#include "polynom.h"
#include "matrix.h"
#include "qq.h"

#include <iostream>

using namespace std;

int main(void)  
{
/*
	Matrix<double> A, S;
	Vector<double> b, x0;

	cin >> A;
	cin >> b;

	cerr << "b = " << b << endl;
*/
/*
	Matrix<double> L, R;
	Vector<long> pmt;
	
	x0.clear();
	
	A.gauss(L, R, pmt);
	compute_coords(L, R, pmt, b, x0, false, false);

	S = L*R;
	for (long i=1; i<=S.M; i++)
		L[pmt[i]] = S[i];

	cerr << (A-S)<< endl;
	cerr << "x0 = " << x0 << endl;
	cerr << "A*x0 = " << A*x0 << endl;
*/
/*
	if (!A.solve(S, x0, b)) 
		ERROR("System is not solvable!");
	
	cerr << "x0 = " << x0 << endl;
	cerr << "A*x0 = " << A*x0 << endl;
*/
	//	cerr << "det A = " << A.determinant() << endl;
	// cerr<< "A*A-1 = " <<	A*A.inverse() << endl;
	// cerr << "A = " << A << endl;
	// cerr << "S = " << S << endl;

/*	
 	for (long i=1; i<=S.M; i++)
		x0 += (S[i]*rand_eq_long(-10000,100000));
	cerr << "x0 = " << x0 << endl;
	cerr << "A*x0 = " << A*x0 << endl;
*/	

#if 0
	register long j;
	Vector<double> ew;
	Polynom<double> p, p1, p2;
	Matrix<double> A, B, C, L, R;
	Vector<long> pmt;

	cin >> A;
	cerr << "A = " << A.transpose() << endl;
	cerr << A.transpose().gauss(L,R,pmt) << endl;
//	cerr << "A = " << A << endl;
//	cerr << A.gauss(L,R,pmt) << endl;
	
	B = L*R;
/*
	cerr << L << endl;
	cerr << R << endl;
	cerr << B << endl;
*/
	C.resize(B.M, B.N);
	for (j=1; j<=pmt.N; j++)
		C[pmt[j]] = B[j];

	cerr << C << endl;
	cerr << pmt << endl;

	exit(1);
#endif

/*
	long min = LMIN(A.M, A.N);

	A.resize(min, min);

	p = A.characteristic_polynom();

	p1 = p.real_root_factor();
	
	cerr << "p(x) = " << p << endl;
	cerr << "real_p(x) = " << p1 << endl;

	p2 = p / p1;

	cerr << "p(x) / real_p(x) = " << p2 << endl;
*/
/*
	time_t t0, t1, t2, t3;
	Matrix<double> B(4,5), Q, R;

	B[1][1] = 0;
	B[1][2] = 0;
	B[1][3] = 1;
	B[1][4] = 0;
	B[1][5] = 0;

	B[2][1] = 2;
	B[2][2] = 1;
	B[2][3] = 0;
	B[2][4] = 1;
	B[2][5] = 0;

	B[3][1] = 1;
	B[3][2] = 0;
	B[3][3] = 0;
	B[3][4] = 0;
	B[3][5] = 0;

	B[4][1] = 1;
	B[4][2] = 2;
	B[4][3] = 3;
	B[4][4] = 0;
	B[4][5] = 0;


	cin >> B;

	B = B.transpose();
	cerr << out_mod << "Read!" << endl;

	time(&t2);
	B.qr(Q,R);
	time(&t3);

	if (B!= (Q*R))
		cerr << out_mod << "B!= QR"<< endl;
	//cerr << out_mod << "B = " << B << endl;
	//cerr << out_mod << "Q*R = " << Q*R << endl;

	time(&t0);
	B.compute_qr(Q, R);
	time(&t1);

	if (B!= (Q*R))
		cerr << out_mod << "B!= QR"<< endl;
	//cerr << out_mod << "B = " << B << endl;
	//cerr << out_mod << "Q*R = " << Q*R << endl;

	std::cerr << out_mod << std::endl;
	
	cerr << out_mod << "My time: " << t1 - t0 << endl;
	cerr << out_mod << "Other time: " << t3 - t2 << endl;
*/
/*
	Matrix<double> A(3, 5);
	Vector<double> b(3), c(5), x(5); 

	A[1][1] = 0;
	A[1][2] = 2;
	A[1][3] = 1;
	A[1][4] = 0;
	A[1][5] = 0;

	A[2][1] = 2;
	A[2][2] = 3;
	A[2][3] = 0;
	A[2][4] = 1;
	A[2][5] = 0;

	A[3][1] = 1;
	A[3][2] = 0;
	A[3][3] = 0;
	A[3][4] = 0;
	A[3][5] = 1;

	c[1] = -3;
	c[2] = -1;
	c[3] = 0;
	c[4] = 0;
	c[5] = 0;

	b[1] = 6;
	b[2] = 13;
	b[3] = 5;
	
	
	cerr << out_mod << "Costs: " << c << endl;

	A.simplex(b, c, x);

	cerr << out_mod << "Optimal: " << x << endl;
	cerr << out_mod << "Minimal value: " << (c*x) << endl;
*/

	return 0;
}
