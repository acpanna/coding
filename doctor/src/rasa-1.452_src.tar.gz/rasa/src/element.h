#ifndef ELEMENT__H
#define ELEMENT__H

#include "globals.h"

#include <iostream>

template <class DATATYPE>
class Element {

	public:
		Element();
		Element(Element const &ref);
		Element(DATATYPE const &ss);
		~Element();

		Element& operator=(Element const &ref);
		
		REAL value(void) { return content.value(); }

		bool operator==(Element const &ref) const;
		bool operator!=(Element const &ref) const;
	
		template <class DATATYPE_FRIEND>
		friend std::ostream& operator<< (std::ostream& os, 
				Element<DATATYPE_FRIEND> &e);

	public:
		DATATYPE content;
		
		Element *prev_element;
		Element *next_element;
};

#include "element.cpp"

#endif
