#include <fstream> 
#include <sstream> 
#include <cstring>

#include "matrix.h"

#define GENMAX 99

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " --M=* --N=* file.prb");
}

int main(int argc, char *argv[])
{
	char suffix[1024], *ptr;
	long i, j, M, N;
	string ostr; 
	
	if (argc != 4) 
		usage(argv[0]);
		
	for (i=1; i<argc; i++) {
		if (strncmp(argv[i], "--M=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> M;
		} else if (strncmp(argv[i], "--N=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> N;
		} else if (strncmp(argv[i], "-", 1) == 0) 
			usage(argv[0]);
		else 
			ostr = argv[i];
	}

	ptr = strstr(( char *) ostr.c_str(), ".prb");

	if (ptr == NULL)
		usage(argv[0]);
		
	if (*(ptr+4) != 0)
		usage(argv[0]);

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	Matrix<REAL> A_g, A_u;
	Vector<REAL> b_g;
	Vector<REAL> l_u, r_u, l_x, r_x;
	
	A_g.resize(M, N);
	b_g.resize(M);
	
	l_x.resize(N);
	l_x.clear();

	r_x.resize(N);

	new_seed();

	// Erzeuge 50:50 Market-Split Problem
	// mit Cornuejols/Dawande Ansatz

	for (i=1; i<=M; i++) {
		b_g[i] = 0;

		for (j=1; j<=N; j++) {
			A_g[i][j] = rand_eq_real(0, GENMAX);
			b_g[i] += A_g[i][j];
		}

		b_g[i] = FLOOR(b_g[i] / 2);
	}

	for (j=1; j<=N; j++) 
		r_x[j] = 1;
	
	A_u.resize(0);
	l_u.resize(0);
	r_u.resize(0);

	fout << ext_prec << A_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << A_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << b_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_x << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_x << endl;
	fout << ext_prec << endl;

	fout << ext_prec << 1 << endl;
	                   
	fout << endl << "// A_u, A_g, l_u, r_u, b_g, l_x, r_x, aardal" << endl;

	fout.close();

	return 0;
}
