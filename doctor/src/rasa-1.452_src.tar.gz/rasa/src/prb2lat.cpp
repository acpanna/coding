#include <fstream> 
#include <sstream> 
#include <cstring>

#include "error.h"
#include "functions.h"
#include "lattice.h"

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " *.prb");
}

int main(int argc, char **argv)
{
	time_t start_time;

	bool aardal = true;
	bool insufficient = true;
	
	long it = 0, rang, sdim, ineq = 0;
	
	char buff[4096], *ptr;
	string istr, ostr;
	
	stringstream stream;

	register long i, j, j1, j2, m, n;

	REAL N, tmp, gcd, R;

	Matrix<REAL> A_u, A_g, AA, T;
	Vector<REAL> l_u, r_u, rr, l_x, r_x, bb, b_g;
	Vector<REAL> ll, uu, aa, cc, l, u, a, c_g, c_u, x;
	
	Lattice<REAL> lat, L;
	
	if (argc != 2) 
		usage(argv[0]);

	istr = argv[1];

	strncpy(buff, istr.c_str(), 4096);
	ptr = strstr(buff, ".prb");
	if (ptr == NULL) 
		usage(argv[0]);
	*ptr = 0;

	ostr = string(buff) + string(".lat");

	ifstream fin(istr.c_str());
	if (!fin.good())
		ERROR("The input file [ " + istr + " ] could not be opened!");

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	fin >> A_u;
	fin >> A_g;

	fin >> l_u;
	fin >> r_u;
	fin >> b_g;

	fin >> l_x;
	fin >> r_x;
	
	fin >> aardal; // NEW
	
	fin.close();

	if (l_u.N != r_u.N)
		ERROR("The dimensions of the inequation bounds differ!")

	if (r_x.N == 0) 
		ERROR("You can't use " + string(argv[0]) + 
				" with problems, where x is free [ <==> sdim == 0 ]!");
	
	if (l_x.N != r_x.N)
		ERROR("The dimensions of the solution bounds differ!")
	
	for (j=1; j<=r_x.N; j++) 
		if (r_x[j] <= l_x[j])
			ERROR("r_x has to be > l_x in each of its components!");

	ineq = A_u.M; // NEW
	
	m = A_g.M;
	
	if (m > 0)
		n = A_g.N;
	else
		n = A_u.N;

	sdim = r_x.N; // NEW -- wegen NTRU (modulo q)
	
	time(&start_time);

	if (m > 0) {

		/************************************/
		/* Remove linear dependent rows and */ 
		/*  make sure that: A_g.M <= A_g.N  */
		/************************************/

		AA.resize(m, n+1);
		for (i=1; i<=m; i++) {
			for (j=1; j<=n; j++)
				AA[i][j+1] = A_g[i][j];
			AA[i][1] = -b_g[i];
		}

		Lattice<REAL> tmp_lat(AA);
		rang = m - tmp_lat.remove_int_deps();

		if (rang < m) {

			Matrix<REAL> A_g_orig;
			Vector<REAL> b_g_orig;

			A_g_orig = A_g;
			b_g_orig = b_g;

			A_g.resize(rang, n);
			b_g.resize(rang);

			for (i=1; i<=rang; i++)  {
				b_g[i] = -tmp_lat.B_curr[i][1];
				for (j=1; j<=n; j++)  
					A_g[i][j] = tmp_lat.B_curr[i][j + 1]; 
			}

			m = rang;

			cerr << "*** Modifying prb file! ***" << endl;

			// Save the modified A_g, b_g and their originals in the prb file!

			ofstream fout_red(istr.c_str());

			fout_red << ext_prec << A_u << endl;
			fout_red << endl;
			fout_red << ext_prec << A_g << endl;
			fout_red << endl;
			fout_red << ext_prec << l_u << endl;
			fout_red << endl;
			fout_red << ext_prec << r_u << endl;
			fout_red << endl;
			fout_red << ext_prec << b_g << endl;
			fout_red << endl;
			fout_red << ext_prec << l_x << endl;
			fout_red << endl;
			fout_red << ext_prec << r_x << endl;
			fout_red << endl;
			fout_red << aardal << endl;
			fout_red << endl;
			fout_red << ext_prec << A_g_orig << endl;
			fout_red << endl;
			fout_red << ext_prec << b_g_orig << endl;

			fout_red << endl << "// A_u, A_g, l_u, r_u, b_g, l_x, r_x, aardal";
			fout_red << ", A_g_orig, b_g_orig" << endl;

			fout_red.close();
		}
	}

	cerr << "Equations: " << m << endl;
	cerr << "Inequalities: " << ineq << endl;
	cerr << "Variables: " << n << endl;

	/***********************************************/
	/* At first ensure that l_x is the zero vector */
	/***********************************************/

	if (!l_x.is_zero()) { // NEW
		r_x = r_x - l_x;
		
		if (m > 0)
			b_g = b_g - A_g*l_x;
		
		if (ineq > 0) {
			l_u = l_u - A_u*l_x;
			r_u = r_u - A_u*l_x;
		}
	}

	lat.resize(m+sdim+1, n+1);
	lat.B_curr.clear();

	l.resize(sdim+1);
	u.resize(sdim+1); 
	a.resize(sdim+1);
	
	c_g.resize(sdim+1);
	c_u.resize(ineq);
		
	// Bestimme das kgV der Komponenten von r_x
	// R = kgv(r_x[1], r_x[2], ..., r_x[n])
	//
	// c_g[j] = R / r_x[j]
	//
	// siehe hierzu Seiten 8/9 in
	// http://btmdx1.mat.uni-bayreuth.de/~haaner/papers/mark_split.pdf

	if (sdim == 0) 
		R = 1;
	else {

		gcd = R = r_x[1];
		for (j=2; j<=sdim; j++) {
			gcd = ggT(R, r_x[j]);
			R = (R * r_x[j]) / gcd;
		}
	}
	
	// Bestimme das kgV der Komponenten von 
	// (r_u - l_u) mit R und setze:
	// 
	// R = kgV(R, r_u[1] - l_u[1], r_u[2] - l_u[2], ..., r_u[ineq] - l_u[ineq]),
	// c_u[j] = R / (r_u[j] - l_u[j])
	
	// <begin> NEW //
	
	for (j=1; j<=ineq; j++) 
	    if ((r_u[j] - l_u[j]) == 0)
		break;
	    
	if (j > ineq) {
	    for (j=1; j<=ineq; j++) {
		tmp = r_u[j] - l_u[j];
		gcd = ggT(R, tmp);
		R = (R * tmp) / gcd;
	    }
	}
	
	for (j=1; j<=ineq; j++) {
	    tmp = r_u[j] - l_u[j];
	    if (tmp == 0)
		c_u[j] = 1;
	    else
		c_u[j] = R / (r_u[j] - l_u[j]);
	}

	// <end NEW> //
	
	for (j=1; j<=sdim; j++) {
		c_g[j] = R / r_x[j];
		u[j] = R;
		l[j] = -u[j];
	}
		
/*
	cerr << "c = " << c << endl;
	cerr << "l = " << l << endl;
	cerr << "u = " << u << endl;
	cerr << "A_g = " << A_g << endl;
	cerr << "b_g = " << b_g << endl;
*/
	for (j=1; j<=sdim; j++) {

		/* u[j] % 2 == 0 */

		if (ROUND(u[j] / 2) == (u[j] / 2)) 
			a[j] = 0;
		else
			a[j] = -1;
	}

	l[sdim+1] = -R;
	u[sdim+1] = R;
	a[sdim+1] = -1;

	for (i=1; i<=m; i++)
		lat.B_curr[i][1] = -b_g[i];

	for (i=m+1; i<=m+sdim; i++)
		lat.B_curr[i][1] = -R;

	for (i=1; i<=m; i++)
		for (j=2; j<=n+1; j++) 
			lat.B_curr[i][j] = A_g[i][j-1];

	for (i=m+1; i<=m+sdim; i++)
		lat.B_curr[i][i-m+1] = 2*c_g[i-m];

	lat.B_curr[m+sdim+1][1] = R;
	for (j=2; j<=sdim+1; j++)
		lat.B_curr[m+sdim+1][j] = 0;

	if (aardal && m > 0) { // Remember: m = A_g.M

		N = 10 * FMAX(TO_REAL(n), TO_REAL(m));
/*
		M = b_g.quad_euklid_norm();

		AA = A_g.transpose();
		for (i=1; i<=n; i++)
			M = LMAX(M, AA[i].quad_euklid_norm());

		Nmax = pow(4.0 / (4.0*delta - 1.0), n / 2.0) * 2 * SQRT((m+1)*(n+1)) * R;
		Nmax *= pow(M, m);
*/	  
	  	cerr << "Aardal reduction is enabled!" << endl;
		
		while (insufficient) {

			it++;

			L = lat.B_curr.transpose();

			for (i=1; i<=n+1; i++)
				for (j=1; j<=m; j++)
					L.B_curr[i][j] *= N;

			L.sort(true); 
			L.lll();
			L.sort(true); 
		
			if (L.B_curr.overflow()) 
				ERROR("[ " << istr << " ] Overflow --> Increase Precision!")

			insufficient = false;

			for (i=1; i<=n-m+1; i++) { 
				if (!insufficient) {
					for (j=1; j<=m; j++) {
						if (L.B_curr[i][j] != 0) {
							insufficient = true;
							N *= 10;
							break;
						}
					}
				}
			}
		}

		/**************************************************/
		/*   The Aardal reduction was succesful, hence    */
		/* unnecessary rows and columns are stripped off. */
		/**************************************************/

		lat.resize(n-m+1, sdim+1);
		for (i=1; i<=n-m+1; i++) 
			for (j=m+1; j<=m+sdim+1; j++)
				lat.B_curr[i][j - m] = L.B_curr[i][j];

		T = L.T;
		L = lat.B_curr.transpose();

		lat = L.B_curr;
		
		//cerr << "R = " << R << endl;
		//cerr << "lat = " << lat << endl;
		
		/********************************************************/
		/* The following code checks, if an integer solution x  */
		/* for the problem A_g * x = b_g exists, which does not */
		/*		 necessarily fulfill the bound l_x <= x < r_x 	  */
		/********************************************************/
		
		insufficient = true;

		while (insufficient) {

			L = lat.B_curr.transpose();

			for (i=1; i<=n-m+1; i++)
				L.B_curr[i][sdim+1] *= N; 

			L.sort(true); 
			L.lll();
			L.sort(true); 

			if (L.B_curr.overflow()) 
				ERROR("[ " << istr << " ] Overflow2 --> Increase Precision!")

			insufficient = false;

			if (!insufficient) {
				for (i=1; i<=n-m; i++) {
					if (L.B_curr[i][sdim+1] != 0) {
						insufficient = true;
						N *= 10; 
						break;
					}
				}
			}

			if (!insufficient) {
				if (ABS(L.B_curr[n-m+1][sdim+1]) != R*N) {
					cout << endl;
					cout << "The equation system has no integer solution!";
					cout << endl;

					exit(1);
				}
			}
		}

		L = lat.B_curr;
//		cerr << "L2 = " << L << endl;
	
	} else {
		T.make_one(n+1);  
		L.B_curr = lat.B_curr;
	}
	
	if (ineq > 0) {

		AA.resize(ineq, n+1);
		for (i=1; i<=ineq; i++) { 
			AA[i][1] = -(l_u[i] + r_u[i]) * c_u[i]; // NEW

			for (j=2; j<=n+1; j++)
				AA[i][j] = 2*c_u[i] * A_u[i][j-1]; // NEW
		}
		
		A_u = AA.transpose();

		j1 = A_u.N;

		if (aardal)  {

			/*****************************************/
			/*   Apply the Aardal-transformation T   */
			/* to the the inequations stored in A_u. */
			/*****************************************/
			 
			A_u = T*A_u;  

			j2 = j1;

		} else  
			j2 = j1 + m;

		L.resize(lat.M + j1, lat.N);

		for (i=1; i<=j1; i++)
			for (j=1; j<=lat.N; j++) 
				L.B_curr[i][j] = A_u[j][i];

		for (i=j1+1; i<=lat.M + j1; i++)
			for (j=1; j<=lat.N; j++) 
				L.B_curr[i][j] = lat.B_curr[i - j1][j];
	
	} else {

		j1 = 0;
		
		if (aardal) 
			j2 = 0;
		else 
			j2 = m;
	}
		
	ll.resize(l.N + j2);
	uu.resize(u.N + j2);
	aa.resize(a.N + j2);
	cc.resize(c_g.N + j2);

	for (j=1; j<=j1; j++) {
	  tmp = (r_u[j] - l_u[j]);
	  
	  if (tmp == 0)
	      ll[j] = 0;
	  else
	      ll[j] = -R; 
	 
	  uu[j] = -ll[j];
	  aa[j] = 0;
	  cc[j] = c_u[j]; // 0; // NEW
	}
	
	for (j=j1+1; j<=j2; j++) 
		ll[j] = uu[j] = aa[j] = cc[j] = 0;
		
	for (j=j2+1; j<=j2 + sdim + 1; j++) {
		ll[j] = l[j - j2];
		uu[j] = u[j - j2];
		aa[j] = a[j - j2];
		cc[j] = c_g[j - j2]; // NEW
	}
	
	stream << (time(NULL) - start_time);

	fout << ext_prec << L.B_curr.transpose() << endl;
	fout << endl;
	fout << ext_prec << ll << endl;
	fout << ext_prec << uu << endl;
	fout << ext_prec << aa << endl;
	fout << endl;
	fout << ext_prec << cc << endl;
	fout << endl;
	fout << ext_prec << R << endl;
	fout << ext_prec << 0 << endl; // FIXME (idx)
	fout << ext_prec << 0 << endl; // FIXME (val)
	fout << endl;
	fout << ext_prec << ineq << endl; // NEW 

	fout << endl;
	fout << ext_prec << T << endl; // NEW

	fout << endl << "// lattice, lbnd, ubnd, anz0, c, R, idx, val, ineq, T";
	fout << endl << "// " + stream.str() + " sec(s)";
	fout << endl;

	fout.close();

	cerr << "Lattice file: " << ostr << endl;
	cerr << "Time: " << stream.str() << " sec(s)" << endl;
	cerr << "Iters: " << it << endl;

	return 0;
}
