#include <iostream>

#include "error.h"
#include "functions.h"
	
template <class DATATYPE>
Set<DATATYPE>::Set(void) : elements(0), elements_max(0), first_element(0), last_element(0), curr_element(0), center(TO_REAL(0)), dst_2(TO_REAL(0))
{ } 

template <class DATATYPE>
Set<DATATYPE>::Set(long max) : elements(0), elements_max(max), first_element(0), last_element(0), curr_element(0), center(TO_REAL(0)), dst_2(TO_REAL(0))
{} 

template <class DATATYPE>
Set<DATATYPE>::Set(Set<DATATYPE> const &ref) : elements(0), elements_max(ref.elements_max), first_element(0), last_element(0), curr_element(0), center(TO_REAL(0)), dst_2(TO_REAL(0))
{
	*this = ref;
}

template <class DATATYPE>
Set<DATATYPE>::~Set()
{
	clear();
}

template <class DATATYPE>
void Set<DATATYPE>::clear(void) 
{
	if (!elements)
		return;

	Element<DATATYPE> *element = first_element;

	while (element != 0) {
		first_element = element->next_element;

		elements--;
		delete element;

		element = first_element;
	}

	first_element = last_element = curr_element = 0;

	center = 0;
	dst_2 = 0;
}

template <class DATATYPE>
Set<DATATYPE> & Set<DATATYPE>::operator= (const Set &ref)
{
	clear();

	elements_max = LMAX(elements_max, 
			ref.elements_max);

	vereinigung(ref);
	return *this;
}

template <class DATATYPE>
bool Set<DATATYPE>::insert(const Element<DATATYPE> &e)
{
	Element<DATATYPE> *ret;

	if ((ret = contains(e))) {
		curr_element = ret; 
		return true;
	}

	if (elements_max > 0 && elements >= elements_max)
		return false;

	Element<DATATYPE> *element = new Element<DATATYPE>(e);
	
	if (last_element) {
		last_element->next_element = element;

		element->prev_element = last_element;
		last_element = element;

	} else {
		element->prev_element = 0;
		first_element = last_element = element;
	}
	
	element->next_element = 0;
	curr_element = element;

	elements++;
	return true;
}

template <class DATATYPE>
Set<DATATYPE> & Set<DATATYPE>::vereinigung(const Set &other)
{
	Element<DATATYPE> *element = other.first_element;

	while (element != 0) {
		insert(*element);
		element = element->next_element;
	}

	return *this;
}

template <class DATATYPE>
Element<DATATYPE> * 
Set<DATATYPE>::contains(const Element<DATATYPE> &e) const
{
	if (!elements)
		return NULL;

	Element<DATATYPE> *element = first_element;

	while ((*element) != e) {
		if (element->next_element != 0) 
			element = element->next_element;
		else 
			return NULL;
	}

	return element;
}

template <class DATATYPE>
bool Set<DATATYPE>::contains(const Set &other) const
{
	Element<DATATYPE> *element = other.first_element;

	while (element != 0) {
		if (!contains(*element))
			return false;
		element = element->next_element;
	}

	return true;
}

template <class DATATYPE>
bool Set<DATATYPE>::operator== (const Set &other) const
{
	if (!contains(other))
		return false;	
	else
		return other.contains(*this);
}

template <class DATATYPE>
bool Set<DATATYPE>::remove(const Element<DATATYPE> &e)
{
	if (!elements)
		return false;

	Element<DATATYPE> *element = first_element;

	while ((*element) != e) {
		if (element->next_element != 0) 
			element = element->next_element;
		else 
			return false;
	}

	if (element->prev_element != 0) {
		element->prev_element->next_element = element->next_element;

		if (element->next_element != 0)
			element->next_element->prev_element = element->prev_element;
		else
			last_element = element->prev_element;

	} else if (element->next_element != 0)
		first_element = element->next_element;
	else
		first_element = last_element = 0;

	elements --;
	delete element;

	return true;
}	

template <class DATATYPE>
void Set<DATATYPE>::remove_smaller(void)
{
	if (!elements) {
		ERROR("elements == 0");
	}

	Element<DATATYPE> *element, *prev_element, *next_element;

	element = first_element;

	next_element = element->next_element;
	prev_element = element->prev_element;

	while (next_element != 0) {

		if (element->value() < curr_element->value()) {

			if (prev_element != 0)
				prev_element->next_element = next_element;
			else 
				first_element = next_element;

			next_element->prev_element = prev_element;
			
			delete element;
			elements --;
		}

		element = next_element;

		next_element = element->next_element;
		prev_element = element->prev_element;
	}

	last_element = element;
}	

template <class DATATYPE>
void Set<DATATYPE>::remove_greater(void)
{
	if (!elements)
		ERROR("elements == 0")

	Element<DATATYPE> *element, *prev_element, *next_element;

	element = first_element;

	next_element = element->next_element;
	prev_element = element->prev_element;

	while (next_element != 0) {

		if (element->value() > curr_element->value()) {

			if (prev_element != 0)
				prev_element->next_element = next_element;
			else 
				first_element = next_element;

			next_element->prev_element = prev_element;
			
			delete element;
			elements --;
		}
	
		element = next_element;

		next_element = element->next_element;
		prev_element = element->prev_element;
	}

	last_element = element;
}	

template <class DATATYPE>
Element<DATATYPE> * 
Set<DATATYPE>::min_element(void) const
{
	Element<DATATYPE> *min_element, *element;
	REAL tmp, min;

	min_element = 0;
	element = first_element;
	min = 0;
	
	while (element != 0) {
	
		tmp = element->value();

		if (tmp < min || min == 0) {
			min_element = element;
			min = tmp;
		}

		element = element->next_element;
	}

	return min_element;
}

template <class DATATYPE>
Element<DATATYPE> * 
Set<DATATYPE>::max_element(void) const
{
	Element<DATATYPE> *max_element, *element;
	REAL tmp, max;
	
	max_element = 0;
	element = first_element;
	max = 0;

	while (element != 0) {
		
		tmp = element->norm();

		if (tmp > max) {
			max_element = element;
			max = tmp;
		}

		element = element->next_element;
	}
	
	return max_element;
}

template <class DATATYPE>
void Set<DATATYPE>::swap(Element<DATATYPE> &e1, 
		Element<DATATYPE> &e2)
{
	if (&e1 == &e2)
		return;

	if (e2.next_element == &e1)
		return swap(e2, e1);

#if 0	
		cerr << "swap before: " << *this << endl;
#endif

	if (e1.next_element == &e2) { // Spezialfall
	
		Element<DATATYPE> *p = e1.prev_element;

		if (p != 0)
			p->next_element = &e2;
		else 
			first_element = &e2;

		if (e2.next_element != 0)
			e2.next_element->prev_element = &e1;
		else
			last_element = &e1;

		e1.next_element = e2.next_element;
		e1.prev_element = &e2;

		e2.next_element = &e1;
		e2.prev_element = p;

	} else { // Allgemeiner Fall

		Element<DATATYPE> *p = e1.prev_element;
		Element<DATATYPE> *n = e1.next_element;
		
		if (n != 0)
			n->prev_element = &e2;
		else 
			last_element = &e2;

		if (p != 0)
			p->next_element = &e2;
		else
			first_element = &e2;

		if (e2.next_element != 0)
			e2.next_element->prev_element = &e1;
		else 
			last_element = &e1;

		if (e2.prev_element != 0)
			e2.prev_element->next_element = &e1;
		else
			first_element = &e1;

		e1.next_element = e2.next_element;
		e1.prev_element = e2.prev_element;

		e2.next_element = n;
		e2.prev_element = p;
	}

#if 0
		cerr << "swap after: " << *this << endl;
#endif

}

template <class DATATYPE>
void Set<DATATYPE>::shuffle(register long count)
{
	register long i, j, k, s;
	Element<DATATYPE> *e1, *e2;
	
	if (elements <= 1) 
		return;

	for (s=1; s<=count; s++) {

		e1 = first_element;
		e2 = first_element;
		
		i = rand_eq_long(1, elements);
		j = rand_eq_long(1, elements);

		for (k=1; k<i; k++)
			e1 = e1->next_element;

		for (k=1; k<j; k++)
			e2 = e2->next_element;

		swap(*e1, *e2);
	}
}

template <class DATATYPE_FRIEND>
std::ostream& operator << (std::ostream& os, Set<DATATYPE_FRIEND> &set)
{
	std::string space;
	Element<DATATYPE_FRIEND> *element = set.first_element;

	os << "( elements_max = " << set.elements_max << ", elements = " << set.elements;
	os << ", center = " << set.center << ", dst_2 = " << set.dst_2 << " ) " << std::endl;

	os << "{" << std::endl;
	while (element != 0) {

		if (element == set.curr_element) 
			os << "--> ";
		else
			os << "    ";

		os << (*element);
		
		if (element == set.curr_element) 
			os << " <-- ";
		os << std::endl;

		element = element->next_element;
	}
	os << "}" << std::endl;

	return os;
}
