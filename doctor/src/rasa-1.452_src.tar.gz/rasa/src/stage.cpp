Stage::Stage() : ytilda(TO_REAL(0)), vtilda(TO_REAL(0)), ctilda(TO_REAL(0)), utilda(TO_REAL(0)), Delta(TO_REAL(0)), delta(TO_REAL(1)) { }

void Stage::clear(void)
{ 
	ytilda = TO_REAL(0); 
	vtilda = TO_REAL(0); 
	ctilda = TO_REAL(0); 
	utilda = TO_REAL(0);

	Delta = TO_REAL(0); 
	delta = TO_REAL(1); 
}
