template <typename REAL>
Sample<REAL>::Sample() : B(0), U(0), MU(0), pi(TO_REAL(0)), len(TO_REAL(0)), pos(0) 
{}

template <typename REAL>
Sample<REAL>::Sample(Sample<REAL> const &ref) : B(ref.B), U(ref.U), MU(ref.MU), pi(ref.pi), len(ref.len), pos(ref.pos) 
{}

template <typename REAL>
Sample<REAL>::~Sample() 
{}

template <typename REAL>
Sample<REAL> const & Sample<REAL>::operator=(Sample<REAL> const &ref)
{ 
	B = ref.B; 
	U = ref.U; 
	MU = ref.MU; 
	pi = ref.pi; 
	len = ref.len; 
	pos = ref.pos; 

	return *this; 
}

template <typename REAL>
Sample<REAL> const & Sample<REAL>::operator=(double const &ref)
{ 
	B.resize(1);
	U.resize(1);
	MU.resize(1);

	B[1] = ref; 
	U[1] = ref; 
	MU[1] = ref; 

	pi = ref; 
	len = ref; 
	pos = ref; 

	return *this; 
}

template <typename REAL_FRIEND>
void sswap(Sample<REAL_FRIEND> &a, Sample<REAL_FRIEND> &b) 
{
	register long i;

	REAL_FRIEND *flt_ptr;
	REAL_FRIEND *int_ptr;
	
	REAL_FRIEND f;
	
	flt_ptr = a.B.data; 
	a.B.data = b.B.data; 
	b.B.data = flt_ptr;

	flt_ptr = a.MU.data; 
	a.MU.data = b.MU.data; 
	b.MU.data = flt_ptr;

	int_ptr = a.U.data; 
	a.U.data = b.U.data; 
	b.U.data = int_ptr;

  	f = a.pi; 
	a.pi = b.pi;
	b.pi = f;

	f = a.len; 
	a.len = b.len;
	b.len = f;

	i = a.pos; 
	a.pos = b.pos;
	b.pos = i;
}
