#include "release.h"
#include "functions.h"
#include "globals.h"
#include "lattice.h"

#ifdef SERVER
#include "tcp.h" 
#endif

#include <iomanip>
#include <fstream> 
#include <sstream>
#include <cstring>
#include <ctime>

#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>
#include <libgen.h>

void usage(void);
void* timer(void *arg);

void read_params(int argc, char **argv);
void set_param_str(std::ostringstream &oss);

bool read_lattice(void); 

void exit_handler(int sig);

void kill_it(void);


char param[21][1024];

string input_file = "";
string map_file = "";

string dbase = "";

unsigned int seed = 0;

bool trans = true;

double alpha = 0.5;
double delta = 0.99;

long beta = 20;
long deep = 0;

long btime = 0;
long rtime = 0;

long gsa = 0;
long slimit = 20000;
bool prj = false;

long eprune = 0;
long eenum = 0;

bool pwr = true;
long sieve = -1; 
long heu = 0;

long verb = 0;

#ifdef SERVER
pthread_t server_thread = 0;
#endif
pthread_t time_thread = 0;

pid_t pid;

string prg = "";

Lattice<REAL> lat;

char star_line[] = "**************************************************************************";

using namespace std;

int main(int argc, char **argv)
{
	register long rank;

	Matrix<REAL> A, L, S;
	Vector<long> pivot;

	cerr << "RASA v" << string(RELEASE) << " ";
	cerr << "-- (c) Copyright by Heiko Vogel < heiko.vogel@birdworx.de >";
	cerr << endl << endl;

	read_params(argc, argv);
	
	if (!read_lattice())
		return 1;

//	seed = 17101978; // FIX

	if (seed)
		new_seed(seed);
	else  
		seed = new_seed();
	
	signal(SIGINT, exit_handler);
	signal(SIGTERM, exit_handler);
	
	/***********************************************************/
	/*        Falls der Parameter "rtime" gesetzt wurde,       */
	/*  starte einen Thread, der das Programm beendet, sobald  */
	/*    die vorgegebene Laufzeit in Sekunden erreicht ist.   */
	/***********************************************************/
	
	if (rtime) 
		pthread_create(&time_thread, NULL, timer, (void *) rtime);

#ifdef SERVER
	pthread_create(&server_thread, NULL, tcp_server, (void *) 0); 
#endif
	
	cerr << "[ PID = " << pid << " | ";

	cerr << "M = " << lat.M << ", N = " << lat.N << ", ";
	cerr << "rank = ";

	A = lat.B_curr;
	rank = A.normierte_zeilenstufenform(S, L, pivot);
	cerr << rank << " ]" << endl;

	ostringstream oss;
	set_param_str(oss);

	lat.params = oss.str();
	
	if (verb) {
		cerr << endl;
		cerr << "The following parameters are set:" << endl;
		cerr << endl;

		cerr << oss.str() << endl;
		cerr << endl;
	}
	
	/**************************************************************/
	
	beta = LMIN(beta, lat.M);

	lat.init_params(dbase, verb, btime, trans, alpha, delta, beta, deep, 
			eprune, eenum, pwr, sieve, heu, gsa, prj, slimit);

	/*************************************/
	/* Remove the dependencies at first! */
	/*************************************/

	lat.remove_int_deps(); 		

	if (verb)
		cerr << endl;

	lat.check_solution();  
	lat.bkz();
	lat.reduce_loop();

	/**************************************************************/

	return 0;
}

void usage(void) 
{
	cerr << "Usage: " << prg << " [options] *.lat" << endl;
	cerr << endl;
	cerr << "The available options are:" << endl;

	ostringstream oss;
	set_param_str(oss);

	cerr << endl;
	cerr << oss.str();
	cerr << endl;
	
	exit(1);
}

void* timer(void *arg) 
{ 
	time_t start, curr, duration;

	time(&start);
	duration = (long) arg;
	
	while (true) {

		time(&curr);

		if (curr - start >= duration) {
			send_signal(15);
			return NULL;
		}

		sleep(10);
	}
	
	return NULL;
}

void read_params(int argc, char **argv)
{
	register long i;
	string buff = "";

	prg = argv[0];

	if (argc <= 1)
		usage();

	for (i=1; i<argc; i++) {
	
		if (strncmp(argv[i], "--help", 6) == 0 || strncmp(argv[i], "-h", 2) == 0)
			usage();

		else if (strncmp(argv[i], "--trans=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> trans;
		} else if (strncmp(argv[i], "--alpha=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> alpha;
		} else if (strncmp(argv[i], "--delta=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> delta;
		} else if (strncmp(argv[i], "--beta=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> beta;
		} else if (strncmp(argv[i], "--deep=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> deep;
		} else if (strncmp(argv[i], "--heu=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> heu;
		} else if (strncmp(argv[i], "--verb=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> verb;
		} else if (strncmp(argv[i], "--dbase=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> dbase;
		} else if (strncmp(argv[i], "--pwr=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> pwr;
		} else if (strncmp(argv[i], "--eprune=", 9) == 0) {
			buff = argv[i]+9;
			istringstream iss(buff);
			iss >> eprune;
		} else if (strncmp(argv[i], "--eenum=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> eenum;
		} else if (strncmp(argv[i], "--prj=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> prj;
		} else if (strncmp(argv[i], "--sieve=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> sieve;
		} else if (strncmp(argv[i], "--gsa=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> gsa;
		} else if (strncmp(argv[i], "--slimit=", 9) == 0) {
			buff = argv[i]+9;
			istringstream iss(buff);
			iss >> slimit;
		} else if (strncmp(argv[i], "--map=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> map_file;
		} else if (strncmp(argv[i], "--btime=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> btime;
		} else if (strncmp(argv[i], "--rtime=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> rtime;
		} else if (strncmp(argv[i], "--sol=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> sol;
		} else if (strncmp(argv[i], "--targets=", 10) == 0) {
			buff = argv[i]+10;
			istringstream iss(buff);
			iss >> targets;
		} else if (strncmp(argv[i], "--slk=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> slk;
		} else if (strncmp(argv[i], "--seed=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> seed;
		} else if (strncmp(argv[i], "-", 1) == 0) {
			usage();
		} else 
			input_file = argv[i];
	}
}

void set_param_str(std::ostringstream &oss) 
{
	std::ostringstream oss2;
	
	oss2.str("");
	oss.str("");

	oss2 << "--seed=" << seed;
	strcat(param[0], oss2.str().c_str()); 
	oss << "[ " << oss2.str() << " ";
	oss2.str("");

	oss2 << "--alpha=" << alpha;
	sprintf(param[1], "%s", oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--delta=" << delta;
	sprintf(param[2], "%s", oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--beta=" << beta;
	strcat(param[3], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--deep=" << deep;
	strcat(param[4], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--eprune=" << eprune;
	strcat(param[5], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--eenum=" << eenum;
	strcat(param[6], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--slimit=" << slimit;
	strcat(param[7], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--gsa=" << gsa;
	strcat(param[8], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--prj=" << prj;
	strcat(param[9], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--heu=" << heu;
	strcat(param[10], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--pwr=" << pwr;
	strcat(param[11], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--sieve=" << sieve;
	strcat(param[12], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--trans=" << trans;
	strcat(param[13], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--btime=" << btime;
	strcat(param[14], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--rtime=" << rtime;
	strcat(param[15], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--sol=" << sol;
	strcat(param[16], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--targets=" << targets;
	strcat(param[17], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--slk=" << slk;
	strcat(param[18], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--verb=" << verb;
	strcat(param[19], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--dbase=";
	if (dbase == "")
		oss2 << "*";
	else
		oss2 << dbase;
	strcat(param[20], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--map=";
	if (map_file != "")
		oss2 << map_file << " ]";
	else
		oss2 << "*.map_* ]";
	oss << oss2.str();
}

bool read_lattice(void) 
{
	char *ptr;
	register long i;
	
	string file, map_params;
	stringstream ss;

	Matrix<REAL> A, AA, C, L, S;
	Vector<REAL> coord, vec;
	Vector<long> pivot;

	ifstream fin(input_file.c_str());
	if (!fin.good()) {
		cerr << ext_prec << "The file [ " << input_file << " ] can't be opened!";
		cerr << ext_prec << endl;
		return false;
	}

	ptr = strstr((char *) input_file.c_str(), ".lat");

	if (ptr == NULL) 
		usage();
	
	fin >> lat;
	fin.close();

	pid = getpid();
	ss << pid;

	file = input_file;
	file.erase(ptr - input_file.c_str());

	lat.nrm_file = file + string(".nrm_") + ss.str();
	lat.map_file = file + string(".map_") + ss.str();

	if (map_file != "") {
		
		fin.open(map_file.c_str());
		getline(fin, map_params);

		fin >> lat.B_curr;
		fin >> lat.TT;
		
		if (lat.TT.N == 0) 
			ERROR("There is no transformation saved in the map file")
		else {

			for (i=1; i<lat.TT.N; i++)
				lat.B = lat.TT[i] * lat.B;
			lat.T = lat.TT[lat.TT.N];

			C = lat.T * lat.B;
			C.resize(lat.B_curr.M, lat.N);

			if (lat.B_curr != C) 
				ERROR("Map Error")
			else 
				lat.M = lat.B_curr.M;
		}

		lat.check_trans();

		if (read_vector(fin, vec)) 
			lat.check_best_heu(vec);

		if (read_vector(fin, vec)) 
			lat.check_best_slk(vec);

		while (read_vector(fin, vec)) 
			lat.check_solution(vec);

		fin.close();
	}

	return true;
}

void exit_handler(int sig)
{
	cerr << endl; 
	cerr << "Got signal: ";
	cerr << strsignal(sig);

	kill_it();
}

void kill_it(void) 
{
	int fd1, fd2;

	cerr << endl;
	cerr << star_line;
	cerr << endl;

	/***********************************************************/
	/* RACE CONDITION :													  */
	/*	----------------													  */
	/* On exiting the lattice can be in an inconsistent state, */
	/* because of memory allocations, which could occur right  */
	/* at the moment when a signal gets caught and handled.    */
	/*																			  */
	/*    ==> calling check_trans in a handler WILL fail !!!   */
	/*       [ the same applies for map-file writes ... ]		  */
	/***********************************************************/

	lat.print_sol();
	cerr << endl;
	
	fd1 = open(lat.map_file.c_str(), O_RDONLY);
	fd2 = open(lat.nrm_file.c_str(), O_RDONLY);

	if (fd1 != -1 && fd2 != -1) {
		cerr << "The following files contain the results: " << endl;
		cerr << endl;
		cerr << "\t" << lat.map_file << endl;
		cerr << "\t" << lat.nrm_file << endl;
		cerr << endl;
	} else if (fd1 != -1) {
		cerr << "The following file contains the results: " << endl;
		cerr << endl;
		cerr << "\t" << lat.map_file << endl;
		cerr << endl;
	} else if (fd2 != -1) {
		cerr << "The following file contains the results: " << endl;
		cerr << endl;
		cerr << "\t" << lat.nrm_file << endl;
		cerr << endl;
	}

	close(fd1);
	close(fd2);
	
	cerr << "Total iterations: " << lat.iters << endl;
	cerr << "Total running time: ";
	print_time(cerr, time(NULL) - lat.create_time);
	cerr << " -- Program terminated" << endl;
	
	_exit(0);
}
