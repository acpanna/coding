#ifndef POLYNOM__H
#define POLYNOM__H

#include "vector.h"

template <typename DATATYPE>
class Polynom {
	
public:
		Polynom();
		Polynom(Polynom<DATATYPE> const &ref_pol);
		Polynom(Vector<DATATYPE> const &ref_vec);
		virtual ~Polynom();

		DATATYPE & operator[] (register long j) const;
		DATATYPE operator() (DATATYPE const &x) const;
		
		Polynom<DATATYPE> const & operator= (Polynom<DATATYPE> const &ref_pol);
		Polynom<DATATYPE> const & operator= (DATATYPE const &ref_scal);
	
		Polynom<DATATYPE> const & operator+=(Polynom<DATATYPE> const &ref);
		Polynom<DATATYPE> const & operator-=(Polynom<DATATYPE> const &ref);

		Polynom<DATATYPE> const & operator*=(DATATYPE const &ref);
		Polynom<DATATYPE> const & operator*=(Polynom<DATATYPE> const &ref);
		Polynom<DATATYPE> const & operator/=(DATATYPE const &ref);
		Polynom<DATATYPE> const & operator/=(Polynom<DATATYPE> const &ref);
		
		Polynom<DATATYPE> operator+(Polynom<DATATYPE> const &ref) const;
		Polynom<DATATYPE> operator+(DATATYPE const &ref) const;
		Polynom<DATATYPE> operator-(Polynom<DATATYPE> const &ref) const;
		Polynom<DATATYPE> operator-(DATATYPE const &ref) const;
		Polynom<DATATYPE> operator*(Polynom<DATATYPE> const &ref) const;
		Polynom<DATATYPE> operator*(DATATYPE const &ref) const;
		Polynom<DATATYPE> operator/(Polynom<DATATYPE> const &ref) const;
		Polynom<DATATYPE> operator/(DATATYPE const &ref) const;
		
		Polynom<DATATYPE> operator-(void) const;

		bool operator==(Polynom<DATATYPE> const &ref) const;
		bool operator==(DATATYPE const &ref) const;
		bool operator!=(Polynom<DATATYPE> const &ref) const;
		bool operator!=(DATATYPE const &ref) const;

		bool operator>(DATATYPE const &ref) const;
		bool operator>(Polynom<DATATYPE> const &ref) const;
		bool operator>=(DATATYPE const &ref) const;
		bool operator>=(Polynom<DATATYPE> const &ref) const;

		Polynom<DATATYPE> xmult(register long exp) const;

		void polynomdivision(Polynom<DATATYPE> const &div, 
				Polynom<DATATYPE> &q, Polynom<DATATYPE> &r) const;

		Polynom<DATATYPE> differentiate(void) const;
		Polynom<DATATYPE> integrate(void) const;

		DATATYPE newton_root(void) const;
		Polynom<DATATYPE> real_root_factor(void) const;
		
		long grad(void) const;
		
		void trim(void);

private:
		Vector<DATATYPE> a;
};

#include "polynom.cpp"

#endif
