#include <fstream> 
#include <sstream> 
#include <cstring>

#include "matrix.h"

#define GENMAX 99

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " --N=* file.prb");
}

int main(int argc, char *argv[])
{
	char suffix[1024], *ptr;
	long i, j, M, N;
	string ostr; 
	
	if (argc != 3) 
		usage(argv[0]);
		
	for (i=1; i<argc; i++) {
		if (strncmp(argv[i], "--N=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> N;
		} else if (strncmp(argv[i], "-", 1) == 0) 
			usage(argv[0]);
		else 
			ostr = argv[i];
	}

	ptr = strstr(( char *) ostr.c_str(), ".prb");

	if (ptr == NULL)
		usage(argv[0]);
		
	if (*(ptr+4) != 0)
		usage(argv[0]);

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	// Variablen: 
	//
	// N Städte ==> N*N x_i,j + N u_i ==> (N+1)*N Variable
	// Gleichungen: Für jede Stadt: 2 Gleichungen ==> N*2 Gleichungen + 1 MTZ-Gleichung
	// Ungleichungen: (N-1) * (N-1) MTZ-Ungleichungen + 1 Zielfunktionsungleichung

	Matrix<REAL> A_g, A_u;
	Vector<REAL> b_g;
	Vector<REAL> l_u, r_u, r_x;
	
	r_x.resize((N+1)*N);
	A_g.resize(N*2+1, r_x.N);
	b_g.resize(A_g.M);

	A_u.resize((N-1)*(N-1)+1, r_x.N);
	l_u.resize(A_u.M);
	r_u.resize(A_u.M);

	A_g.clear();
	A_u.clear();

	// sum x_i,j = 1 (j != i)
	for (i=1; i<=N; i++) {
		for (j=1; j<=N; j++) 
			if (i != j)
				A_g[i][(i-1)*N + j] = 1; 

		b_g[i] = 1;
	}
	
	// sum x_j,i = 1 (j != i)
	for (i=1; i<=N; i++) {
		for (j=1; j<=N; j++) 
			if (i != j)
				A_g[N + i][(j-1)*N + i] = 1;
		
		b_g[N + i] = 1;
	}
	
	// u_1 = 1
	A_g[2*N + 1][2*N + 1] = 1;
	b_g[2*N + 1] = 1;

	// Gleichungen sind belegt
	
	cerr << A_g << endl;
	cerr << b_g << endl;
	
	for (i=1; i<=N-1; i++) {
		for (j=1; j<=N-1; j++) {
			A_u[1 + (i-1)*(N-1)+j][i*N+(j+1)] = N;
			A_u[1 + (i-1)*(N-1)+j][2*N+(i+1)] = 1;
			A_u[1 + (i-1)*(N-1)+j][2*N+(j+1)] = -1;

			r_u[1 + (i-1)*(N-1)+j] = N-1;
			l_u[1 + (i-1)*(N-1)+j] = -(N-2);
		}
	}

	// Ungleichungen sind belegt

	// Erzeuge zufälligen Distanz-/Kostenvektor,
	// der als Zielfunktion dient und die erste 
	// Ungleichung des Systems repräsentiert.

	for (j=1; j<=2*N; j++) 
		A_u[1][j] = rand_eq_real(1, GENMAX);

	l_u[1] = 0;
	r_u[1] = N*GENMAX; // way to pessimistic but for a smoke test

	cerr << A_u << endl;
	cerr << l_u << endl;
	cerr << r_u << endl;

	// l_x und r_x belegen!
	exit(1);

	fout << ext_prec << A_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << A_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << b_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_x << endl;
	fout << ext_prec << endl;

	fout << ext_prec << 1 << endl;
	                   
	fout << ext_prec << endl << "// A_u, A_g, l_u, r_u, b_g, r_x, aardal" << endl;

	fout.close();

	return 0;
}
