#include <fstream> 
#include <sstream> 
#include <cstring>

#include "matrix.h"

#define GEN_MAX 99

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " --M=* --N=* --B=* file.prb");
}

int main(int argc, char *argv[])
{
	char suffix[1024], *ptr;
	long i, j, M = 0, N, B;
	string ostr; 
	
	if (argc != 5) 
		usage(argv[0]);
		
	for (i=1; i<argc; i++) {
		if (strncmp(argv[i], "--M=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> M;
		} else if (strncmp(argv[i], "--N=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> N;
		} else if (strncmp(argv[i], "--B=", 4) == 0) {
			strcpy(suffix, argv[i]+4);
			istringstream iss(suffix, istringstream::in);
			iss >> B;
		} else if (strncmp(argv[i], "-", 1) == 0) 
			usage(argv[0]);
		else 
			ostr = argv[i];
	}

	ptr = strstr(( char *) ostr.c_str(), ".prb");

	if (ptr == NULL)
		usage(argv[0]);
		
	if (*(ptr+4) != 0)
		usage(argv[0]);

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	if (M <= 0)
		ERROR("M has to be > 0");

	if (N < M)
		ERROR("N has to be >= M");

	if (B <= 0)
		ERROR("Generation bound B has to be > 0");

	Matrix<REAL> A_u, A_g;
	Vector<REAL> l_u, r_u, l_x, r_x, x, b_g;

	l_x.resize(N);
	r_x.resize(N);

	x.resize(N);
	A_g.resize(M, N);

	new_seed();

	for (j=1; j<=N; j++) {
		l_x[j] = -B;
		r_x[j] = B;
		x[j] = rand_eq_long(-B, B);
		for (i=1; i<=M; i++) 
			A_g[i][j] = rand_eq_long(-GEN_MAX, GEN_MAX);
	}

	b_g = A_g*x;

	A_u.resize(0);
	l_u.resize(0);
	r_u.resize(0);

	fout << ext_prec << A_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << A_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << b_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_x << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_x << endl;
	fout << ext_prec << endl;

	fout << ext_prec << 1 << endl;
	                   
	fout << endl << "// A_u, A_g, l_u, r_u, b_g, l_x, r_x, aardal" << endl;
	
	fout.close();

	return 0;
}
