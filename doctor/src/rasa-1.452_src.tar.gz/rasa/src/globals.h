#ifndef GLOBALS__H
#define GLOBALS__H

#include "defs.h"

//extern long prec;

/* The global epsilon variable, which stores the minimum difference 
	a REAL value must have before being considered as zero */
extern double epsilon;

extern long sol;
extern long targets;
extern long slk;

extern long prime[PRIMES+1];

#endif
