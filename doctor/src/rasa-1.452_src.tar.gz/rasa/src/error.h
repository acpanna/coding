#ifndef ERROR__H
#define ERROR__H

#include <iostream>
#include <cstdlib>

#define ERROR(x)   { std::cerr << "!!! " << x << " !!!" << std::endl; exit(1); }
#define WARNING(x) { if (VERB == 3) std::cerr << "*** " << x << " ***" << std::endl; }

#endif
