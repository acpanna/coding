#ifndef ZZ__H
#define ZZ__H

#include <vector>
#include <iostream>

#define KARATSUBA 750

typedef std::vector<unsigned short> STL_Vector;

class ZZ : public STL_Vector {

	public: 
		
		ZZ() { push_back(0); sign = true; }
		
		ZZ(int src) { *this = src; }
		ZZ(ZZ const &src);
		ZZ(char const * const src) { *this = src; }
		
		void clear(void) { STL_Vector::clear(); sign = true; }

		ZZ& operator=(int);
		ZZ& operator=(ZZ const &);
		ZZ& operator=(char const * const);
		
		ZZ operator-(void) const;

		ZZ& lshift(size_type const &);
		
		ZZ abs(void) const;
	
		int compare(ZZ const &rts) const;

		static ZZ& add(ZZ const &a, ZZ const &b, ZZ &ret);
		static ZZ& sub(ZZ const &a, ZZ const &b, ZZ &ret);
		static ZZ& mul(ZZ const &a, ZZ const &b, ZZ &ret);
		
		static void div(ZZ const &x, ZZ const &y, ZZ &q, ZZ &r);
		
		static ZZ& pow(ZZ a, ZZ b, ZZ &ret);

		static ZZ& ggT(ZZ const &a, ZZ const &b, ZZ &ret);
		static ZZ& kgV(ZZ const &a, ZZ const &b, ZZ &ret);
		
		static ZZ extended_euclid(ZZ const &a, ZZ const &b, ZZ &s, ZZ &t);
		static ZZ chinese_remainder(ZZ const * const m, ZZ const * const v, 
						register long r);
	private:

		static ZZ& karatsuba_mul(ZZ const &x, ZZ const &y, ZZ &ret);
		static ZZ& schul_mul(ZZ const &x, ZZ const &y, ZZ &ret);

	public:

		/************************************************/
		/* Das Vorzeichen wird in Form einer bool'schen */
		/* Variable gespeichert: "false" entspricht "-" */
		/*   "true" entspricht "+" bzw. vorzeichenlos   */
		/************************************************/
		
		bool sign;
};
		
inline bool operator==(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) == 0); }

inline bool operator!=(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) != 0); }

inline bool operator<(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) < 0); }

inline bool operator<=(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) <= 0); }

inline bool operator>(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) > 0); }

inline bool operator>=(ZZ const &lts, ZZ const &rts)
{ return (lts.compare(rts) >= 0); }

inline ZZ operator+(const ZZ &lts, const ZZ &rts) 
{ ZZ c; return ZZ::add(lts, rts, c); }
		
inline ZZ operator-(const ZZ &lts, const ZZ &rts) 
{ ZZ c; return ZZ::sub(lts, rts, c); }
		
inline ZZ operator*(const ZZ &lts, const ZZ &rts)
{ ZZ c; return ZZ::mul(lts, rts, c); }

inline ZZ operator/(const ZZ &lts, const ZZ &rts) 
{ ZZ q, r; ZZ::div(lts, rts, q, r); return q; }
		
inline ZZ operator%(const ZZ &lts, const ZZ &rts) 
{ ZZ q, r; ZZ::div(lts, rts, q, r); if (r < 0) r = r + rts; return r; }

std::ostream& operator <<(std::ostream&, const ZZ&); 
std::istream& operator >>(std::istream&, ZZ&); 

#endif
