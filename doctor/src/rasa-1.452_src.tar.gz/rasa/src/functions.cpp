#include "functions.h"
#include "globals.h"
#include "error.h"
#include "primes.h"

#include <fcntl.h>
#include <signal.h>
#include <sstream>
#include <cstring>
#include <iomanip>
#include <limits>

using namespace std;

void send_signal(long signal)
{
	if (kill(getpid(), signal) != 0)
		ERROR("Can't send signal (" << signal << ")!");
}

unsigned int new_seed(unsigned int seed) 
{
	if (seed) {
		srand(seed);
		return seed;
	}

	int fd;
	char *str;

	str = new char[128];
	unsigned int *seed_ptr = NULL;

	fd = open("/dev/random", O_RDONLY | O_NONBLOCK);

	if (read(fd, str, sizeof(int)) == sizeof(int)) {
		seed_ptr = (unsigned int *) str;
		srand(*seed_ptr);

	} else {
		close(fd);
		fd = open("/dev/urandom", O_RDONLY | O_NONBLOCK);
		
		if (read(fd, str, sizeof(int)) == sizeof(int)) {
			seed_ptr = (unsigned int *) str;
			srand(*seed_ptr);
		}
	}

	close(fd);
	return (*seed_ptr);
}

void print_time(std::ostream &s, time_t t)
{
   double hh, mm, ss;

   ss = t;

	hh = ss / 3600;
	hh = floor(hh);

   ss = ss - hh*3600;
   
	mm = ss / 60;
	mm = floor(mm);

   ss = ss - mm*60;
   ss = ceil(ss);

   if (hh > 0)
      s << hh << ":";

   if (hh > 0 || mm > 0) {
      if (hh > 0 && mm < 10) s << "0";
      s << mm << ":";
   }

   if ((hh > 0 || mm > 0) && ss < 10)
		s << "0";
  
	s << ss;

	if (hh > 0)
		s << " hour(s):min(s):sec(s) == " << t << " secs";
	else if (mm > 0)
		s << " min(s):sec(s) == " << t << " secs";
	else
		s << " sec(s)";
}

std::ostream &ext_prec(std::ostream &out)
{
	out.unsetf(ios_base::fixed);
	out.unsetf(ios_base::scientific);

	out << std::setprecision(std::numeric_limits<double>::digits10);
	return(out);
}

std::ostream &std_prec(std::ostream &out)
{
	out.unsetf(ios_base::fixed);
	out.unsetf(ios_base::scientific);
	
	out << std::setprecision(4);
	return(out);
}

long min_prime_factor(register long nbr)
{
	if (nbr < 0) 
		nbr = -nbr;

	if (nbr == 0 || nbr == 1)
		return 1;
	
	register long i, min_prm_fact = nbr;

	for (i=0; i<=PRIMES; i++) {
		if (nbr % prime[i] == 0) {
			min_prm_fact = prime[i];
			break;
		}
	}

	if (i > PRIMES) {
		std::cerr << "nbr = " << nbr << std::endl;
		ERROR("globals1: add more primes to primes.h / defs.h");
	}

	if (min_prm_fact == nbr)
		min_prm_fact = prime[0];
	
	return min_prm_fact;
}

long median_prime_factor(register long nbr)
{
	if (nbr < 0) 
		nbr = -nbr;

	if (nbr == 0 || nbr== 1)
		return 1;
	
	register long i, min_prm_fact = nbr, max_prm_fact = nbr;

	for (i=0; i<=PRIMES; i++) {
		if (nbr % prime[i] == 0) {
			min_prm_fact = prime[i];
			break;
		}
	}

	if (i > PRIMES) {
		std::cerr << "nbr = " << nbr << std::endl;
		ERROR("globals2: add more primes to primes.h / defs.h");
	}
	
	if (min_prm_fact == nbr) 
		return nbr; 
	
	for (i=i+1; i<=PRIMES; i++) {
		if (prime[i] > nbr)
			break;

		if (nbr % prime[i] == 0) 
			max_prm_fact = prime[i];
	}

	if (i > PRIMES) {
		std::cerr << "nbr = " << nbr << std::endl;
		ERROR("globals: add more primes to primes.h / defs.h");
	}

	return ((min_prm_fact + max_prm_fact) / 2);
}

long max_prime_factor(register long nbr)
{
	if (nbr < 0)
		nbr = -nbr;

	if (nbr == 0 || nbr == 1)
		return 1;
	
	register long i, max_prm_fact = nbr;

	for (i=0; i<=PRIMES; i++) {
		if (prime[i] > nbr)
			break;

		if (nbr % prime[i] == 0) 
			max_prm_fact = prime[i];
	}

	if (i > PRIMES) {
		std::cerr << "nbr = " << nbr << std::endl;
		ERROR("globals: add more primes to primes.h / defs.h");
	}

	return max_prm_fact;
}

REAL pow2(REAL const &base)
{
	return (base*base);
}

// Erzeugt gleichverteilte 
// ganze Zahlen aus [min, max]
// 		Datentyp: long
long rand_eq_long(register long min, register long max)
{
	if (min > max)
		return 0;
	
 	return (long) (floor(((1.0 + max - min) / (RAND_MAX + 1.0)) * rand()) + min);
}

// Erzeugt gleichverteilte 
// ganze Zahlen aus [min, max]
// 		Datentyp: REAL
REAL rand_eq_real(REAL const &min, REAL const &max)
{
	REAL ret;
	ret = 0;

	if (min > max)
		return ret;
	
	ret = FLOOR(((1.0 + max - min) / (RAND_MAX + 1.0)) * rand());

	return (ret + min);
}

// Erzeugt normalverteilte reelle Zahlen,
// mit Zentrum (bzw. Erwartungswert) µ = 0.5 
// und Streuung (bzw. Varianz) (sigma)^2 = 1
double rand_norm(void) 
{
	double n1, n2, p, q, x1, x2;

	do {
		// x1, x2 sind gleichverteilt im Intervall [0, 1]
		x1 = ((double) rand()) / ((double) RAND_MAX); 
		x2 = ((double) rand()) / ((double) RAND_MAX); 

		q = (2*x1 - 1)*(2*x1 - 1) + (2*x2 - 1)*(2*x2 - 1);

	} while (q > 1);

	p = SQRT((-2*LOG(q)) / q);

	n1 = (2*x1 - 1)*p;
	n2 = (2*x2 - 1)*p;

	n1 += 0.5;
	n2 += 0.5;

/*
	// An den Intervallgrenzen
	// abschneiden
	
	if (n1 < 0 || n1 > 1) {
		if (n2 < 0 || n2 > 1)
			return rand_norm();
		else
			n1 = n2;
	}
*/
	if (rand_eq_long(0, 1))
		n1 = n2; 
	
	return n1;
}

// Erzeugt normalverteilte reelle Zahlen,
// mit dem Zentrum: min + ((max-min) / 2)
// und einer Streuung von: max-min
REAL rand_norm(REAL const &min, REAL const &max)
{
	REAL r;
	r = rand_norm();

	r *= (max - min);
	r += min;

	// An den Intervallgrenzen
	// abschneiden
	
	r = FMIN(r, max);
	r = FMAX(min, r);

	return r;
}

REAL ggT(REAL const &x, REAL const &y)
{	
	REAL a, b, ret;
	
	a = ABS(x);
	b = ABS(y);
	
	while (b != 0) {
		ret = a - (FLOOR(a/b) * b);

		a = b;
		b = ret;
	}

	ret = a;
	return ret;
}

REAL kgV(REAL const &x, REAL const &y)
{	
	return ((x*y) / ggT(x, y)); 
}

REAL modulo(REAL const &value, REAL const &modul) 
{
	REAL ret;

	ret = value - (FLOOR(value / modul) * modul);

	if (ret < 0)
		ret += modul;

	return ret;
}

REAL extended_euclid(REAL const &a, REAL const &b, REAL &s, REAL &t)
{
	REAL d, dd, ss, tt;

	if (ABS(b) < epsilon) {
		s = 1;
		t = 0;

		return a;
	}

	dd = extended_euclid(b, modulo(a, b), ss, tt);
	
	d = dd;
	s = tt;
	t = ss - FLOOR(a / b) * tt;

	return d;
}


