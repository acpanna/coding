#ifndef MATRIX__H
#define MATRIX__H

#include "polynom.h"
#include "zz.h"

template <typename DATATYPE>
class Matrix {

	public:
		Matrix();
		Matrix(register long m, register long n = 0);
		Matrix(register long m, register long n, 
				DATATYPE const * const * const matrix);

		Matrix(Matrix const &ref);
		~Matrix(); 

		void resize(register long m, register long n = 0);

		Matrix const & operator= (Matrix const &ref);
		Matrix const & operator+=(Matrix const &ref);
		Matrix const & operator-=(Matrix const &ref);
		
		Matrix const & operator*=(DATATYPE const &ref);
		Matrix const & operator*=(Matrix const &ref);

		Vector<DATATYPE> const & operator*=(Vector<DATATYPE> const &ref);
		
		Matrix const & operator/=(DATATYPE const &ref);
		
		Matrix operator+(Matrix const &ref) const;
		Matrix operator-(Matrix const &ref) const;
		
		Matrix operator*(DATATYPE const &ref) const;
		Matrix operator*(Matrix const &ref) const;

		Matrix operator%(DATATYPE const &modul) const;
		
		Vector<DATATYPE> operator*(Vector<DATATYPE> const &ref) const;
		
		Vector<DATATYPE> & operator[] (register long j) const;

		bool operator==(Matrix const &ref) const;
		bool operator!=(Matrix const &ref) const;

		void swap(register long i, register long j);
		void clear();

		void make_zero(register long m = 0);
		void make_one(register long m = 0);

		void blockmatrix_AD(Matrix<DATATYPE> const &A, 
				Matrix<DATATYPE> const &D);

		Matrix normalize(void) const;
		Matrix transpose(void) const;

		Matrix round(DATATYPE eps = 0) const;

		Matrix inverse(void) const;

		Matrix rows(register long k, register long m) const;
		Matrix cols(register long l, register long n) const;

		ZZ modular_determinant(void);

		long rank(void) const;

		bool simplex(Vector<DATATYPE> const &b,
			Vector<DATATYPE> const &c, Vector<DATATYPE> &x) const;

		bool simplex_with_equations(Vector<DATATYPE> const &b,
			Vector<DATATYPE> const &c, Vector<DATATYPE> &x) const;

		bool zeilenstufenform(Matrix<DATATYPE> &L);

		long normierte_zeilenstufenform(Matrix<DATATYPE> &S,
			Matrix<DATATYPE> &L, Vector<long> &pivot);

		bool compute_x0(Vector<DATATYPE> &x0, 
				Matrix<DATATYPE> const &L, Vector<long> const &pivot, 
				Vector<DATATYPE> const &b) const;

		bool solve(Matrix<DATATYPE> &S, Vector<DATATYPE> &x0, 
				Vector<DATATYPE> const &b) const;

		long gauss(Matrix<DATATYPE> &L, Matrix<DATATYPE> &R, 
				Vector<long> &pmt) const;
		
		void house(register long j, Vector<DATATYPE> &v, DATATYPE &beta); 
		
		void qr(Matrix<DATATYPE> &Q, Matrix<DATATYPE> &R) const;
		
		void compute_qr(Matrix<DATATYPE> &Q, Matrix<DATATYPE> &R) const;
		void compute_qr_pmatrix(Matrix<DATATYPE> &P, register long j) const;
		
		Polynom<DATATYPE> characteristic_polynom(void) const;
		
		DATATYPE determinant(void) const;


		bool overflow(void) const;


		template <typename DATATYPE_FRIEND>
		friend std::istream& operator>> (std::istream &i, 
				Matrix<DATATYPE_FRIEND> &ref);

		template <typename DATATYPE_FRIEND>
		friend std::ostream& operator<< (std::ostream &o, 
				Matrix<DATATYPE_FRIEND> const &ref); 

	private:
		long modular_gauss(ZZ const * const * T, ZZ const &modul, 
			ZZ ** const L, ZZ ** const R, bool &sign);

		ZZ modular_determinant(ZZ const * const * const T, register long n);

		void simplex_ph2(Vector<DATATYPE> const &c, Vector<DATATYPE> &x) const;

	public:
		long M;
		long N;

	private:
		Vector<DATATYPE> *row;
};

template <typename DATATYPE>
short compute_coords(Matrix<DATATYPE> const &L, 
	Matrix<DATATYPE> const &R, Vector<long> const &pmt, 
	Vector<DATATYPE> const &b, Vector<DATATYPE> &x,	
	bool regular, bool integer = true);

#include "matrix.cpp"

#endif
