#include "globals.h"

double epsilon = 1.0 / LOOP_LIMIT;

long sol = 1;
long targets = 0;
long slk = -1;
