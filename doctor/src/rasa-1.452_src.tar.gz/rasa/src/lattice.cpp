#include <sstream>
#include <cfloat>
#include <cmath>

using namespace std;

template <typename REAL>
Lattice<REAL> const & 
Lattice<REAL>::operator=(Matrix<REAL> const &lat_mat)
{
	B = B_curr = lat_mat;
	
	M = B.M;
	N = B.N;
	
	T.make_one(M);
	
	resize(M, N);
	
	check_lbnd.make_zero(N);
	check_ubnd.make_zero(N);
	check_anz0.make_zero(N);
	
	check_c.make_zero(targets);

	sym_bnds = true;

	return *this;
}

template <typename REAL>
void Lattice<REAL>::resize(register long m, register long n)
{
	if (m <= 0 || n < 0)
		ERROR("invalid size");
	
	if (n == 0) 
		n = N;
	
	B_curr.resize(m, n);
	B.resize(m, n);

	if (m > T.M)
		T.resize(m, m); 

	mu.resize(m, n); 

	Bdach.resize(m, n);
	Bgram.resize(m, m);

	b.resize(m);
	c.resize(m);
	
	stage.resize(m+1);
	
	Btilda.resize(m+1, n);
	
	check_lbnd.resize(n); 
	check_ubnd.resize(n);
	check_anz0.resize(n);
	
	check_c.resize(targets);
	
	M = m;

	if (n > 0)
		N = n;
}

template <typename REAL>
Lattice<REAL>::Lattice(void)
{
	init();
}

template <typename REAL>
Lattice<REAL>::Lattice(Matrix<REAL> const &lat_mat, long verbose)
{
	init();
	*this = lat_mat;
	VERB = verbose;
}

template <typename REAL>
Lattice<REAL>::~Lattice() 
{ 
	if (solution)
		delete [] solution;

	solution = 0;
}

template <typename REAL>
void Lattice<REAL>::init(void)
{
	create_time = time(NULL);

	nrm_file = "";
	map_file = "";

	params = "";
	
	dbase_str = "";

	VERB = 3;
	BTIME = 0;
	
	TRANS = true;

	ALPHA = 0.5;
	DELTA = 0.75;

	BETA = 20;
	DEEP = 0;

	EPRUNE = 0;
	EENUM = 0;
	
	SCALE = false;

	PWR = true;
	SIEVE = -1;

	GSA = 0;
	PRJ = false;
	SLIMIT = 0;

	iters = 0;
	ineq = 0;
	
	M = 0;
	N = 0;

	S = 0;

	B_curr = 0;
	B = 0;

	T = 0;
	TT = 0;

	mu = 0;
	Bdach = 0;
	Bgram = 0;
	Btilda = 0;
	
	b = 0;
	c = 0;
	
	stage = 0;
	 
	scale_factor = 1;

	check_lbnd = 0;
	check_ubnd = 0;
	check_anz0 = 0;
	
	check_c = 0;
	
	sym_bnds = true;

	best_heu_abw = -1;
	best_heu_norm = 0;
	best_heu = 0;

	best_slk_abw = -1;

	solution = 0;

	b_min_idx = 0;
	b_max_idx = 0;
	c_min_idx = 0;
	c_max_idx = 0;
	
	b_min = TO_REAL(0);
	b_max = TO_REAL(0);
	c_min = TO_REAL(0);
	c_max = TO_REAL(0);

	triv_sub = 0;
	ntriv_sub = 0;

	deep_cnt = 0;
	pair_cnt = 0;
	short_cnt = 0;
	eshort_cnt = 0;

	heu_improve = 0;
	slk_improve = 0;
	
	heu_update = false;
	
	abw_fptr = &Lattice::def_chk_abw; 
}

template <typename REAL>
void Lattice<REAL>::init_params(string dbase, register long verbose, 
		register long btime, register bool trans, register double alpha, 
		register double delta, register long beta, register long deep, 
		register long eprune, register long eenum,  
		register bool pwr, register long sieve, register long heu, 
		register long gsa, register bool prj, register long slimit)
{
	dbase_str = dbase;

	if (verbose > 3 || verbose < 0)
		ERROR("--verbose=[0,1,2,3]");

	VERB = verbose;

	BTIME = btime;
	TRANS = trans;

	ALPHA = alpha;
	DELTA = delta;

	BETA = beta;
	DEEP = deep;

	if (eprune > 3 || eprune < 0)
		ERROR("--eprune=[0,1,2,3]");
	EPRUNE = eprune;

	EENUM = eenum;
	
	PWR = pwr;

	if (sieve != -1)
		SIEVE = sieve_set.elements_max = sieve; 

	GSA = gsa;
	PRJ = prj;

	SLIMIT = slimit;

	/*
		The heuristic function switch
													*/
	if (heu == 0)
		abw_fptr = &Lattice::def_chk_abw; 
	else if (heu == 1)
		abw_fptr = &Lattice::anz_chk_abw; 
	else if (heu == 2)
		abw_fptr = &Lattice::max_chk_abw;
	else if (heu == 3)
		abw_fptr = &Lattice::all_chk_abw;
	else
		ERROR("--heu=[0,1,2,3]");
}

template <typename REAL>
void Lattice<REAL>::swap(register long i, register long j)
{
	if (i != j) {
		B_curr.swap(i, j);

		if (TRANS)
			T.swap(i, j);

		mu.swap(i, j);

		b.swap(i, j);
		c.swap(i, j);
	}
}

template <typename REAL>
void Lattice<REAL>::check_trans(void)
{
	register long i, j;
	bool transform_error = true;

	REAL det;

	/***********************************************/
	/* T is the transformation matrix,             */
	/* which maps the originating basis matrix (B) */
	/* to the current basis matrix (B_curr).       */
	/***********************************************/
	
	if (TRANS) {

		/***************************************/
		/*                                     */
		/* In several tests it is ensured that */
		/* the transformation T is unimodular. */
		/*                                     */
		/***************************************/

		det = ABS(T.determinant());
		if (ABS(ABS(det) - 1) <= 0.4) { 	// T should have an integer determinant,
			transform_error = false;		// hence <= 0.4 should be sufficient ...

		} else {

			Matrix<REAL> T2;
			T2 = T;

			for (i=1; i<=T2.M; i++)
				for (j=i+1; j<=T2.M; j++)
					if (T2[j].quad_euklid_norm() > T2[i].quad_euklid_norm())
						T2.swap(i, j);

			det = ABS(T2.determinant());
			if (ABS(ABS(det) - 1) <= 0.4) {
				transform_error = false;

			} else {

				for (i=1; i<=T2.M; i++)
					for (j=i+1; j<=T2.M; j++)
						if (T2[j].quad_euklid_norm() < T2[i].quad_euklid_norm())
							T2.swap(i, j);

				det = ABS(T2.determinant());
				if (ABS(ABS(det) - 1) <= 0.4) {
					transform_error = false;

				} else {

					Matrix<REAL> Q, R;
					T.qr(Q, R);

					det = 1;
					for (i=1; i<=R.M; i++)
						det *= R[i][i];

					if (ABS(ABS(det) - 1) <= 0.4) {
						transform_error = false;
					} 

				} 
			}
		}

		if (transform_error) {

			WARNING("Unimodular transformation error detected -- det T = " << det)

			// In the worst case there is no transformation matrix 
			// stored on the stack. The current basis matrix has to be 
			// reinitialized with the original one.

			if (TT.N == 0 || TT.N == 1) 
				B_curr = B;
			else {

				// Fetch the last known (correct) 
				// transformation from the stack.

				B_curr = TT[TT.N-1]*B;
				B = B_curr;
			}
				
			T.make_one(M);
		}

		/**************************************************/
		/*																  */
		/* If we get to this point, the transformation is */ 
		/* 			correct and unimodular.               */
		/*																  */
		/**************************************************/

		for (i=1; i<=T.M; i++) {
			for (j=1; j<=T.M; j++) {
				if (ABS(T[i][j]) > T_MAX_VAL) {

					WARNING("Transformation overflow detected")

					if (TT.N == 0) 
						TT.resize(TT.N + 1);
					
					TT[TT.N] = T;

					B_curr = T*B;
					B = B_curr;

					TT.resize(TT.N + 1);
					T.make_one(M);

					break;
				}
			}

			if (j <= T.M) // Test for break within the j-loop
				break;
		}

		if (TT.N > T_MATRIX_NUMBER) {
			ERROR("TT.N > T_MATRIX_NUMBER");
		}

		/********************************************/
		/* The current basis matrix gets recomputed */
		/*     and is (eventually) rescaled         */
		/********************************************/

		Matrix<REAL> BB;
		BB = T * B;
		if (BB != B_curr) 
			WARNING("Transformation error detected")
		B_curr = BB;

		if (SCALE)
			for (i=1; i<=M; i++)
				B_curr[i][N] *= scale_factor;

		//////////////////////////////////////////////

		if (TT.N == 0) 
			TT.resize(TT.N + 1);

		TT[TT.N] = T;
	}

	write_map();
}

template <typename REAL>
void Lattice<REAL>::print_stats(void)
{	
	register long i;

	REAL defect;
	REAL b_curr, b_mean, c_curr, c_mean;
	
	check_trans();
	compute_lengths();
	write_nrm();

	if (VERB) {
		cerr << endl;
		cerr << "---------------------------- Some statistics -----------------------------" << endl;
	}

	b_mean = b[1] / M; 
	c_mean = c[1] / M;

	defect = (LOG(b[1]) - LOG(c[1]));

	for (i=2; i<=M; i++) {
		b_curr = b[i];
		b_mean += (b_curr / M);

		c_curr = c[i];
		c_mean += (c_curr / M);

		defect += (LOG((b[i])) - LOG(c_curr));
	}

	if (VERB) {
		cerr << std_prec;
		cerr << "\nShortest base vector: ";
		cerr << "||b_" << b_min_idx << "||² = " << b_min;
		cerr << "\nLongest base vector: ";
		cerr << "||b_" << b_max_idx << "||² = " << b_max;
		cerr << endl;
		cerr << "\nShortest orthogonal vector: ";
		cerr << "||PI_" << c_min_idx << "(b_" << c_min_idx << ")||² = " << c_min;
		cerr << "\nLongest orthogonal vector: ";
		cerr << "||PI_" << c_max_idx << "(b_" << c_max_idx << ")||² = " << c_max;
		cerr << endl;
		cerr << endl;
		cerr << "Mean base vector length: " << b_mean << endl;
		cerr << "Mean orthogonal vector length: " << c_mean << endl;
		cerr << endl;
		cerr << "Logarithmic orthogonal defect: " << defect << endl;
		cerr << endl;
		cerr << "Transformation matrices: " << TT.N << endl;
		cerr << endl;
		cerr << "Deep insertions: " << deep_cnt << endl;
		cerr << "Pairwise reductions: " << pair_cnt << endl;
		cerr << "Heuristic improvements: " << heu_improve << endl;

		if (SIEVE != -1)
			cerr << "Remaining sieve vectors: " << sieve_set.elements << endl;

		if (ineq) 
			cerr << "Slack improvements: " << slk_improve << endl;

		cerr << endl;
		cerr << "Sampling insertions (short / eshort): ";
		cerr << "( " << short_cnt << " / " << eshort_cnt << " )" << endl;
		cerr << endl;
		cerr << "Basis substitutions (triv / ntriv): ";
		cerr << "( " << triv_sub << " / " << ntriv_sub << " )" << endl; 
	}

	if (VERB) {
		
		print_sol();

		cerr << endl;
		cerr << "--------------------------------------------------------------------------" << endl;
	}
}

template <typename REAL>
void Lattice<REAL>::print_best_heu(void)
{
	cerr << std_prec << endl;
	cerr << "H(best_heu) = " << best_heu_abw;
//	cerr << ", || best_heu ||_2 = " << best_heu_norm;

	if (best_heu_abw != -1) {
		cerr << " -- [ ";
		print_time(cerr, best_heu.time);
		cerr << " ]";
	}
}

template <typename REAL>
void Lattice<REAL>::print_best_slk(void)
{
	cerr << std_prec << endl;
	cerr << "S(best_slk) = " << best_slk_abw;
	
	if (best_slk_abw != -1) {
		cerr << " -- [ ";
		print_time(cerr, best_slk.time);
		cerr << " ]";
	}
}

template <typename REAL>
void Lattice<REAL>::print_sol(void)
{
	print_best_heu();

	if (ineq) 
		print_best_slk();
		
	cerr << endl;

	if (S > 0) {
		cerr << endl;
		cerr << "Solutions found: " << S << endl;
		cerr << endl;
		cerr << "[ The first solution/s was/were found after: ";

		for (long i=0; i<LMIN(3, S); i++) {
			print_time(cerr, solution[i].time);
			cerr << " ";
		}

		cerr << "]" << endl;
	}
}

template <typename REAL>
void Lattice<REAL>::write_nrm(void)
{
	register long i;
	ofstream fout(nrm_file.c_str());

	fout << ext_prec << "yC <- c( ";
	for (i=1; i<=M; i++) {
		if (i > 1) fout << ext_prec << ", ";
		fout << ext_prec << c[i];
	}

	fout << ext_prec << ") " << endl;
	fout << ext_prec << "yB <- c( ";

	for (i=1; i<=M; i++) {
		if (i > 1) fout << ext_prec << ", ";
		fout << ext_prec << b[i];
	}

	fout << ext_prec << ") " << endl;
	fout.close();
}

template <typename REAL>
void Lattice<REAL>::write_map(void)
{
	register long i, j;
	ofstream fout(map_file.c_str());

	Matrix<REAL> *B_tmp = 0;

	if (SCALE) {
		B_tmp = new Matrix<REAL>(M, N);

		for (i=1; i<=M; i++) { 
			(*B_tmp)[i] = B_curr[i];
			(*B_tmp)[i][N] /= scale_factor;
		}

	} else
		B_tmp = &B_curr;

	for (i=1; i<=B_tmp->M; i++)
		for (j=1; j<=B_tmp->N; j++)
			if (ABS((*B_tmp)[i][j]) < epsilon)
				(*B_tmp)[i][j] = 0;

	fout << ext_prec << params << endl;
	fout << endl;

	fout << ext_prec << (*B_tmp) << endl;
	fout << endl;

	if (SCALE)
		delete B_tmp;

	if (TRANS)
		fout << ext_prec << TT << endl; 
	else
		fout << "[ ]" << endl; 

	fout << endl;
	fout << ext_prec << best_heu << " -- " << best_heu_norm << endl;
	fout << ext_prec << best_slk << " -- " << best_slk_abw << endl;

	if (S > 0)  {
		fout << endl;
		for (i=0; i<S; i++) 
			fout << ext_prec << solution[i] << endl;
	} 

	fout.close();
}

/*
	This function adds a new solution to the pool of
	already found solutions and takes care that there
	are no double entries.
*/
template <typename REAL>
void Lattice<REAL>::new_solution(Vector<REAL> const &ref)
{
	register long j;
	Vector<REAL> tmp(ref);
	Solution<REAL> *tmp_solution;

	check_trans(); // At first have to check if everything is alright, 
	// before a solution for an incorrect transformation gets written.
	
	if (SCALE)
		tmp[N] /= scale_factor;

	for (j=0; j<S; j++) 
		if (tmp.is_abs_equal((Vector<REAL>) solution[j]))
			return;
	S++;
	tmp_solution = solution;
	solution = new Solution<REAL>[S];
	for (j=0; j<S-1; j++) 
		solution[j] = tmp_solution[j];
	
	if (tmp_solution)
		delete [] tmp_solution;

	solution[S-1] = tmp;
	solution[S-1].time = time(NULL) - create_time;

	if (S == 1 && dbase_str != "")
		dbase_commit();
	
	write_map(); // normally a check_trans should be called at first,
	// to ensure that the solution belongs to a valid transformation,
	// but well ... solutions are more important ...

	if (sol > 0 && S == sol) 
		send_signal(15);
}

/*
	The QR-decomposition of the 
	base matrix is done in here.
*/
template <typename REAL>
void Lattice<REAL>::compute_gs_qr(register long k, register long m) 
{
	register long i, j;

	Matrix<REAL> A, Q, R;

	if (k == 0)
		k = 1;
	if (m == 0)
		m = M;

	A.resize(N, m-k+1);
	for (i=1; i<=A.M; i++)
		for (j=1; j<=A.N; j++)
			A[i][j] = B_curr[j+k-1][i];
	
	A.qr(Q, R);

	for (i=1; i<=Q.M; i++) 
		for (j=1; j<=Q.N; j++) 
			Q[i][j] *= R[j][j];
	
	for (i=1; i<=R.M; i++) {
		for (j=i+1; j<=R.N; j++) 
			R[i][j] /= R[i][i];
		
		R[i][i] = 1;
	}

	Bdach.resize(M, N);
	mu.resize(M, M);

	for (i=k; i<=m; i++) {
		for (j=1; j<=N; j++)
			Bdach[i][j] = Q[j][i-k+1];

		for (j=k; j<=m; j++)
			mu[i][j] = R[j-k+1][i-k+1];
	}

	for (i=k; i<=m; i++) {
		c[i] = Bdach[i].quad_euklid_norm();
		Bgram[i][i] = B_curr[i] * B_curr[i];
	}
}

/*
	The euclidean lengths of 
	the (orthogonal) base 
	vectors are computed here.
*/
template <typename REAL>
void Lattice<REAL>::compute_lengths(register long k, register long m)
{
	register long i;

	if (k == 0)
		k = 1;
	if (m == 0)
		m = M;
	
	b_min = 0;
	b_max = 0;
	c_min = 0;
	c_max = 0;

	compute_gs_qr(k, m);

	for (i=k; i<=m; i++) {

		b[i] = B_curr[i].quad_euklid_norm();
			
		if (b[i] < b_min || b_min == 0) {
			b_min_idx = i;
			b_min = b[i];
		}
		
		if (b[i] > b_max) {
			b_max_idx = i;
			b_max = b[i];
		}
			
		if (c[i] < c_min || c_min == 0) {
			c_min_idx = i;
			c_min = c[i];
		}
		
		if (c[i] > c_max) {
			c_max_idx = i;
			c_max = c[i];
		}
	}
}

template <typename REAL>
void Lattice<REAL>::variate(void)
{
	register long idx = 0;

	if (VERB >= 2)
		cerr << ext_prec << "-> Variating base vectors ... " << endl;

	if (variate_sol()) 
		return;

	if (idx == 0) {

		if (rand_eq_long(0, 1))
			sort();
		else
			shuffle();

		return;
	}
}

template <typename REAL>
bool Lattice<REAL>::variate_sol(void)
{
	static long curr_sol = 0;

	if (S > 0 && curr_sol < S)  {

		register long i, idx = 0;
		
		Vector<REAL> coord, vec;
		vec = solution[curr_sol];

		if (SCALE)
			vec[N] *= scale_factor;

		for (i=1; i<=M; i++)
			if (ABS(B_curr[i][N]) == vec[N])
				idx = ((rand_eq_long(0, idx) > 0) ? idx : i);

		if (idx == 0) 
			return false;

		swap(idx, M);

		if (!compute_lat_coords(vec, coord))
			ERROR("variate: could not compute integer coords!");

		if (ABS(coord[M]) == 1) { 

			if (VERB >= 2)
				cerr << "-> Variating base vector (" << idx << ") ..." << endl;

			if (TRANS) {
				T[M] *= coord[M];
				for (i=1; i<M; i++)
					T[M] += T[i]*coord[i];
			}

			B_curr[M] = vec;
			curr_sol++;

		} else
			return false;

		return true;

	} else 
		return false;
}

template <typename REAL>
void Lattice<REAL>::shuffle(void)
{
	register long i, j, k;
	
	static long curr_shf = 0;
	curr_shf++;

	if (VERB >= 2) {
		cerr << "-> Shuffling base vectors ";
		cerr << "( " << curr_shf << " shuffle(s) ) ..." << endl;
	}

	for (k=1; k<curr_shf; k++) {

		i = rand_eq_long(1, M);
		j = rand_eq_long(1, M);

		swap(i, j);
	}
}

/*
	Heuristically sort the basis, such that:
		H(B[1]) <= H(B[2]) <= ... <= H(B[m])
*/
template <typename REAL>
void Lattice<REAL>::sort(bool euklid)
{
	bool sorted = false;
	register long i, j;

	Vector<REAL> hb;
	hb.resize(M);

	if (euklid) {
		for (i=1; i<=M; i++)
			hb[i] = B_curr[i].quad_euklid_norm();

	} else {

		if (VERB >= 2)
			cerr << "-> Heuristic Sorting ... " << endl;
	
		for (i=1; i<=M; i++)
			hb[i] = (this->*abw_fptr)(B_curr[i]);
	}
	
	while (!sorted) {
		sorted = true;

		for (i=1; i<M; i++) {
			for (j=i+1; j<=M; j++) {

				if (hb[j] < hb[i]) {
					hb.swap(i, j);
					swap(i, j);
					sorted = false;
				}
			}
		}
	}
}

/*
 	Locate the base vector with the best
	heuristic deviation and put it at the end
	of the basis
*/
template <typename REAL>
void Lattice<REAL>::shortest_heu_to_end(void)
{
	register long i, idx;
	REAL hd, min;

	idx = 1;
	min = (this->*abw_fptr)(B_curr[1]);

	for (i=2; i<=M; i++) {
		hd = (this->*abw_fptr)(B_curr[i]);

		if (hd < min) {
			idx = i;
			min = hd;
		}
	}

	swap(idx, M);
}

/*
 	Locate the shortest base vector
	and put it at the front of the basis
*/
template <typename REAL>
void Lattice<REAL>::shortest_euklid_to_start(void)
{
	register long i, idx;
	REAL hd, min;

	idx = 1;
	min = B_curr[1].quad_euklid_norm();

	for (i=2; i<=M; i++) {
		hd = B_curr[i].quad_euklid_norm();

		if (hd < min) {
			idx = i;
			min = hd;
		}
	}

	swap(idx, 1);
}

template <typename REAL>
void Lattice<REAL>::check_solution(void)
{
	register long i;

	for (i=1; i<=M; i++) 
		check_solution(i);
}

template <typename REAL>
void Lattice<REAL>::check_solution(register long i)
{
	check_solution(B_curr[i]);
}

template <typename REAL>
void Lattice<REAL>::check_solution(Vector<REAL> const &coord, 
		register long jj,	register long kk)
{
	register long i;
	Vector<REAL> lat_vec;

	lat_vec = B_curr[jj] * coord[jj];
	
	for (i=jj+1; i<=kk; i++)
		lat_vec += B_curr[i] * coord[i];
	
	check_solution(lat_vec);
}

template <typename REAL>
bool Lattice<REAL>::check_solution(Vector<REAL> &ref)
{
	bool ret = false;
	register long i, j;
	
	if (!ref.is_zero()) { 
	
		bool try_negative;
		Vector<REAL> *vec;
		
		for (i=1; i<=2; i++) {

			try_negative = false;

			if (i == 1) 
				vec = &ref;
			else {
				vec = new Vector<REAL>;
				*vec = -ref;
			}

			for (j=targets+1; j<=N; j++) {

				if (check_anz0[j] != 0 && (*vec)[j] == 0) {
					check_best_heu(*vec);
					if (i == 2)  {
						delete vec;
					}
					return ret;
				}

				if ((*vec)[j] < check_lbnd[j] || (*vec)[j] > check_ubnd[j]) {
					check_best_heu(*vec);
					try_negative = true;
					break;
				}
			}

			if (try_negative) 
				continue;

			if (slk >= 0) 
				check_best_slk(*vec);

			for (j=1; j<=targets; j++) {

				if (check_anz0[j] != 0 && (*vec)[j] == 0) {
					check_best_heu(*vec);
					if (i == 2)  {
						delete vec;
					}
					return ret;
				}

				if ((*vec)[j] < check_lbnd[j] || (*vec)[j] > check_ubnd[j]) {
					check_best_heu(*vec);
					try_negative = true;
					break;
				}
			}
			
			if (try_negative) 
				continue;

			new_solution(*vec);
			check_best_heu(*vec);

			ret = true;
			break;
		}

		if (i >= 2)
			delete vec;
	}

	return ret;
}

template <typename REAL>
bool Lattice<REAL>::check_best_heu(register long i)
{
	return check_best_heu(B_curr[i]);
}

template <typename REAL>
bool Lattice<REAL>::check_best_heu(Vector<REAL> &ref) 
{
	REAL abw;

	abw = (this->*abw_fptr)(ref);

	if ((best_heu_abw == -1 || abw <= best_heu_abw)) {

		best_heu = ref;

		if (SCALE)
			best_heu[N] /= scale_factor;

		if (best_heu_abw == -1 || abw < best_heu_abw) {
			best_heu.time = time(NULL) - create_time;
			heu_update = true; // wegen best_heu_insert
		}

		best_heu_abw = abw;
		best_heu_norm = SQRT(best_heu.quad_euklid_norm());

		heu_improve++;

		if (SIEVE != -1) 
			sieve_set.insert(best_heu); 

		return true;
	}

	return false;
}

template <typename REAL>
bool Lattice<REAL>::check_best_slk(Vector<REAL> const &ref)
{
	REAL abw;
	abw = slk_abw(ref);

	if (best_slk_abw == -1 || abw <= best_slk_abw) {
		
		best_slk = ref;

		if (SCALE)
			best_slk[N] /= scale_factor;

		if (best_slk_abw == -1 || abw < best_slk_abw) {
			best_slk.time = time(NULL) - create_time;
				
			best_slk_abw = abw;

			if (dbase_str != "")
				dbase_commit();
		}

		slk_improve++;

		if (SIEVE != -1) 
			sieve_set.insert(best_slk); 

		if (best_slk_abw <= slk) {

			if (best_slk_abw == 0)
				new_solution(ref);
	
			else {
				
				write_map(); // normally a check_trans should be called at first,
				// to ensure that the solution belongs to a valid transformation,
				// but well ... solutions are more important ...
				
				send_signal(15);
			}
		}

		return true;
	}

	return false;
}

/*
	The first "ineq" lattice components reflect inequations 
	for the underlying linear problem. 

	This function computes how much these inequations are "injured".

	For this we have to know:
		s_i := MAX(0, (l_u - A_u*x)_i , (A_u*x - r_u)_i) for i = 1,2,...,ineq 

	If y is a lattice vector it looks like this:
		y = (2*A_u*x - (l_u + r_u), ...)
		     ---------------------
			         =: y'

	Via prb2lat we get: check_ubnd = r_u - l_u

	So in order to compute s_i, we have to:
		
	a) 1. Subtract check_ubnd from y':
			==> 2*A_u*x - 2*r_u 	
		2. Divide by 2
			==> A_u*x - r_u

	b) 1. Add check_ubnd to y':
			==> 2*A_u*x - 2*l_u
		2. Divide by 2
			==> A_u*x - l_u
		3. Negate
		   ==> l_u - A_u*x
	 
	See chapters 1.4.1 / 5.3 of the dissertation for further details.
*/
template <typename REAL>
REAL Lattice<REAL>::slk_abw(Vector<REAL> const &vec)
{
	register long j;
	REAL abw, t1, t2;

	abw = 0;
	
	for (j=1; j<=targets; j++) {
		t1 = (vec[j] - check_ubnd[j]) / (2 * check_c[j]);
		t2 = -(vec[j] + check_ubnd[j]) / (2 * check_c[j]);

		abw += (FMAX(TO_REAL(0), FMAX(t1, t2)));
	}

	return abw;
}

template <typename REAL>
long Lattice<REAL>::rank(void) const
{
/*
	Vector<long> pmt;
	Matrix<REAL> L, R;

	return B_curr.transpose().gauss(L, R, pmt);
*/
	return B_curr.rank();
}

/* 
	Compute the integer coords for a lattice vector, 
		such that: vector = (B_curr)^T * coord
*/
template <typename REAL>
bool Lattice<REAL>::compute_lat_coords(Vector<REAL> const &vector, 
		Vector<REAL> &coord)
{
	bool status;

	Matrix<REAL> A, L, S;
	Vector<long> pivot;
	
	A = B_curr.transpose();
	status = A.solve(S, coord, vector);

	if (status) 
		status = coord.cmake_integer();
	else
		WARNING("compute_lat_coords: system is not solvable")

	return status;
}

template <typename REAL>
void Lattice<REAL>::compute_bdach(register long k, 
		register long m)
{
	register long i, j;

	for (i=k; i<=m; i++) {
		Bdach[i] = B_curr[i];
		
		for (j=1; j<i; j++)
			Bdach[i] -= Bdach[j]*mu[i][j];
	}
}

/* 
	This functions computes the k-th dual base vector 
*/
template <typename REAL>
void Lattice<REAL>::compute_bstar(Lattice &dual_lat, 
		register long k, register long m) 
{
	register long i, j;

	Matrix<REAL> Rt;
	Vector<REAL> x;

	/************************************************************************/
	/*                             														*/
	/* 	We have B = B_dach * mu^T = 													*/
	/*																								*/
	/*						  [ 1 / ||B_dach[1]||_2			 ]								*/
	/* 		= B_dach * [			...	 		 		 ]								*/
	/* 					  [			1 / ||Bdach[m]||_2 ]								*/
	/*																								*/
	/*										[ ||B_dach[1]||_2					 ]				*/
	/* 								* 	[				...					 ]	* mu^T	*/
	/*										[					||B_dach[m]||_2 ]				*/
	/*																								*/
	/*			= Q * R <==> Q = B * R^(-1)												*/
	/*																								*/
	/*		And for the dual base we have:												*/
	/*																								*/
	/*			B_dual = Q * (R^(-1))^T = B * R^(-1) * (R^(-1))^T					*/
	/* 	<==> B_dual[k] = B_dual * e_k = B * R^(-1) * (R^(-1))^T * e_k		*/
	/*																								*/
	/* 	So in order to easily compute B_dual[k] the equation system			*/
	/*																								*/
	/*			x = R^(-1) * (R^(-1))^T * e_k <==> R^T * R * x = e_k				*/
	/*																								*/
	/*		has to be solved.																	*/
	/*																								*/
	/*		And so we get: 																	*/
	/*									B_dual[k] = B * x 									*/
	/*																							   */
	/************************************************************************/

	Rt.resize(m, m);

	for (i=1; i<=m; i++) {
		for (j=1; j<i; j++)  
			Rt[i][j] = mu[i][j] * SQRT(c[j]); 
		Rt[i][i] = SQRT(c[i]);
	}

	for (i=1; i<=m; i++) 
		for (j=i+1; j<=m; j++) 
			Rt[i][j] = 0.0;
#if 0
	Vector<REAL> e_k;
	Vector<long> pmt;

	e_k.resize(m);

	pmt.resize(m);
	for (i=1; i<=m; i++) { 
		pmt[i] = i;
		e_k[i] = 0;
	}
	
	e_k[k] = 1;

	if (compute_coords(Rt, Rt.transpose(), pmt, e_k, x, true, false) != 1)
		ERROR("compute_coords: Rt*R ist not regular!");
#else
	x.resize(m);

	for (j=1; j<=m; j++) {

		if (j == k)
			x[j] = TO_REAL(1);
		else
			x[j] = TO_REAL(0);

		for (i=1; i<=j-1; i++)
			x[j] -= (Rt[j][i] * x[i]);

		x[j] /= Rt[j][j];
	}

	for (j=m; j>=1; j--) {
		for (i=j+1; i<=m; i++)
			x[j] -= (Rt[i][j] * x[i]);

		x[j] /= Rt[j][j];
	}
#endif

	for (j=1; j<=N; j++) {
		dual_lat.B_curr[k][j] = 0;
		for (i=1; i<=m; i++) 
			dual_lat.B_curr[k][j] += (B_curr[i][j] * x[i]); 	
		
		dual_lat.B[k][j] = dual_lat.B_curr[k][j];
	}
}

/* 
	This function computes the dual base
*/
template <typename REAL>
void Lattice<REAL>::compute_bstar(Lattice &dual_lat) 
{
	register long i;
	dual_lat.resize(M, N);

	compute_gs_qr();
	for (i=1; i<=M; i++) 
		compute_bstar(dual_lat, i, M);
#if 0
	Matrix<REAL> CCC, E;
	CCC = (B_curr * dual_lat.B_curr.transpose());

	CCC.normalize();

	cerr << CCC << endl;
	E.make_one(CCC.M);

	if (E == CCC)
		cerr << "ok" << endl;
	else
		cerr << "nok" << endl;

	exit(1);
#endif
}

template <typename REAL>
bool Lattice<REAL>::remove_int_dep(register long k)
{	
	bool ret = false;
	register long i;

	swap(k, M);

	if (!B_curr[k].is_zero()) {

		Matrix<REAL> A;
		Vector<REAL> coord;

		A.resize(M-1, N);
		for (i=1; i<=A.M; i++)
			A[i] = B_curr[i];

		Lattice<REAL> lat(A);

		if (lat.compute_lat_coords(B_curr[M], coord)) {

			if (coord.contains_one()) { // Lineare Abhängigkeit erkannt
				ret = true;
			} else {
				ERROR("Inkonsistenz: Untergitter Abhängigkeit entdeckt")
			}
		}

	} else // Null-Vektor entdeckt
		ret = true;

	if (ret) { // Entferne die Abhängigkeit

		B_curr.resize(M-1, N);
		M = B_curr.M;
	}

	return ret;
}

template <typename REAL>
long Lattice<REAL>::remove_zero_vecs(void)
{
	register long i, zeroes = 0;

	for (i=1; i<=M; i++) {

		if (B_curr[i].is_zero()) {

			swap(i, M);
			resize(M-1);
			
			B = B_curr;
			T.make_one(M);

			zeroes++;
		}

	}

	if (B_curr[M].is_zero()) {

		resize(M-1);

		B = B_curr;
		T.make_one(M);

		zeroes++;
	}

	return zeroes;
}

template <typename REAL>
long Lattice<REAL>::remove_int_deps(void)
{
	register long i, deps;
	bool retry;
	
	deps = 0;

	while (M > N) {

		Matrix<REAL> A, R;

		A.resize(N, N);
		R.resize(M - N, N);

		for (i=1; i<=N; i++)
			A[i] = B_curr[i];

		for (i=N+1; i<=M; i++)
			R[i-N] = B_curr[i];

		Lattice<REAL> lat(A, VERB);

		if (lat.remove_int_deps() > 0) {

			B_curr.resize(lat.M + R.M, N);
			for (i=1; i<=lat.M; i++)
				B_curr[i] = lat.B_curr[i];
			for (i=lat.M+1; i<=lat.M + R.M; i++)
				B_curr[i] = R[i-lat.M];
		}

		B = B_curr;
		resize(B.M);
		T.make_one(M);
	} 

	do {

		retry = false;
		compute_gs_qr();

		for (i=1; i<=M; i++) {

			if (c[i] < epsilon || ISNAN(c[i])) {

				if ((retry = remove_int_dep(i))) 
					deps++;
				else {

					/***********************************************/
					/* A linear dependency could not be discovered */
					/*  and a zero vector could also not be found  */
					/***********************************************/

					WARNING("Condition problems detected")
				}
			}
		}
	}

	while (retry);

	if (VERB) 
		cerr << "Linear dependencies detected: " << deps << endl;

	B = B_curr;
	resize(B.M);
	T.make_one(M);

	return deps;
}

template <typename REAL>
bool Lattice<REAL>::blend_out(register long k)
{
	register long i;

	WARNING("Blending out - c[" << k << "] = " << c[k] << ", eps = " << epsilon)

	B_curr[k][0] = -1; // NEW
	for (i=k+1; i<=M; i++) 
		if (B_curr[i][0] != -1) 
			break;

	if (i <= M) {
		swap(k, i);
		return true;
	} 

	c[k] = 0;

	return false;
}

template <typename REAL>
void Lattice<REAL>::reset_blending(void)
{
	register long i;
	for (i=1; i<=M; i++) 
		B_curr[i][0] = 0;
}

/* 
	The classic routine for computing Gram-Schmidt data 
*/
template <typename REAL>
void Lattice<REAL>::compute_gs_classic(register long k)
{
	bool recompute;
	register long i, j;
	REAL s, t;

	Vector<REAL> buf(k-1);

	do {

		recompute = false;

		for (j=1; j<=k-1; j++) {

			s = (B_curr[j] * B_curr[k]);
			Bgram[k][j] = Bgram[j][k] = s;

			t = 0;
			for (i=1; i<=j-1; i++) 
				t += (mu[j][i] * buf[i]);

			mu[k][j] = (buf[j] = (s - t)) / c[j];
		}

		s = 0;
		for (j=1; j<=k-1; j++) {
			s += (mu[k][j] * buf[j]);
		}

		Bgram[k][k] = B_curr[k] * B_curr[k];

		c[k] = Bgram[k][k] - s;

		if (c[k] < epsilon || ISNAN(c[k])) {

			/********************************************/
			/* We probably have some condition problems */
			/*   ==> Try Householder QR-decomposition   */
			/********************************************/ 	

			compute_lengths();

			if (c[k] < epsilon || ISNAN(c[k])) {

				/*******************************************************/
				/* Ausblenden von (linear abhängigen) Problem-Vektoren */
				/*******************************************************/

				if (!(recompute = blend_out(k))) 
					return;
			}
		}

		mu[k][k] = 1;

	} while (recompute);
}

template <typename REAL>
void Lattice<REAL>::compute_gs_classic(register long k, register long m)
{
	register long i;

	for (i=k; i<=m; i++)  
		compute_gs_classic(i);
}

template <typename REAL>
void Lattice<REAL>::compute_gs_classic(void)
{
	compute_gs_classic(1, M);
}

/* 
	This function modifies the k-th base vector,
	such that |mu[k][j]| <= 1/2 for all 1 <= j < k
*/
template <typename REAL>
bool Lattice<REAL>::size_reduce(register long k)
{	
	bool ret = false;
	register long i, j;
	REAL mu1, t;

	compute_gs_classic(k, k);
	
	/********************************************/
	/* The remaining vectors are zero or depend */
	/*     lineary on the preceding vectors     */
	/********************************************/
				
	if (B_curr[k][0] == -1)  
		return false;

	for (j = k-1; j >= 1; j--) {
		t = ABS(mu[k][j]);

		if (t > 0.5) {

			mu1 = ROUND(mu[k][j]);

			if (mu1 == 1) {
				for (i = 1; i <= j-1; i++)
					mu[k][i] -= mu[j][i];
			}
			else if (mu1 == -1) {
				for (i = 1; i <= j-1; i++)
					mu[k][i] += mu[j][i];
			}
			else {
				for (i = 1; i <= j-1; i++)
					mu[k][i] -= mu1*mu[j][i];
			}

			mu[k][j] -= mu1;
			
			B_curr[k] -= B_curr[j]*mu1;

			if (TRANS)
				T[k] -= T[j]*mu1;

			ret = true;
		}
	}

	if (ret) {

		// FIXME
		
		// If you leave this part out you will get an
		// "internal error3" when running: 
		//
		// 		./rasa test/challenge/ch-500.lat

		//cerr << "c_k old = " << c[k] << endl;
		compute_gs_classic(k, k);
		//cerr << "c_k new = " << c[k] << endl;
	}

	return ret;
}

/*
	The extended Lovasz condition with deep insertions.
*/
template <typename REAL>
long Lattice<REAL>::deep_reduce(register long k)
{
	register long l = 1;

	REAL t1, t2;

	t1 = B_curr[k].quad_euklid_norm(); 
	t2 = c[1];

	while (l < k) {

		if ((l <= DEEP || k-l <= DEEP) && (t1 < DELTA*t2)) {

			deep_cnt++;

			while (l < k) {
				swap(k, k-1);
				k--;
			}

			return k;

		} else {

			t1 = t1 - pow2(mu[k][l]) * t2;
			t2 = c[l+1];

			l++;
		}
	}

	return (k+1);
}

/* 
	The Lovasz condition gets checked in here.
*/
template <typename REAL>
long Lattice<REAL>::lovasz_reduce(register long k)
{
	REAL t1, t2;

	t1 = c[k] + pow2(mu[k][k-1]) * c[k-1];
	t2 = c[k-1];

	if (t1 < DELTA*t2) {
		swap(k, k-1);		
		k--;

		return k;
	}

 	return (k+1);
}

template <typename REAL>
long Lattice<REAL>::lll(void)
{
	reset_blending();
	return lll(1, M);	
}

/*
	The LLL-reduction algorithm calls size_reduce
	and afterwards lovasz / deep_reduce.
*/
template <typename REAL>
long Lattice<REAL>::lll(register long k, register long m)
{
	register long i, new_k = k;
	register long swap_limit; 

	time_t start_tt, last_tt, tt;
	time_t interval_tt = 3600; 
	
	Vector<long> J;

	J.resize(m);
	J.clear();

	time(&last_tt);
	start_tt = last_tt;

	while (k <= m) {
	
		if (k < new_k)
			new_k = k;
		
		check_solution(k);
		if (size_reduce(k))
			check_solution(k);

		if (B_curr[k][0] == -1) { // NEW 
			return k;
		}

		if (k < 2) {
			k++;
			continue;
		}

		time(&tt);
		if (BTIME && (tt - start_tt >= BTIME)) 
			break;

		if (tt > last_tt + interval_tt) {

			last_tt = tt;

			if (VERB >= 2) 
				cerr << k << ":" << m << " ";
		}

		/***********************************/
		/*  Code to prevent infinite loops */
		/***********************************/

		swap_limit = 5; 			 // wenigstens 5 Swaps sind erlaubt
		for (i=new_k; i<=m; i++) // FIXME:  vormals k statt new_k
			swap_limit += J[i];
		//swap_limit /= 2; 

		/***********************************************/
		/* J[k] counts how often the k-th basis vector */
		/*     gets swapped during this lll call.      */
		/*---------------------------------------------*/
		/*          If too many swaps occur,           */
		/*   the algorithm steps one vector further.   */
		/***********************************************/

		if (J[k] < swap_limit) {

			J[k]++;

			if (DEEP > 0) 
				k = deep_reduce(k);
			else 
				k = lovasz_reduce(k);

		} else {

			J[k]--;
			k++;
		}
	}

//	cerr << "J = " << J << endl;

	return new_k;
}

template <typename REAL>
void Lattice<REAL>::compute_ytilda(register long t, 
		register long ss) 
{
	register long i;
	REAL tmp;
	
	tmp = 0;
	for (i = t+1; i <= ss; i++)
		tmp += stage[i].utilda*mu[i][t];

	stage[t].ytilda = tmp;
}

/*
	This method gets called, when a backtracking step has to be made during 
	the BKZ enumeration. It is responsible for calling compute_ytilda /
	compute_utilda_bnds and initializes the needed variables for this stage.
*/
template <typename REAL>
void Lattice<REAL>::compute_stage(register long t, register long ss) 
{
	compute_ytilda(t, ss);
	
	stage[t].vtilda = ROUND(-stage[t].ytilda);
	stage[t].Delta = TO_REAL(0);

	if (stage[t].vtilda > -stage[t].ytilda) 
		stage[t].delta = TO_REAL(-1);
	else 
		stage[t].delta = TO_REAL(1);

	stage[t].utilda = stage[t].vtilda;
}

template <typename REAL>
void Lattice<REAL>::check_utilda(register long t, register long ss)
{
	register long i;

	if (stage[t].utilda <= 0) {
		for (i=t+1; i<=ss; i++)
			if (stage[i].utilda != 0)
				break;

		if (i > ss) {
			while (stage[t].utilda <= 0) 
				next_utilda(t, t+1); 
		}
	}
}

/*
	The next value for utilda[t] is computed in this function
*/
template <typename REAL>
void Lattice<REAL>::next_utilda(register long t, 
		register long ss)
{
	if (t < ss)
		stage[t].Delta = -stage[t].Delta;

	if (stage[t].Delta * stage[t].delta >= 0) 
		stage[t].Delta += stage[t].delta;

	stage[t].utilda = stage[t].vtilda + stage[t].Delta;

	check_utilda(t, ss);
}

template <typename REAL>
REAL Lattice<REAL>::niveau_function(Vector<REAL> const &vec, register long t)
{
	register long j, k, s;

	REAL tmp;
	Vector<REAL> bb, z;
	z.resize(t);

	bb.resize(1 + 2*N);
	bb[1] = vec.sup_norm();

	for (s=1; s<=t; s++) {
		for (k=1; k<=N; k++) {
			
			bb[1 + k] = -vec[k];
			bb[1 + N + k] = vec[k];

			for (j=1; j<=s-1; j++) {
				tmp = (B_curr[j][k] * z[j]);

				bb[1 + k] -= tmp;
				bb[1 + N + k] += tmp;
			}
		}
#if 0
		Matrix<REAL> A;
		Vector<REAL> cc, x;

		for (s=1; s<=t; s++) 
			for (k=1; k<=N; k++) 
				A[1 + k][1] = A[1 + N + k][1] = TO_REAL(-1);

		cc.resize(1);
		x.resize(1);

		A.resize(1 + 2*N, 1);
		A[1][1] = TO_REAL(1);

		cc[1] = 1;

		if (!A.simplex(bb, cc, x)) {
			cerr << "A = " << A << endl;
			cerr << "bb = " << bb << endl;
			cerr << "cc = " << cc << endl;
			cerr << "x = " << x << endl;

		}

		cerr << "A = " << A << endl;
		cerr << "bb = " << bb << endl;
		cerr << "cc = " << cc << endl;
		cerr << "x = " << x << endl;

		z[s] = x[1];
#else	
		/*************************************************/
		/* A cheap alternative which has not to call     */
		/* the simplex algorithm: 						       */
		/*															    */
		/* 1. Search the minimum entry on the right side */
		/* 2. The desired x equals the negated minimum   */
		/*************************************************/

		z[s] = bb[1];
		for (j=2; j<=N; j++) {
			if (bb[j] < z[s])
				z[s] = bb[j];
		}

		if (z[s] < 0)
			z[s] = -z[s];
#endif
	}

	return z[t];
}

template <typename REAL>
void Lattice<REAL>::bkz(bool oo_norm, bool enum_only)
{
	bool cond, clean = false;

	register long i, t, jj, ss, kk, hh, zz;
	register long beta, new_k;

	time_t start_tt, last_tt, tt;
	time_t interval_tt = 3600; 

	REAL cbar, fbar, q;
	
	Vector<REAL> ubar; 
	ubar.resize(M);

	Lattice dual_lat;
	
	time(&last_tt);
	start_tt = last_tt;
	
	dual_lat.resize(M, N);

	for (i=1; i<=M; i++)
		B_curr[i][0] = 0;

	if (enum_only) 
		beta = M;
	else
		beta = LMIN(BETA, M);

	if (VERB >= 2) {
		cerr << "-> BKZ reducing ( beta = " << beta << ", deep = " << DEEP;
		if (oo_norm)
			cerr << ", oo-norm";
		cerr << " ) ... ";
	}
	
	/********************************************/
	/* The remaining vectors are zero or depend */
	/*     lineary on the preceding vectors     */

	if (B_curr[lll()][0] == -1) {
		if (VERB >= 2) cerr << endl;
		return;
	}

	/********************************************/
	
	if (M > 1 && beta > 2) {

		jj = 0;
		zz = 0;
		
		while (zz < M-1) {
			
			jj++;

			if (jj == M) {
				jj = 1;
				clean = true; 
			}

			kk = LMIN(jj+beta-1, M);
			hh = LMIN(kk+1, M);

			//// BEGINN Initialisierung ////

			for(i=jj; i<=kk+1; i++) 
				stage[i].clear();
				
			ubar.clear(jj, kk);

			if (oo_norm) { // NEW
				for (i=jj; i<=kk+1; i++) 
					Btilda[i].clear();

				fbar = niveau_function(B_curr[jj], jj);
				cbar = pow2(fbar)*(N); // = (fbar*R)² vgl. Ritter S.39
			} else 
				cbar = c[jj];
			
			ss = t = jj;

			ubar[jj] = stage[jj].utilda = 1;
			check_utilda(t, ss);

			//// ENDE Initialisierung ////
		
			while (t <= kk) {
				time(&tt);

				if (BTIME && (tt - start_tt >= BTIME)) { 
					lll(jj, M);
					if (VERB >= 2) cerr << endl;
					return;
				}
		
				if (tt > last_tt + interval_tt) {

					last_tt = tt;

					if (VERB >= 2) 
						cerr << zz << "/" << t << "/" << kk << " ";

					//compute_lengths();
				}
				
				//// ENDE Initialisierung der Grenzen ////

				q = stage[t].ytilda + stage[t].utilda;
				
				stage[t].ctilda = stage[t+1].ctilda + pow2(q)*c[t];

				if (oo_norm) 
					Btilda[t] = Btilda[t+1] + B_curr[t]*stage[t].utilda;

				if (EPRUNE) {
					  
					// register long l = kk + jj - t; 
					register long l = t; // entspricht Nguyen, obwohl
					// es verdreht ausschaut -- wird aber innerhalb der 
					// Bounding-Functions berücksichtigt ...
					
					/* EXTREME Pruning */

					if (EPRUNE == 1) { // Linear Bounding Function

						cond = (SQRT(stage[t].ctilda) 
								< SQRT(TO_REAL(kk - l + 1) / TO_REAL(beta) * cbar));
					
					} else if (EPRUNE == 2) { // Step Bounding Function

						if (l <= (jj + kk) / 2)
							cond = (stage[t].ctilda < cbar);
						else
							cond = (SQRT(stage[t].ctilda) < SQRT(ALPHA * cbar));

					} else { // Piecewise-Linear Bounding Function

						REAL term;

						if (l <= (jj + kk) / 2) 
							term = (2*ALPHA - 1 + (1 - ALPHA)*(2*(kk - l) + 1) / beta);
						else 
							term = (ALPHA*2*((kk - l) + 1) / beta);

						cond = (SQRT(stage[t].ctilda) < SQRT(term * cbar));
					}

				} else {

					/* STANDARD Enumeration Condition */

					// If the (squared) euclidean norm of the projected vector 
					// is smaller than cbar, then it is a substitution candidate
					// for the t-th base vector.

					cond = (stage[t].ctilda < cbar);
				}

				//// BEGINN Backtracking - Check ////

				if (cond) {

					if (t > jj) {

						t--;
						compute_stage(t, ss);
					}

					else {

						if (oo_norm) { // NEW
							
							REAL niv;
							niv = niveau_function(Btilda[t], jj);
							
							if (niv < fbar) {
								fbar = niv;

								for (i = jj; i <= kk; i++) 
									ubar[i] = stage[i].utilda;

								check_solution(ubar, jj, kk); 
								cbar = pow2(fbar)*(N); // = (fbar*R)² vgl. Ritter S.39

							} else 
								next_utilda(t, t+1);

						} else {

							for (i = jj; i <= kk; i++) 
								ubar[i] = stage[i].utilda;

							check_solution(ubar, jj, kk); 
							cbar = stage[jj].ctilda;
						}
					}

				} else {

					t++;
					ss = LMAX(ss, t);
					next_utilda(t, ss);
				}

				//// ENDE Backtracking - Check ////
			}
				
			cond = (cbar < DELTA*c[jj]);

			//// BEGINN der Basistransformation ////

			if (cond) {

				basis_extend(ubar, jj, kk);
				new_k = lll(jj, hh);

				/********************************************/
				/* The remaining vectors are zero or depend */
				/*     lineary on the preceding vectors     */
				/********************************************/
				
				if (B_curr[new_k][0] == -1) {
					if (VERB >= 2) cerr << endl;
					return;
				}

				if (new_k < jj) 
					jj = new_k - 1; 

				zz = 0;

				clean = false;
			} 

			//// ENDE der Basistransformation ////
			
			else {	

				new_k = hh+1;

				if (!clean) {

					new_k = lll(hh, hh);

					/********************************************/
					/* The remaining vectors are zero or depend */
					/*     lineary on the preceding vectors     */
					/********************************************/
						
					if (B_curr[new_k][0] == -1) {
						if (VERB >= 2) cerr << endl;
						return;
					}

					if (new_k < jj) 
						jj = new_k - 1; 
				}
				
				zz++;
			}

			for (i=new_k; i<=hh; i++)
				check_solution(i);

			for (i=1; i<=M; i++)
				dual_lat.B_curr[i][0] = 0;

			if (enum_only) {

				cerr << B_curr[1] << endl;
				cerr << B_curr[1].quad_euklid_norm() << endl;
				break;

			}
		}
	}

	if (VERB >= 2) cerr << endl;
}

/*
	If ||{-1, 1} * b_i + {-1 , 1} * b_j|| < max {||b_i|| , ||b_j||}, 
	then replace the larger of b_i, b_j with {-1, 1} b_i + {-1, 1} * b_j
*/
template <typename REAL>
void Lattice<REAL>::pair_reduce(void) 
{
	bool retry = true;

	register long idx;
	register long h, i, l;

	Vector<REAL> tmp_vec;
	REAL r, b_h, b_i;;

	if (VERB >= 2) {
		cerr << ext_prec << "-> Pairwise Reduction ...";
		cerr << endl;
	}

	while (retry) {

		retry = false;

		for (h=1; h<=M; h++) {
			for (i=1; i<=M; i++) {

				if (i == h)
					continue;

				for (l=-1; l<=1; l+=2) {

					B_curr[0] = B_curr[h] + B_curr[i]*TO_REAL(l);
					check_solution(0);

					r = (this->*abw_fptr)(B_curr[0]);

					b_h = (this->*abw_fptr)(B_curr[h]);
					b_i = (this->*abw_fptr)(B_curr[i]);

					if (r < b_h)
						idx = h;
					else if (r < b_i)
						idx = i;
					else if (!sym_bnds) { // NEW

						r = (this->*abw_fptr)(-B_curr[0]);

						if (r < b_h)
							idx = -h;
						else if (r < b_i)
							idx = -i;
						else 					
							continue;
					} else
						continue;

					if (TRANS)
						tmp_vec = (T[h] + T[i]*TO_REAL(l));

					if (idx < 0) {
						idx = -idx;
						B_curr[0] = -B_curr[0];

						if (TRANS) 
							tmp_vec = -tmp_vec;
					} 

					b[idx] = B_curr[0].quad_euklid_norm();
					B_curr[idx] = B_curr[0];
					if (TRANS) 
						T[idx] = tmp_vec;

					pair_cnt++;
					retry = true;
				}
			}
		}
	}
}

template <typename REAL>
bool Lattice<REAL>::best_heu_insert(void) 
{
	bool ret;
	
	Vector<REAL> coord, *vector;

	if (VERB >= 2)
		cerr << "-> Inserting best heuristic vector ... " << endl;

	if (heu_update) {
					
		heu_update = false;

		if (SCALE) {
			vector = new Vector<REAL>(best_heu);
			(*vector)[N] *= scale_factor;
		} else
			vector = &best_heu;

		if ((ret = compute_lat_coords(*vector, coord)))
			basis_replace(coord, 1, M, M);

		if (SCALE)
			delete vector;

		return ret;
	}

	return false;
}

template <typename REAL>
REAL Lattice<REAL>::regula_falsi(
	REAL (Lattice::*f)(Vector<REAL> const &, 
		register long, register long, register long, REAL const &) const, 
	Vector<REAL> const &len, register long k, register long u, 
	register long m, REAL const &delta_c_k, REAL &a, REAL &b) const 
{
	register long i;
	REAL x, x_old;

	x_old = b;

	if (((this->*f)(len, k, u, m, a) - delta_c_k) 
			* ((this->*f)(len, k, u, m, b) - delta_c_k) > 0) {
		ERROR("f(a)*f(b) >= 0!");
	}
	
	i = 0;

	while (i < LOOP_LIMIT) {

		x = a - ((this->*f)(len, k, u, m, a) - delta_c_k) * (b - a) / 
			(((this->*f)(len, k, u, m, b) - delta_c_k) 
				- ((this->*f)(len, k, u, m, a) - delta_c_k));

		if (ABS(x - x_old) < epsilon*ABS(x))
			return x;

		x_old = x;
		
		if (((this->*f)(len, k, u, m, a) - delta_c_k) *
				((this->*f)(len, k, u, m, x) - delta_c_k) > 0)
			a = x;
		else
			b = x;

		i++;
	}

	WARNING("regula_falsi: LOOP_LIMIT reached!")

	return x;
}

/* 
	The expected length of a sampled lattice vector is calculated 
	in this function (see chapter 3.3 of the dissertation).
*/
template <typename REAL>
REAL Lattice<REAL>::exp_length(Vector<REAL> const &len, register long k, 
	register long u, register long m, REAL const &q) const
{
	register long i;
	REAL sum, sum2;

	sum = sum2 = 0;
	
	for (i=1; i<=k-1; i++) 
		sum += (POW(q, TO_REAL(k-i))*len[i]);
	
	for (i=k; i<=m-u-1; i++)
		sum += len[i];

	sum *= TO_REAL(1.0/12.0);
	
	for (i=m-u; i<=m-1; i++)
		sum2 += len[i];

	sum2 *= TO_REAL(1.0/3.0);

	sum += sum2;
	sum += len[m];

	return sum;
}

/*
 	The root of the function:
			f(q) := exp_length(..., q) - delta*c[k] 

	is computed in here. This is accomplished with 
	a call to the regula_falsi method.
*/
template <typename REAL>
REAL Lattice<REAL>::log_success_prob_bound(Vector<REAL> const &len,  
	register	long k, register long u, register long m, REAL const &delta_c_k) const
{
	REAL a, b, q;

	a = 0;
	b = 1;

	if (exp_length(len, k, u, m, b) <= delta_c_k)
		return TO_REAL(-1);
	else if (exp_length(len, k, u, m, a) >= delta_c_k) 
		return TO_REAL(-m);

	q = regula_falsi(&Lattice::exp_length, len, k, u, m, delta_c_k, a, b);
	
	return FLOOR((LOG(q)/LOG(TO_REAL(2.0))) * (k*(k-1)/4.0) - 1); 
}

/*
 	This procedure calculates for the parameter u an exponent p, such that
	the probability to locate a lattice vector b with:

					||PI_k(b)||^2 <= delta * || Bdach[k]||^2 
	
	gets maximal, if at least 2^(-p) vectors are sampled.
*/
template <typename REAL>
REAL Lattice<REAL>::best_bound(register long u, register long k, 
		register long m, REAL const &delta_c_k) const
{
	register long i, j;
	REAL bnd, max, tmp;

	Vector<REAL> len(m);

	// Ludwig's ESHORT-Variante
	for (i=1; i<k; i++)
		len[i] = 0;
	for (i=k; i<=m; i++)
		len[i] = c[i];

	// Bubble-Sort Variante (sortiert die Laengen der ersten 
	// m-u-1 orthogonalen Basisvektoren absteigend und 
	// laesst die letzten u+1 fix)
	for (i=k; i<=m-u-1; i++) {
		for (j=i+1; j<=m-u-1; j++)
			if (len[j] > len[i]) {
				tmp = len[i];
				len[i] = len[j];
				len[j] = tmp;
			}
	}

	// Berechne die beste Grenze
	max = log_success_prob_bound(len, k, u, m, delta_c_k);
	for (j=k+1; j<=m-u; j++) {
		bnd = log_success_prob_bound(len, j, u, m, delta_c_k);
		if (bnd > max)
			max = bnd;
	}

	return max;
}

template <typename REAL>
long Lattice<REAL>::buchmann_strategy(register long k, register long m) const
{
	register long u;
	REAL delta_c_k, p;

	delta_c_k = DELTA*c[k];

	// Compute that u for which the success 
	// probability is sufficiently high enough.

	for (u=k; u<m; u++) {
		p = best_bound(u, k, m, delta_c_k);
		if (-p <= u)
			break;
	}

	return u;
}

template <typename REAL>
long Lattice<REAL>::schnorr_strategy(register long k, 
		register long m) const
{
	register long i, j, best_k, best_u;
	REAL Q, one_min_q, log_q, log_two_x_4, w, best_w;

	Vector<REAL> q(m);

	// Bestimme einen möglichst guten Q-Wert

	for (i=k+1; i<=m; i++) {
		q[i] = c[i] / c[k];
		q[i] = POW(q[i], TO_REAL(1.0/(i-1)));
	}

	// Sortiere die q-Werte, so dass: 
	// 	q_k+1 <= q_k+2 <= ... <= q_m
	 
	for (i=k+1; i<=m; i++) { 
		for (j=i+1; j<m; j++) 
			if (q[j] < q[i]) {
				Q = q[i];
				q[i] = q[j];
				q[j] = Q;
			}
	}

	// Q wird der Median von q_k+1, q_k+2, ..., q_m
	
	if ((k+1+m) % 2 == 0)
		Q = q[(k+1+m) / 2];
	else
		Q = (1.0/2.0) * (q[(k+1+m)/2] + q[(k+1+m)/2 + 1]);

	static REAL one_min_eps = TO_REAL(1.0 - epsilon);

 	Q = FMIN(Q, one_min_eps); // 0 < Q < 1
 
 	one_min_q = 1.0 - Q;
	log_q = LOG(Q);
	log_two_x_4 = LOG(2.0)*4;

	k = best_k = best_u = 1;

	best_w = (1.0/12.0) * (1.0 + (Q + 3.0*POW(Q, TO_REAL(3.0)))/one_min_q);

	while (best_u < m - 3*k) {

		w = (1.0 / 12.0) * (k*POW(Q, TO_REAL(k-1.0)) + (POW(Q, TO_REAL(1.0*k)) 
					+ 3.0*POW(Q, TO_REAL(3.0*k)))/one_min_q);

		if (w < 0.99)
			break;

		if (w < best_w) {
			best_k = k;
			best_w = w;
		}

		k++;
		best_u = 1 + TO_LONG(CEIL((-k*(k-1)*log_q)/log_two_x_4));
	}

	if (best_u >= m - 3*k) {
		WARNING("usa_strategy: success probability too small!")
		best_u = 1 + TO_LONG(CEIL((-best_k*(best_k-1)*log_q)/log_two_x_4));
	}

	return best_u; 
}

template <typename REAL>
long Lattice<REAL>::vogel_strategy(register long k, 
		register long m) const
{
	register long i, j, best_k, best_u;
	REAL Q, one_min_q, log_q, log_two_x_4, w, best_w;

	Vector<REAL> q(m);

	// Bestimme einen möglichst guten Q-Wert

	for (i=k+1; i<=m; i++) {
		q[i] = c[i] / c[k];
		q[i] = POW(q[i], TO_REAL(1.0/(i-1)));
	}

	// Sortiere die q-Werte, so dass: 
	// 	q_k+1 <= q_k+2 <= ... <= q_m
	 
	for (i=k+1; i<=m; i++) { 
		for (j=i+1; j<m; j++) 
			if (q[j] < q[i]) {
				Q = q[i];
				q[i] = q[j];
				q[j] = Q;
			}
	}

	// Q wird der Median von q_k+1, q_k+2, ..., q_m
	
	if ((k+1+m) % 2 == 0)
		Q = q[(k+1+m) / 2];
	else
		Q = (1.0/2.0) * (q[(k+1+m)/2] + q[(k+1+m)/2 + 1]);

	static REAL one_min_eps = TO_REAL(1.0 - epsilon);

 	Q = FMIN(Q, one_min_eps); // 0 < Q < 1
 
 	one_min_q = 1.0 - Q;
	log_q = LOG(Q);
	log_two_x_4 = LOG(2.0)*4;

	k = best_k = best_u = 1;

	best_w = (1.0/12.0) * (		1.0 						+ 		(		Q 
												+ 3.0*POW(Q, TO_REAL(m-2)) 
												- 4.0*POW(Q, TO_REAL(m-1)))/one_min_q)
														+ POW(Q, TO_REAL(m-1));
	while (best_u + k < m) {

		w = (1.0 / 12.0) * (k*POW(Q, TO_REAL(k-1.0)) + (POW(Q, TO_REAL(1.0*k)) 
												+ 3.0*POW(Q, TO_REAL(m-best_u-1))
												- 4.0*POW(Q, TO_REAL(m-1)))/one_min_q)
														+ POW(Q, TO_REAL(m-1));

		if (w < 0.99)
			break;

		if (w < best_w) {
			best_k = k;
			best_w = w;
		}

		k++;
		best_u = 1 + TO_LONG(CEIL((-k*(k-1)*log_q)/log_two_x_4));
	}

	if (best_u + k >= m) {
		WARNING("usa_strategy: success probability too small!")
		best_u = 1 + TO_LONG(CEIL((-best_k*(best_k-1)*log_q)/log_two_x_4));
	}

	return best_u;
}

/*
 	The sample algorithm SA expects a parameter u, which is computed 
	in this procedure according to the selected GSA strategy.
*/
template <typename REAL>
long Lattice<REAL>::compute_usa(register long k, register long m) const
{
	register long u;

	if (GSA == 1) 
		u = schnorr_strategy(k, m);
	else if (GSA == 2)
		u = buchmann_strategy(k, m);
	else if (GSA == 3)
		u = vogel_strategy(k, m); 
/*	else if (GSA == 4)
		u = fourier_strategy(k, m); */
	else
		ERROR("This gsa strategy is not implemented!")

	u = LMIN(u, m-1); // 1 <= u < m 

	return u;
}
	
/*
	The random sampling routine, which generates 
	lattice vectors for which: 
		
	a)	| <b, B_dach[j]> / <B_dach[j], B_dach[j]> |	<= 1/2 for j=1,2,...,m-u-1
	b)	| <b, B_dach[j]> / <B_dach[j], B_dach[j]> |	<= 1 for j=m-u,m-u+1,...,m
*/
template <typename REAL>
void Lattice<REAL>::sa(Sample<REAL> * const sam, register long k, 
		register long m, register long u)
{
	register long i, j;
	REAL lower, upper, _mu_;
		
	sam->U[m] = 1;
	sam->MU[m] = 1.0; 

	for (i=1; i<m; i++) {
		sam->U[i] = 0;
		sam->MU[i] = mu[m][i];
	}

	sam->B = B_curr[m];

	for (i=m-1; i>=m-u; i--) {

		lower = CEIL(sam->MU[i] - 1);
		upper = FLOOR(sam->MU[i] + 1);

		_mu_ = rand_eq_real(lower, upper); 

		sam->B = sam->B - B_curr[i]*_mu_;
		sam->U[i] -= _mu_;

		for (j=1; j<i; j++)
			sam->MU[j] = sam->MU[j] - _mu_ * mu[i][j];
		sam->MU[i] = sam->MU[i] - _mu_;
	}

	for (; i>=k; i--) {

		lower = CEIL(sam->MU[i] - 0.5);
		upper = FLOOR(sam->MU[i] + 0.5);

		_mu_ = rand_eq_real(lower, upper); 

		sam->B = sam->B - B_curr[i]*_mu_;
		sam->U[i] -= _mu_;

		for (j=1; j<i; j++)
			sam->MU[j] = sam->MU[j] - _mu_ * mu[i][j];
		sam->MU[i] = sam->MU[i] - _mu_;
	}
}	

/*
	This function scans the coord vector between the k-th 
	and m-th coordinate for an entry which equals to +- 1. 
	
	If no such entry could be found the basis gets 
	extended with help of the basis(_extend) function.
	
	In the other case, when such a entry could be located,
	the corresponding base vector is modified by adding up 
	the remaining coordinate / base vector products.
	
	Both cases end with a swap of the k-th base vector 
	to the max(k,l)-th position.
*/
template <typename REAL>
void Lattice<REAL>::basis_replace(Vector<REAL> &coord,
		register long k, register long m, register long l)
{
	register long i, o;

	for (o=m; o>=k; o--) 
		if (ABS(coord[o]) == 1)
			break;

	if (o < k) { 
		basis_extend(coord, k, m); 
		for (i=k; i<l; i++) 
			swap(i, i+1);

	} else {

		if (coord[o] == -1) {
			B_curr[o] = -B_curr[o];

			if (TRANS)
				T[o] = -T[o];
		}

		for (i=k; i<o; i++)  
			B_curr[o] += (B_curr[i] * coord[i]);
		
		for (i=o+1; i<=m; i++)  
			B_curr[o] += (B_curr[i] * coord[i]);

		if (TRANS)  {
			for (i=k; i<o; i++) 
				T[o] += (T[i] * coord[i]);
			for (i=o+1; i<=m; i++) 
				T[o] += (T[i] * coord[i]);
		}

		if (l < k)
			l = k;

		if (l < o) {
			for (i=o; i>l; i--) 
				swap(i, i-1);
		} else {
			for (i=o; i<l; i++) 
				swap(i, i+1);
		}
	}
}

/*
	This function realizes the replacement step for the dual base, 
	which is described at the end of chapter 3.4 of the dissertation.
*/
template <typename REAL>
void Lattice<REAL>::basis_replace_dual(Vector<REAL> &coord, register long k, 
		register long m)
{
	register long i, km_2;

#ifdef REVERSED
	// Reverse the order of the base vectors
	 
	km_2 = ((m-k) / 2);

	for (i=k; i<=km_2; i++) 
		swap(i, m-i+k);
#endif
	for (i=m; i>k; i--) {
		swap(i, i-1);
		
		B_curr[i] -= (B_curr[i-1] * TO_REAL(coord[i-1]));

		if (TRANS)
			T[i] -= (T[i-1] * TO_REAL(coord[i-1]));
	}
}

template <typename REAL>
REAL Lattice<REAL>::compute_pi(Vector<REAL> const & lambda, REAL const & len,
		register long k, register long m)
{
	register long i;
	REAL pi;

	if (k > m/2) {

		pi = 0;
		for (i=k; i<=m; i++) 
			pi += pow2(lambda[i]) * c[i];

	} else {

		pi = len;
		for (i=1; i<k; i++) 
			pi -= pow2(lambda[i]) * c[i];
	}

	return pi;
}

/* 
 	The next routine combines SHORT and ESHORT 
*/
template <typename REAL>
bool Lattice<REAL>::exshort_sr(register long k, register long m)
{
	time_t start;
	register long i, l, u, zz, limit;

	Vector<REAL> delta_b, delta_c;

	Vector<Sample<REAL> > sample; 
	Sample<REAL> *sam;

	time(&start);

	compute_lengths(k, m);
	u = compute_usa(k, m);
	
	if (VERB >= 2) {
		cerr << "-> ExSHORT Sampling ( k = " << k << ", m = " << m;
		cerr << ", u = " << u << " ) ..." << endl;
	}
	
	if (SLIMIT < (limit = pow(2, u))) {
		WARNING("Sample Limit is too small: " << SLIMIT << " < " << limit)
		limit = SLIMIT;
	}

	delta_b.resize(m);
	delta_c.resize(m);

	for (zz=k; zz<=m; zz++) 
		delta_b[zz] = DELTA * b[zz];

	if (PRJ) 
		for (zz=k; zz<=m; zz++) 
			delta_c[zz] = DELTA * c[zz];

	sample.resize(m); 

	for (i=0; i<=m; i++) {
		sample[i].U.resize(m);
		sample[i].MU.resize(m);
		sample[i].B.resize(N);
		sample[i].len = sample[i].pi = 0;
	}

	sam = &(sample[0]);

	for (l=0; l<limit; l++) {

		sa(sam, k, m, u);
		sam->len = sam->B.quad_euklid_norm();
		check_solution(sam->U, k, m);

		for (zz=k; zz<=m; zz++) {

			if ((sam->len <= delta_b[zz] && sample[zz].len == 0) 
					|| (sam->len < sample[zz].len)) {
				
				if (PRJ)
					sam->pi = compute_pi(sam->MU, sam->len, k, m);
				sam->pos = i+1;

				sswap(sample[zz], (*sam));
				break;
			}

			if (PRJ) {

				if (zz == k) 
					sam->pi = compute_pi(sam->MU, sam->len, k, m);
				else  
					sam->pi -= pow2(sam->MU[zz-1]) * c[zz-1];

				if ((sam->len <= delta_b[zz]) && 
						((sam->pi <= delta_c[zz] && sample[zz].pi == 0) 
						 || (sam->pi < sample[zz].pi)) ) { 

					sam->pos = -(l+1);

					sswap(sample[zz], (*sam));
					break;
				}
			}
		}
	}

	// Find the best sample vector
	 
	for (i=k; i<=m; i++) 
		if (sample[i].len > 0 || sample[i].pi > 0) 
			break;

	if (i <= m) {
	
		if (sample[i].pos > 0)
			short_cnt++;
		else
			eshort_cnt++;

		basis_replace(sample[i].U, i, m); 

		if (SCALE)
			sample[i].B[N] /= scale_factor;

		if (SIEVE != -1) 
			sieve_set.insert(sample[i].B); 

		return true;
	} 

	return false;
}

template <typename REAL>
void Lattice<REAL>::fill_sieve(void)
{
	register long j;
	Vector<REAL> coord, lat_vec;
		
	coord.resize(M);

	while (sieve_set.elements < sieve_set.elements_max) {

		/* Generate a random 0 / 1 coord vector ... */

		for (j=1; j<=M; j++) 
			coord[j] = rand_eq_long(0, 1);

		/* Zero vectors shall be omitted ... */

		if (coord.is_zero()) {

			for (j=1; j<=M; j++) {
				if (rand_eq_long(0, 1))
					coord[j] = 1;
				else
					coord[j] = -1;
			}
		}
		
		/* Compute the random lattice vector */

		lat_vec = B_curr.transpose()*coord;

		if (SCALE)
			lat_vec[N] /= scale_factor;

		sieve_set.insert(lat_vec);
	}
}

template <typename REAL>
void Lattice<REAL>::sieve(double gamma) 
{
	register long i;
	REAL abw, min, /* max,*/ R;

	Vector<REAL> d_vec;
	Set<Vector<REAL> > c_set, s_set2;
	Element<Vector<REAL> > *v_element, *c_element, *element;

	if (best_heu_norm != 0)
		sieve_set.insert(best_heu); 

	for (i=1; i<=M; i++) { 
		if (!B_curr[i].is_zero()) {
			
			if (SCALE)
				B_curr[i][N] /= scale_factor;

			sieve_set.insert(B_curr[i]); 
		}
	}

	if (VERB >= 2) {
		cerr << "-> Sieving ( " << sieve_set.elements;

		if (sieve_set.elements_max > 0)
			cerr << " + " << sieve_set.elements_max - sieve_set.elements;
		
		cerr << " vectors ) ..." << endl; 
	}

	if (sieve_set.elements < sieve_set.elements_max) 
		fill_sieve();
	
	c_set.elements_max  = sieve_set.elements_max;
	s_set2.elements_max = sieve_set.elements_max;

	while (1) {
		
		R = 0;
		
		v_element = sieve_set.first_element;

		while (v_element != 0) {
			R = FMAX(R, (this->*abw_fptr)(v_element->content));
			v_element = v_element->next_element;
		}

		if (ABS(R) < epsilon)
			break;

		c_set.clear();
		s_set2.clear();
		
		//cerr << "sieve_set = " << sieve_set << endl;

		v_element = sieve_set.first_element;

		while (v_element != 0) {

			//cerr << "c_set = " << c_set << endl;

			if ((this->*abw_fptr)(v_element->content) <= gamma*R) {
				s_set2.insert(v_element->content);

			} else {

				c_element = c_set.first_element;

				while (c_element != 0) {
					
					d_vec = v_element->content - c_element->content;
					if (!d_vec.is_zero()) {

						abw = (this->*abw_fptr)(d_vec);

						if (abw <= gamma*R) {
							s_set2.insert(d_vec);
							break;
						}
					}

					d_vec = v_element->content + c_element->content;
					if (!d_vec.is_zero()) {

						abw = (this->*abw_fptr)(d_vec);

						if (abw <= gamma*R) {
							s_set2.insert(d_vec);
							break;
						}
					}

					if (!sym_bnds) { // NEW

						ERROR("this should not happen NOW!");

						d_vec = -v_element->content - c_element->content;
						if (!d_vec.is_zero()) {

							abw = (this->*abw_fptr)(d_vec);

							if (abw <= gamma*R) {
								s_set2.insert(d_vec);
								break;
							}
						}

						d_vec = -v_element->content + c_element->content;
						if (!d_vec.is_zero()) {

							abw = (this->*abw_fptr)(d_vec);

							if (abw <= gamma*R) {
								s_set2.insert(d_vec);
								break;
							}
						}
					}

					c_element = c_element->next_element;
				}

				if (c_element == 0)
					c_set.insert(v_element->content);
			}

			v_element = v_element->next_element;
		}

		if (s_set2.elements == 0) 
			break;
		
		sieve_set = s_set2;
	} 

	v_element = sieve_set.first_element;
	
	element = v_element;
	min = (this->*abw_fptr)(element->content);

	while (v_element != 0) {

		check_solution(v_element->content);
		
		abw = (this->*abw_fptr)(v_element->content);
		if (abw < min)
			element = v_element;

		v_element = v_element->next_element;
	}

//	WARNING("FIXME -- element->content in die Basis einbauen ...")
}

/*******************************************************/
/*       The default deviation function computes       */
/* the euclidean distance between the submitted vector */
/*      and the midpoint of the two bound vectors.     */
/*******************************************************/

template <typename REAL>
REAL Lattice<REAL>::def_chk_abw(Vector<REAL> const &vec) 
{
	register long j;
	Vector <REAL> mid;
	
	mid = (check_ubnd + check_lbnd);
	for (j=1; j<=N; j++)
		mid[j] /= 2;
	mid = vec - mid;

	if (SCALE)
		mid[N] /= scale_factor;

	return mid.quad_euklid_norm();
}


/*********************************************/
/* Calculate how often a vector violates the */
/*    solution vector bound constraints.     */
/*********************************************/

template <typename REAL>
REAL Lattice<REAL>::anz_chk_abw(Vector<REAL> const &vec) 
{
	bool valid; 
	register long j;
	REAL anz_abw;
	
	anz_abw = 0;

	for (j=1; j<=N; j++) {
		if ((check_anz0[j] == -1) && (vec[j] == 0))
			valid = false;
		else
			valid = (check_lbnd[j] <= vec[j] && vec[j] <= check_ubnd[j]);

		if (!valid) 
			anz_abw++;
	}

	return anz_abw;
}


/**************************************************/
/* Compute the deviation for the vector component */
/* which violates the constration bounds at most. */
/**************************************************/

template <typename REAL>
REAL Lattice<REAL>::max_chk_abw(Vector<REAL> const &vec) 
{
	register long j;
	REAL curr_abw, max_abw;

	max_abw = 0;

	for (j=1; j<=N; j++) {
		curr_abw = FMAX(check_lbnd[j] - vec[j], vec[j] - check_ubnd[j]);
		
		if (curr_abw <= 0) { 
			if (vec[j] == 0 && check_anz0[j] == -1)
				curr_abw = 1;

		} else if (SCALE && j == N)
			curr_abw /= scale_factor;

		if (curr_abw > max_abw) 
			max_abw = curr_abw;
	}

	return max_abw;
}


/**************************************************/
/* Sums up the deviation of each vector component */
/**************************************************/

template <typename REAL>
REAL Lattice<REAL>::all_chk_abw(Vector<REAL> const &vec) 
{
	register long j;
	REAL abw, dist;

	abw = 0;

	for (j=1; j<=N; j++) {
		dist = FMAX(check_lbnd[j] - vec[j], vec[j] - check_ubnd[j]);

		if (dist <= 0) {
			if (vec[j] == 0 && check_anz0[j] == -1)
				abw++;
		} else {

			if (SCALE && j == N)
				dist /= scale_factor;

			abw += dist;
		}
	}

	return abw;
}

/*
	A wrapper function for the basis-
	method which follows afterwards.
*/
template <typename REAL>
void Lattice<REAL>::basis_extend(Vector<REAL> &uu,
		register long jj, register long kk)
{
	register long i, s = 0;

	// Test if this is a (non-)trivial basis extension

	for (i = jj+1; i <= kk; i++) { 

		if (uu[i] != 0) {
			if (s == 0)
				s = i;
			else
				s = -i;
		}
	}

	if (s == 0) {

		// Normally this case should never occur, but if it does 
		// we make sure that no linear dependencies have evolved
		
		if (rank() != M) {
			ERROR("rank is too small!");
		}

	} else if (s > 0) {

		for (i = s; i > jj; i--) 
			swap(i-1, i);

		triv_sub++;

	} else {
		basis(uu, jj, kk);
		ntriv_sub++;
	}
}

/*
	This function implements Hoerner's BASIS algorithm. 
	The vector B_curr*u is inserted as j-th base vector.
	The old vectors b_j,b_(j+1), ..., b_k are modified
	in a way that they don't loose their base character.
*/
template <typename REAL>
void Lattice<REAL>::basis(Vector<REAL> &uu, 
		register long jj, register long kk)
{
	register long i, k;
	REAL tmp, q;

	B_curr[0].resize(N);
	B_curr[0].clear();

	for (i = jj; i <= kk; i++) {
		if (uu[i] == 0) 
			continue;

		B_curr[0] += B_curr[i]*uu[i];
	}
	
	if (B_curr[0].is_zero())
		ERROR("basis can't insert the zero vector!");
	
	b[0] = B_curr[0].quad_euklid_norm();

	check_solution(0); 

	if (TRANS) {
		T[0].resize(T.M);
		T[0].clear();

		for (i = jj; i <= kk; i++) {
			if (uu[i] == 0) 
				continue;
			T[0] += T[i]*uu[i];
		}
	}

	//// ANFANG des Algorithmus BASIS ////

	k = kk;
	while (uu[k] == 0)
		k--;

	// Es muss gelten:
	// 	ggT(uu[jj], uu[jj+1], ..., uu[k]) = 1
	//
	// vgl. Hoerner Diplomarbeit
	
	tmp = uu[k];
	for (i=k-1; i>=jj; i--)
		if (uu[i] != 0)
			tmp = ggT(tmp, uu[i]);

	if (tmp != 1) {

		WARNING("ggT != 1 : ggt = " << tmp)
		uu = uu / tmp;
	}
		 
	i = k - 1;

	while (ABS(uu[k]) > 1) {
		while (uu[i] == 0 && i > jj)  
			i--;

		if (uu[i] == 0) {
			uu.print_subvector(jj, kk);
			ERROR("basis can't divide by zero!");
		}
		
		q = ROUND(uu[k] / uu[i]);

		tmp = uu[i];
		uu[i] = uu[k] - q*uu[i];
		uu[k] = tmp;

		swap(k, i);

		B_curr[k] += B_curr[i]*q;

		if (TRANS) 
			T[k] += T[i]*q;
	}

	for (i=k; i>=jj+1; i--) 
		swap(i, i-1);

	swap(jj, 0);
}

template <typename REAL>
void Lattice<REAL>::reduce_loop(void)
{
	register long cnt, CNT = 10;

	iters = 0;

	while (1) {

		if (VERB >= 2)
			cerr << endl;

		if (PWR) {
			do pair_reduce(); 
			while (best_heu_insert()); 
		}

		variate();

		if (EENUM) 
			bkz();

		check_trans();
			
		extract_inhomogenous_part(true); // NEW

		if (GSA) {

			static long best_cnt = 0, k, m;

			if (best_cnt == 0) {
				k = rand_eq_long(1, M-1);
				m = rand_eq_long(k+1, M);
			}

			cnt = 0; 

			while (exshort_sr(k, m) 
					&& cnt++ <= CNT) {

				if (EENUM) 
					bkz();

				check_trans();
			}

			if (cnt >= best_cnt && cnt <= CNT) 
				best_cnt = cnt;
			else 
				best_cnt = 0;
		}

		if (SIEVE != -1) 
			sieve(DELTA);

		shortest_heu_to_end(); 
		shortest_euklid_to_start();

		if (EENUM == 2) 
			bkz(false, true); // Full enum in ||.||_2
		else if (EENUM == 3) 
			bkz(true, true);	 // Full enum in ||.||_oo
		else if (EENUM == 4) {
			fipo_enum();
		} /* else */
				
//		cerr << "||B_curr[1]||² = " << B_curr[1].quad_euklid_norm() << endl;

		// REMEMBER:
		// ---------
		//
		// standard enum in ||.||_oo is buggy, 
		// because lll interferes with it ...
		//
		// 	bkz(true, false);
		
		print_stats();

		if (VERB) {
			cerr << endl;
			cerr << "Total iterations: " << ++iters << endl;
			cerr << "Total running time: ";

			print_time(cerr, (time(NULL) - create_time));

			cerr << endl;
		}
	}
}

template <typename REAL>
void Lattice<REAL>::scale(bool reset)
{
	register long i;
	REAL t, tt;

	t = scale_factor;

	if (reset)
		tt = 1;
	else 
		tt = t + 10;

	for (i=1; i<=M; i++) {
		B_curr[i][N] /= t;
		B_curr[i][N] *= tt;
	}

	check_lbnd[N] /= t;
	check_lbnd[N] *= tt;

	check_ubnd[N] /= t;
	check_ubnd[N] *= tt;

	scale_factor = tt;
}

/*
	The task of this routine is to locate a base vector, 
	whose last component is minimal and fulfills the bounds
*/
template <typename REAL>
void Lattice<REAL>::extract_inhomogenous_part(bool full) 
{
	register long i;
	REAL best_ex_abw, abw;

	Vector<REAL> curr, best_ex;
	best_ex_abw = -1;
	
	SCALE = true;
	
	do {

		for (i=1; i<=M; i++) {
			if (B_curr[i][N] != 0 && (check_lbnd[N] <= B_curr[i][N]) &&
					(B_curr[i][N] <= check_ubnd[N])) {

				curr = B_curr[i];
				curr[N] /= scale_factor;

				if (best_ex_abw == -1) {
					best_ex = curr;
					best_ex_abw = (this->*abw_fptr)(best_ex);

				} 	else if ((abw = (this->*abw_fptr)(curr)) < best_ex_abw) {
					best_ex = curr;
					best_ex_abw = abw;
				}
			}
		}

		if (full) {

			for (i=1; i<M; i++) 
				if (B_curr[i][N] != 0)
					break;

			if (i >= M && best_ex_abw != -1) 
				break;

		} else if (best_ex_abw != -1)  
			break;

		scale();
		//bkz();
		lll();

	} while (1);

	scale(true); // reset scaling
	SCALE = false;

	if (VERB >= 2)
		cerr << "-> Extracted: " << best_ex << endl;

	check_solution(best_ex);

	if (SIEVE != -1) 
		sieve_set.insert(best_ex); 
}

template <typename REAL>
void Lattice<REAL>::dbase_commit(void)
{
		int ret;

		string filename;
		filename = map_file;

		const char *ptr = filename.c_str();;
		while (*ptr != '.' && *ptr != 0)
			ptr++;

		filename = filename.substr(0, ptr - filename.c_str());
		
		stringstream slk, time;
		string cmd;

		slk << best_slk_abw;

		if (S == 1) 
			time << solution[S-1].time;
		else 
			time << best_slk.time;

		cmd = "echo 'INSERT INTO rasa.benchmark (filename, paramset, slk, time) VALUES (\"" + filename + "\", \"" + dbase_str + "\", " + slk.str() + ", " + time.str() + ")' | mysql -u haaner";

		ret = system(cmd.c_str());

//		cerr << ret << endl;
//		cerr << cmd << endl;
			
		if (ret == 256) { // INSERT failed

			cmd = "echo 'UPDATE rasa.benchmark SET filename = \"" + filename + "\", paramset = \"" + dbase_str + "\", slk = " + slk.str() + ", time = " + time.str() + " WHERE filename = \"" + filename + "\" AND paramset = \"" + dbase_str + "\"' | mysql -u haaner"; // AND slk = \"" + slk.str() + "\"

			ret = system(cmd.c_str());
		} 
}

/*
	The input / read operator
*/
template <typename REAL_FRIEND>
istream& operator>> (istream &i, Lattice<REAL_FRIEND> &ref) 
{
	REAL tmp_scalar;
	Vector<REAL> tmp_vec;

	// The lattice is read 
	// from the input stream

	i >> ref.B;

	ref.B_curr = ref.B;

	ref.T.make_one(ref.B.M);

	if (ref.B.M != ref.B_curr.M || ref.B.N != ref.B_curr.N)
		ERROR("lattice dimensions are incorrect");
		
	if (ref.B.M != ref.T.M || ref.T.M != ref.T.N) 
		ERROR("transformation matrix dimensions are incorrect");

	ref.resize(ref.B.M, ref.B.N);

	// The check vectors are read 
	// from the input stream
	 
	i >> ref.check_lbnd;
	i >> ref.check_ubnd;
	i >> ref.check_anz0;

	i >> ref.check_c;
	
	i >> tmp_scalar;
	i >> tmp_scalar;
	i >> tmp_scalar;

	// The amount of slk-variables
	// is read from the input stream

	i >> ref.ineq;

	if (slk > 0 && targets == 0) // NEW
		targets = ref.ineq;

	targets = LMIN(targets, ref.ineq); // NEW
	
	ref.check_c.resize(targets);

	if (ref.check_lbnd.N != ref.N 
			|| ref.check_lbnd.N != ref.check_ubnd.N
				|| ref.check_lbnd.N != ref.check_anz0.N)
				
		ERROR("check vector dimensions are incorrect");
	
	ref.sym_bnds = (ref.check_lbnd == -ref.check_ubnd); // NEW

	return i;
}

/*
	The output / write operator
*/
template <typename REAL_FRIEND>
ostream& operator<< (ostream &o, 
		Lattice<REAL_FRIEND> const &ref) 
{
	o << ref.B_curr << endl;
	o << ref.T << endl;
	o << ref.B << endl; 

	return o;
}

template <typename REAL>
void Lattice<REAL>::fipo_enum() 
{
	register long i, j, k, l, n;
	register long noit = 0;
	
	bool new_bound = true;

	time_t elapsedTime;

	Matrix<REAL> A, Bt, Q;
	Vector<REAL> U, L, BND, best_b, b, x;
	REAL bnd, min, tmp, Z;

	Bt = B_curr.transpose();
	A = B_curr*Bt;
	
	n = M;

	U.resize(n);
	L.resize(n);
	BND.resize(n);
	x.resize(n);

	U.clear();
	L.clear();
	BND.clear();
	x.clear();
	
	time(&elapsedTime);

	// [Cholesky -- Start]
	
	Q.resize(n, n);
	Q.clear();

	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			Q[i][j] = A[i][j];
	i = 0;
	while (1) {
		i++;
		if (i == n)
			break;

		for (j=i+1; j<=n; j++) {
			Q[j][i] = Q[i][j];
			Q[i][j] = Q[i][j] / Q[i][i];
		}

		for (k=i+1; k<=n; k++)
			for (l=k; l<=n; l++)
				Q[k][l] = Q[k][l] - Q[k][i] * Q[i][l];
	}
	
	// [Cholesky -- End]

	best_b = B_curr[1];
 	min = best_b.quad_euklid_norm();
	bnd = min;

	// Fincke/Pohst -- Start]
	
	cerr << "-> Full Fincke-Pohst Enumeration ..." << endl;
	
	i = n;
		
	do {
		while (1) {
			noit++;

			if (new_bound) {
				U[i] = 0;
				for (j=i+1; j<=n; j++)
					U[i] += Q[i][j] * x[j];
						
				if (i == n)
					BND[n] = bnd;
				else {
					BND[i] = x[i+1] + U[i+1];
					BND[i] *= BND[i];
					BND[i] *= -Q[i+1][i+1];
					BND[i] += BND[i+1];
				}
						
				Z = SQRT(BND[i] / Q[i][i]);
				L[i] = FLOOR(Z - U[i]);
				x[i] = CEIL(-Z - U[i]) - 1;
				new_bound = false;
			}
		
			x[i]++;

			if (x[i] <= L[i]) { 
				if (i > 1) {
					i--;
					new_bound = true;
				} else 
					break;
			}  else
				i++;
		} 

		if (x*x != 0) {
			
			b = Bt * x;
			check_solution(b);

			if ((tmp = b.quad_euklid_norm()) < min) {
				best_b = b;
				min = tmp;
			}
/*
 			cout << b << endl;
			cout << bnd << endl;

			cout << "||b||² = ";
			cout << (bnd - BND[1]) + Q[1][1]*(x[1] + U[1])*(x[1] + U[1]);
			cout << endl;
			cout << "norm: " << SQRT(b.quad_euklid_norm());
			cout << endl;

			// Probe (Debugging)
			
			RR qx, sum;
			qx = 0;
			
			for (j=1; j<=n; j++) {
				sum = x[j];
				for (k=j+1; k<=n; k++)
					sum += Q(j, k) * x(k);
				sum = sum*sum;
				qx += Q(j, j) * sum;
			}
			
			cout << "qx = " << qx << endl;
*/
		}

	} while (x*x != 0);

	// Fincke/Pohst -- End]

	cerr << "   |-> iters: " << noit << ", running time: ";
	print_time(cerr, (time(NULL) - elapsedTime));
	cerr << endl;
}

#if 0
///////////////////////////////////////////////////////////////////////////

template <typename LAT_DTYPE, typename GSO_DTYPE>
bool Lattice<LAT_DTYPE, GSO_DTYPE>::hoelder_prune(register long N, 
		register long level, LAT_DTYPE bnd) 
{	
	GSO_DTYPE cc = ctilda[level] / bnd; 
	
	for (int ii=1; ii<=N; ii++) 
		cc -= ABS(Btilda[level][ii]); 
	
	if (cc > epsilon) 
		return true; 
	else 
		return false; 
}

template <typename LAT_DTYPE, typename GSO_DTYPE>
bool Lattice<LAT_DTYPE, GSO_DTYPE>::last_line_prune(register long N, 
		register long level, register long pivot, LAT_DTYPE bnd) 
{
	if (level < pivot && ABS(ABS(Btilda[level][N]) - bnd) > 0.5) 
		return true;
	else
		return false;
}

template <typename LAT_DTYPE, typename GSO_DTYPE>
void Lattice<LAT_DTYPE, GSO_DTYPE>::wama_enum(register long t, register long m, LAT_DTYPE bnd) 
{
	register long s;
	Lattice lat;

	if (CVP) {
		lat = sublattice(t, m-1, 1, N);

		lat.resize(lat.M + 1);
		lat.B_curr[lat.M] = _d;
	} else
		lat = sublattice(t, m, 1, N);

	lat.wama_enum(bnd);
	for (s=0; s<lat.S; s++)
		check_solution(lat.solution[s]);
}

template <typename LAT_DTYPE, typename GSO_DTYPE>
void Lattice<LAT_DTYPE, GSO_DTYPE>::wama_enum(LAT_DTYPE bnd) 
{
	time_t elapsedTime;
	bool is_solution;

	register long i, j;
	register long noit, nosol, maxit, maxsol;
	register long level, level_max, first_nonzero_in_last_row;
	
	LAT_DTYPE l0_bound, l2_bound;
	
	maxit = -1;
	maxsol = 2147483647;
	
	first_nonzero_in_last_row = 0;
	
	l0_bound = 1; // gilt nur wenn 0/1 bzw -1/1 Lösungen gesucht sind

	compute_gs_classic();
	compute_bdach();

	for (i=1; i<=M; i++) {
		if (B_curr[i][N] != 0) {
			first_nonzero_in_last_row = i;
			break;
		}
	}

	if (!first_nonzero_in_last_row)
		ERROR("first_nonzero doesn't exist!");

//	l2_bound = N * l0_bound * l0_bound;
//	cerr<< "l2: " << l2_bound << ", bnd: " << bnd << endl;
	l2_bound = bnd;

	for (i=1; i<=M; i++) {
		vt_set[i].curr_element->Delta = 0;
		vt_set[i].curr_element->delta = 1;
		vt_set[i].curr_element->pvc = true;
	}
	
	for (i=1; i<=M+1; i++) 
		Btilda[i].clear();

	ctilda.clear();
	utilda.clear();
	vt_set.clear();
	ytilda.clear();

	level = first_nonzero_in_last_row;
	level_max = level;

	noit = 0;
	nosol = 0;
	
	vt_set[level].curr_element->vtilda = 1;
	utilda[level] = 1;

	time(&elapsedTime);

	cerr << " |-> Wassermann Enumeration ..." << endl;

	while (level <= M) {
		noit++;

		if (maxit >= 0 && noit >= maxit) {
			cerr << "Maximum number of iterations reached -> exit\n";
			break;
		}

		GSO_DTYPE dum = utilda[level] + ytilda[level];
		ctilda[level] = ctilda[level+1] + dum*dum*c[level];

		if (ctilda[level] > (l2_bound+epsilon)){
			level++;

			if(level > M)
				continue;

			if(level_max < level) 
				level_max = level;

			if (vt_set[level].curr_element->pvc == false) {
				vt_set[level].curr_element->Delta *= -1;

				if (vt_set[level].curr_element->Delta * 
						vt_set[level].curr_element->delta >= 0)
							vt_set[level].curr_element->Delta += 
								vt_set[level].curr_element->delta;
			} else {
				vt_set[level].curr_element->Delta +=
					(vt_set[level].curr_element->Delta *
					 	vt_set[level].curr_element->delta >= 0) 
							? vt_set[level].curr_element->delta 
							: -vt_set[level].curr_element->delta;
			}

			utilda[level] = vt_set[level].curr_element->vtilda + 
									vt_set[level].curr_element->Delta;

		} else {
			for (j=1; j<=N; j++)
				Btilda[level][j] = Btilda[level+1][j] + dum*Bdach[level][j];

			if (level > 1) {
				if (last_line_prune(N, level, first_nonzero_in_last_row, l0_bound) 
						|| hoelder_prune(N, level, l0_bound)) {

					if (vt_set[level].curr_element->pvc == true) 
						level++;
					else
						vt_set[level].curr_element->pvc = true;

					if(level > M)
						continue;

					if (level_max < level) 
						level_max = level;

					if (vt_set[level].curr_element->pvc == false) {
						vt_set[level].curr_element->Delta *= -1;

						if (vt_set[level].curr_element->Delta * 
								vt_set[level].curr_element->delta >= 0)
									vt_set[level].curr_element->Delta += 
										vt_set[level].curr_element->delta;
					} else {
						vt_set[level].curr_element->Delta +=
							(vt_set[level].curr_element->Delta * 
							 	vt_set[level].curr_element->delta >= 0)
									? vt_set[level].curr_element->delta 
									: -vt_set[level].curr_element->delta;
					}

					utilda[level] = vt_set[level].curr_element->vtilda + vt_set[level].curr_element->Delta;

				} else {
					level--;
					vt_set[level].curr_element->pvc = false;
					vt_set[level].curr_element->Delta = 0;
					ytilda[level] = 0.0;

					for(i=level_max; i>level; i--)
						ytilda[level] += mu[i][level] * utilda[i];

					vt_set[level].curr_element->vtilda = ROUND(-ytilda[level]);
					vt_set[level].curr_element->delta = 
						(vt_set[level].curr_element->vtilda > -ytilda[level]) 
							? -1 : 1;

					utilda[level] = vt_set[level].curr_element->vtilda;
				}

			} else {

				if (!hoelder_prune(N, level, l0_bound)) {
					Vector<LAT_DTYPE> erg;
					erg.resize(N);
					erg.clear();

					for (i=1; i<=M; i++)
						erg += B_curr[i] * utilda[i];

					check_solution(erg);

					is_solution = true;
					for (j=1; j<=erg.N; j++) 
						if (ABS(erg[j]) != l0_bound) {
							is_solution = false;
							break;
						}

					if (is_solution) {
						
						cerr << "Solution: " << erg << endl;
						nosol++;
						
						if (nosol >= maxsol) {
							cerr << "Maximum number of solutions reached -> exit\n";
							break;
						}
					}
				} 

				if (level > M)
					continue;

				if (level_max < level) 
					level_max = level;

				if (vt_set[level].curr_element->pvc == false) {
					vt_set[level].curr_element->Delta *= -1;

					if (vt_set[level].curr_element->Delta * 
							vt_set[level].curr_element->delta >= 0)
								vt_set[level].curr_element->Delta += 
									vt_set[level].curr_element->delta;
				} else {
					vt_set[level].curr_element->Delta += 
						(vt_set[level].curr_element->Delta * 
						 	vt_set[level].curr_element->delta >= 0)
								? vt_set[level].curr_element->delta 
								: -vt_set[level].curr_element->delta;
				}

				utilda[level] = vt_set[level].curr_element->vtilda + 
					vt_set[level].curr_element->Delta;
			}
		}
	}

	cerr << " |    |-> iters: " << noit << ", running time: ";
	print_time(cerr, (time(NULL) - elapsedTime));
	cerr << endl;
	cerr << " |    |-> solutions found: " << nosol;
	cerr << endl;
}
#endif

#if 0
/* 
	This function computes det(R_v,k) for all v = 0,1,...,m-k 
	and chooses in dependence of the boolean parameter max a random index 
	which either maximizes r_v+1,v+1 / det(R_v,k)^(1/k) or
	minimizes r_v+k,v+k / det(R_v,k)^(1/k).
*/

/*
	This method pads a vector with zeroes 
	before the front and after the end.
*/
template <typename REAL>
void Lattice<REAL>::coord_extend(Vector <REAL> &coord_ex, 
		Vector <REAL> const &coord, register long start, register long end, 
		register long dim)
{
	register long j;

	if (start > end || end > dim)
		ERROR("coord_extend index error");

	coord_ex.resize(dim);
	for (j=1; j<start; j++)
		coord_ex[j] = 0;
	for (j=start; j<=end; j++)
		coord_ex[j] = coord[1+j-start];
	for (j=end+1; j<=dim; j++)
		coord_ex[j] = 0;
}

/*
 	Primal-Dual random sampling
*/
template <typename REAL>
bool Lattice<REAL>::pds(register long k, register long m, 
		register double delta, register long gsa)
{
	if (!gsa)
		return false;

	register long v, i, j;

	Vector<REAL> coord, coord_ex;
	Lattice<REAL> dual_lat;

	k = LMAX(3, k);

	if (k > m)
		return false;

	if (VERB >= 2) {
		cerr << "-> Primal-Dual Sampling ( k = " << k << ", m = ";
		cerr << m << " ) ..." << endl;
	}

	compute_lengths();
	
	// Primaler Fall

	// Randomly select the index v, which maximizes
	// 	r_v+1,v+1 / det(R_v,k)^(1/k)

	v = compute_minmax_block(k, m, true);

	if (v == -1) 
		return false;

	if (short_sr(v+1, v+k, delta, gsa)) {
		primal_cnt++;

		return true;
	}

	// Dualer Fall

	// Randomly select the index v, which minimizes 
	// 	r_v+k,v+k / det(R_v,k)^(1/k)

	v = compute_minmax_block(k, m, false);

	if (v == -1) 
		return false;

	compute_bstar(dual_lat);
/*
/////////////////////////////////////////////////

	Matrix<REAL> R, R_inv;
	Lattice<REAL> dual_lat;

	R.resize(M, M);

	for (i=1; i<=M; i++)
		for (j=1; j<=M; j++)
			R[i][j] = (mu[j][i] * SQRT(c[i]));

	R_inv = R.inverse(true, true);
	//gnf_lat.B = R_inv;
	
	/////////////////////////////////////////////////
*/	

#ifdef REVERSED
 	j = m / 2;
	for (i=1; i<=j; i++)
		dual_lat.swap(i, m-i+1);
#endif

	for (i=1; i<=k; i++)
		dual_lat.swap(i, v+i);
	
	dual_lat.resize(k);
	dual_lat.compute_lengths();

	if (dual_lat.short_sr(coord, 1, k, delta, gsa)) {
      coord_extend(coord_ex, coord, v+1, v+k, m);
		basis_replace_dual(coord_ex, v+1, v+k);
		dual_cnt++;

		return true;
	} 

	return false;
}
#endif
