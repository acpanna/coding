#ifndef DEFS__H
#define DEFS__H

#define ASSERT(x)		(assert((x)))


#define ISNAN(x)		(isnan((x)))
#define TO_LONG(i) 		((long) (i))
#define TO_REAL(i) 		((double) (i))
	
typedef double REAL;


#define CEIL(x)		(ceil((x)))
#define FLOOR(x)	(floor((x)))

#define SQRT(x)		(sqrt((x)))
#define POW(x, y)	(pow((x), (y)))
#define LOG(x)		(log((x)))


/* Defines the loop limit for root computations 
	and defines the global epsilon variable */
#define LOOP_LIMIT 10000000

/* Defines the maximum value which the entries of the
   transformation matrix are allowed to have */
#define T_MAX_VAL 1000 

/* Defines the maximum number of transformation matrices
 	to keep on the transformation stack in order to prevent 
	precision errors */
#define T_MATRIX_NUMBER 100

/* Defines the number of precomputed primes */
#define PRIMES 1000

#endif
