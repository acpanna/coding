#ifndef FUNCTIONS__H
#define FUNCTIONS__H

#include <cstdlib>
#include <string>
#include <iostream>

#include <cmath>
#include <cassert>
#include <unistd.h>

#include "defs.h"

inline REAL ROUND(REAL const &x) 
{ 
	REAL y, o5;
	o5 = 0.5;
		
	if (x >= 0) {
		y = x - o5;
		return CEIL(y);
	} else {
		y = x + o5;
		return FLOOR(y);
	}
}

inline REAL ABS(REAL const &x) 
{ if (x >= 0) return x; else return -x; }

inline REAL FMAX(REAL const &x, REAL const &y) 
{ if (x > y) return x; else return y; }

inline REAL FMIN(REAL const &x, REAL const &y) 
{ if (x < y) return x; else return y; }

inline long LMAX(long x, long y) 
{ if (x > y) return x; else return y; }

inline long LMIN(long x, long y) 
{ if (x < y) return x; else return y; }


void send_signal(long signal);

unsigned int new_seed(unsigned int seed = 0);

void print_time(std::ostream &s, time_t t);

std::ostream &ext_prec(std::ostream &out);
std::ostream &std_prec(std::ostream &out);

long min_prime_factor(register long nbr);
long median_prime_factor(register long nbr);
long max_prime_factor(register long nbr);

REAL pow2(REAL const &base);

long rand_eq_long(register long min, register long max);
REAL rand_eq_real(REAL const &min, REAL const &max);

REAL rand_norm(REAL const &min, REAL const &max);

REAL ggT(REAL const &x, REAL const &y);
REAL kgV(REAL const &x, REAL const &y);

REAL modulo(REAL const &value, REAL const &modul);
REAL extended_euclid(REAL const &a, REAL const &b, REAL &s, REAL &t);

#endif
