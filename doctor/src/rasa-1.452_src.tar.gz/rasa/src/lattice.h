#ifndef LATTICE__H
#define LATTICE__H

#include "set.h"
#include "stage.h"
#include "sample.h"
#include "solution.h"

#include "matrix.h"

#include <ctime>

template <typename REAL>
class Lattice {

	public:
		Lattice(void);
		Lattice(Matrix<REAL> const &lat_mat, long verbose = 0);
		~Lattice();
		
		Lattice<REAL> const & operator=(Matrix<REAL> const &lat_mat);
	
		void resize(register long m, register long n = 0);
	
		void init_params(string dbase, register long verbose, 
				register long btime, register bool trans, register double alpha, 
				register double delta, register long beta, register long deep, 
				register long eprune, register long eenum, 
				register bool pwr, register long sieve, register long heu, 
				register long gsa, register bool prj, register long slimit);

		void swap(register long i, register long j); 
		
		long rank(void) const;
	
		void compute_gs_qr(register long k = 0, register long m = 0); 
		void compute_lengths(register long k = 0, register long m = 0);
		void compute_bstar(Lattice &dual_lat);

		bool compute_lat_coords(Vector<REAL> const &b, Vector<REAL> &u); 
		
		long remove_zero_vecs(void);
		long remove_int_deps(void);

		void reduce_loop(void);

		void pair_reduce(void); 
		bool best_heu_insert(void); 

		void sort(bool euklid = false);

		void shortest_heu_to_end(void);
		void shortest_euklid_to_start(void);
		
		void shuffle(void);
	
		void variate(void); 
		
		long lll(void);

		void bkz(bool oo_norm = false, bool enum_only = false); 

		bool exshort_sr(register long k, register long m);
	
		void sieve(double gamma); 
		
		void check_solution(void);
		
		bool check_solution(Vector<REAL> &ref);
		bool check_best_heu(Vector<REAL> &ref); 
		bool check_best_slk(Vector<REAL> const &ref);
		
		void check_trans(void);

		void print_best_heu(void);
		void print_best_slk(void);

		void print_stats(void);
		void print_sol(void);
		
		void write_nrm(void);
		void write_map(void);

	private:
		void init(void);
		
		void new_solution(Vector<REAL> const &ref);
		
		void check_solution(register long i);

		void check_solution(Vector<REAL> const &coord,
				register long jj, register long kk);
		
		bool check_best_heu(register long i); 

		REAL slk_abw(Vector<REAL> const &vec);

		void compute_bstar(Lattice &dual_lat, register long k, register long m); 
		
		bool remove_int_dep(register long k);
		bool blend_out(register long k);
		void reset_blending(void);

		void compute_gs_classic(register long k);
		void compute_gs_classic(register long k, register long m);

		void compute_gs_classic(void);
		
		void compute_bdach(register long k, register long m);
		
		bool size_reduce(register long k);

		long deep_reduce(register long k);
		long lovasz_reduce(register long k);

		long lll(register long k, register long m);
	
		void compute_ytilda(register long t, register long ss);

		REAL best_bound(register long u, register long k, register long m, 
				REAL const &delta_c_k) const;
		
		REAL regula_falsi(
				REAL (Lattice::*f)(Vector<REAL> const &, 
					register long, register long, register long, REAL const &) const, 
				Vector<REAL> const &len, register long k, register long u, 
				register long m, REAL const &delta_c_k, REAL &a, REAL &b) const;

		REAL exp_length(Vector<REAL> const &len, 
				register long k, register long u, register long m, 
				REAL const &q) const;

		REAL log_success_prob_bound(Vector<REAL> const &len, 
				register long k, register long u, register long m, 
				REAL const &delta_c_k) const;

		long compute_usa(register long k, register long m) const; 

		REAL compute_pi(Vector<REAL> const &lambda, REAL const &len,
				register long k, register long m);
		
		void sa(Sample<REAL> * const sam, 
				register long k, register long m, register long u);

		void basis_replace(Vector<REAL> &coord, 
				register long k, register long m, register long l = 0);
		
		void basis_replace_dual(Vector<REAL> &coord,
				register long k, register long m);

		REAL niveau_function(Vector<REAL> const &vec, register long t);

		void check_utilda(register long t, register long ss);

		void next_utilda(register long t, register long ss);

		void compute_stage(register long t, register long ss);

		long buchmann_strategy(register long k, register long m) const; 
		long schnorr_strategy(register long k, register long m) const;
		long vogel_strategy(register long k, register long m) const;

		bool variate_sol(void); 

		void babai(Matrix<REAL> const &L, 
				Matrix<REAL> const &R, Vector<long> const &pmt, 
				Vector<REAL> const &vec, Vector<REAL> &lat_vec); 

		void fill_sieve(void); 

		void basis_extend(Vector<REAL> &u, 
				register long jj, register long kk); 

		void basis(Vector<REAL> &u, 
				register long jj, register long kk); 

		REAL anz_chk_abw(Vector<REAL> const &vec); 
		
		REAL max_chk_abw(Vector<REAL> const &vec); 

		REAL all_chk_abw(Vector<REAL> const &vec); 
		
		REAL def_chk_abw(Vector<REAL> const &vec);  
/*	
		bool pds(register long k, register long m);
		long compute_minmax_block(register long k, register long m, 
				register bool max); 

		void coord_extend(Vector<REAL> &coord_ex, 
				Vector<REAL> const &coord, 
				register long start, register long end, register long dim);
*/
		void fipo_enum(void); // NEW

		void scale(bool reset = false); // NEW
		void extract_inhomogenous_part(bool full = false); // NEW

		void dbase_commit(void);

		template <typename REAL_FRIEND>
		friend std::istream& operator>> (std::istream &i, 
				Lattice<REAL_FRIEND> &ref);

		template <typename REAL_FRIEND>
		friend std::ostream& operator<< (std::ostream &o, 
				Lattice<REAL_FRIEND> const &ref);
	
	public:

		time_t create_time;

		long iters;
		long ineq;

		long M, N;
		long S;

		Matrix<REAL> B_curr, B, T;
	
		/*************************************************/
		/* TT is a vector which contains the unimodular, */
		/*      transformation matrices such that:       */
		/*                                               */
		/*   B = TT[TT.N - 1] * ... * TT[1] * B_orig     */
		/*      and: T = TT[T.N], B_curr = T * B         */
		/*************************************************/
	
		Vector<Matrix<REAL> > TT;
		
		Vector<REAL> check_lbnd;
		Vector<REAL> check_ubnd;
		Vector<REAL> check_anz0;
		
		Vector<REAL> check_c;
		
		bool sym_bnds;
		
		std::string params;

		std::string nrm_file;
		std::string map_file;

	private:
	
		bool TRANS;	
		
		double ALPHA;
		double DELTA;
		
		long BETA;
		long DEEP;
	
		long EPRUNE;
		long EENUM;
		
		bool SCALE;

		bool PWR;
		long SIEVE;
		
		long GSA;
		bool PRJ;
		long SLIMIT;
		
		string dbase_str;

		long VERB;
		long BTIME;
		
		Matrix<REAL> mu;
		Matrix<REAL> Bdach; 
		Matrix<REAL> Bgram;
		Matrix<REAL> Btilda;
				
		Vector<REAL> b;
		Vector<REAL> c;

		Vector<Stage> stage; 

		REAL scale_factor;
		
		long b_min_idx;
		long b_max_idx;
		long c_min_idx;
		long c_max_idx;

		REAL b_min;
		REAL b_max;
		
		REAL c_min;
		REAL c_max;

		REAL best_heu_abw; 
		REAL best_heu_norm;
		REAL best_slk_abw; 
		
		Solution<REAL> best_heu, best_slk, *solution;
		
		Set<Vector<REAL> > sieve_set;

		long triv_sub;
		long ntriv_sub;

		long deep_cnt;
		long pair_cnt;
		long short_cnt;
		long eshort_cnt;

		long heu_improve; 
		long slk_improve; 

		bool heu_update;

		REAL (Lattice::*abw_fptr)(Vector<REAL> const &vec);
};
		
#include "lattice.cpp"

#endif
