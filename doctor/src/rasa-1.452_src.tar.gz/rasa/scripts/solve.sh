#!/bin/sh

FILE=${1%.prb}

echo "================================"
echo "  Solving integer linear system:"
echo "================================"

echo ""

if [ -f ${FILE}.lat ] ; then
	echo "Lattice file already exists -- skipping prb2lat"
else
	./prb2lat $1
fi

echo ""

./rasa --sol=1 --verb=0 --eenum=1 --sieve=0 --heu=3 --gsa=1 --prj=1 --deep=20 ${FILE}.lat

echo ""

for i in ${FILE}.map_* ; do
	./check_map $i 
done
