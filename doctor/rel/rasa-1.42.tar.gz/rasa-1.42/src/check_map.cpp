#include "matrix.h"
#include "globals.h"

#include <fstream>
#include <sstream>
#include <cstring>

using namespace std;

enum ResultType { SOL, SLK, HEU };


bool result_check(Matrix<REAL> const &B, Matrix<REAL> const &L, 
		Matrix<REAL> const &R, Vector<long> const &pmt, Matrix<REAL> const &A_u, 
		Matrix<REAL> &A_g, Vector<REAL> const &c, Vector<REAL> const &b_g,
		Vector<REAL> const &l_u, Vector<REAL> const &r_u, Vector<REAL> const &r_x,
		REAL const &r,  register long n, register long sdim, register long ineq, 
		register long idx, REAL const &val, bool prb_exists, bool aardal, 
		ResultType rtype, Vector<REAL> &x_lat, string const &params, 
		ofstream &fout);

bool transformation_check(Matrix<REAL> &B_in, Matrix<REAL> &B_curr, 
		Vector<Matrix <REAL> > &TT); 

void remove_close(string const &ostr, ofstream &fout);

void usage(char *prg);


int main(int argc, char **argv)
{
	ofstream fout;
	long idx, ineq;
	
	char *ptr, buff[4096];
	register long i, n = 0, sdim = 0;
	bool prb_exists = true, aardal = true;

	string mstr, lstr, pstr, istr, ostr, params;

	Matrix<REAL> A_u, A_g, B_in, B_curr, T, B, L, R;
	Vector<Matrix<REAL> > TT;
	Vector<REAL> c, b_g, l_u, r_u, r_x, tmp_vec, x_lat_heu, x_lat_slk, x_lat_sol;
	Vector<long> pmt;
	
	REAL val, r;

	if (argc > 3 || argc < 2) 
		usage(argv[0]);

	prec = PRECISION;

	for (i=1; i<argc; i++) {
	
		if (strncmp(argv[i], "--help", 6) == 0 || strncmp(argv[i], "-h", 2) == 0)
			usage(argv[0]);
		
		else if (strncmp(argv[i], "--prec=", 7) == 0) {
#ifdef INF_DTYPE
			strcpy(buff, argv[i]+7);
			istringstream iss(buff);
			iss >> prec;
#else
			if (strstr(argv[0], "check_map-rr") == NULL)
				ERROR("Run check_map-rr, if you want to use the prec parameter!");
#endif
		} else if (strncmp(argv[i], "-", 1) == 0) {
			usage(argv[0]);
		} else 
			mstr = argv[i];
	}

#ifdef INF_DTYPE
	NTL::RR::SetPrecision(prec);
	prec = NTL::RR::precision();

	if (prec < PRECISION)
		ERROR("Please use a precision >= " << PRECISION);

	NTL::RR::SetOutputPrecision(EXT_OUT_PRECISION);
#endif

	strcpy(buff, mstr.c_str());
	ptr = strstr(buff, ".map_");

	if (!ptr) 
		usage(argv[0]);
	
	*ptr = 0;
	istr = string(buff);

	lstr = istr + string(".lat");
	pstr = istr + string(".prb");

	ifstream fin_map(mstr.c_str());
	if (!fin_map.good()) 
		ERROR("The map file [ " << mstr << " ] can't be opened!");

	ifstream fin_lat(lstr.c_str());
	if (!fin_lat.good()) 
		ERROR("The lattice file [ " << lstr << " ] can't be opened!");

	ifstream fin_prob(pstr.c_str());
	if (!fin_prob.good()) 
		prb_exists = false;
	
	cerr << "[ file: " << mstr << " ]" << endl;

	getline(fin_map, params);
	
	fin_map >> B_curr;
	fin_map >> TT;

	fin_lat >> B_in;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;

	fin_lat >> c;

	if (c.N == 0) {
		r = 0;
		idx = 0;
		val = 0;
		ineq = 0;
	} else {
		fin_lat >> r;
		fin_lat >> idx;
		fin_lat >> val;
		fin_lat >> ineq; 
	}

	fin_lat.close();

	if (prb_exists) {

		fin_prob >> A_u;
		fin_prob >> A_g;
		fin_prob >> l_u;
		fin_prob >> r_u;
		fin_prob >> b_g;
		fin_prob >> r_x; 

		fin_prob >> aardal;

		fin_prob.close();

		sdim = r_x.N; 
		ineq = A_u.M;	

		if (ineq > 0)
			n = A_u.N;
		else
			n = A_g.N;
	}

	transformation_check(B_in, B_curr, TT);

	B = B_in.transpose();
	B.gauss(L, R, pmt);

	///////////////////////////////////////////

	ostr = istr + string(".heu");
	fout.open(ostr.c_str(), std::ios::app);
	read_vector(fin_map, x_lat_heu);

	result_check(B, L, R, pmt, A_u, A_g, c, b_g, l_u, r_u, r_x, r, n, sdim,
			ineq,	idx, val, prb_exists, aardal, HEU, x_lat_heu, params,	fout);

	remove_close(ostr, fout);
	
	///////////////////////////////////////////

	ostr = istr + string(".slk");
	fout.open(ostr.c_str(), std::ios::app);
	read_vector(fin_map, x_lat_slk);

	result_check(B, L, R, pmt, A_u, A_g, c, b_g, l_u, r_u, r_x, r, n, sdim, 
			ineq,	idx, val, prb_exists, aardal, SLK, x_lat_slk, params, fout);

	remove_close(ostr, fout);
	
	///////////////////////////////////////////

	ostr = istr + string(".sol");
	fout.open(ostr.c_str(), std::ios::app);

	while (read_vector(fin_map, x_lat_sol)) 
		result_check(B, L, R, pmt, A_u, A_g, c, b_g, l_u, r_u, r_x, r, n, sdim, 
				ineq, idx, val, prb_exists, aardal, SOL, x_lat_sol, params, fout);

	remove_close(ostr, fout);
	
	///////////////////////////////////////////

	fin_map.close();
}


bool result_check(Matrix<REAL> const &B, Matrix<REAL> const &L, 
		Matrix<REAL> const &R, Vector<long> const &pmt, Matrix<REAL> const &A_u, 
		Matrix<REAL> &A_g, Vector<REAL> const &c, Vector<REAL> const &b_g, 
		Vector<REAL> const &l_u, Vector<REAL> const &r_u, Vector<REAL> const &r_x,
		REAL const &r,  register long n, register long sdim, register long ineq, 
		register long idx, REAL const &val, bool prb_exists, bool aardal,	
		ResultType rtype, Vector<REAL> &x_lat, string const &params, 
		ofstream &fout)
{
	register long i, j, m;

	Vector<REAL> coord, modul_vec, null, x_prob, x_lat_sub;

	REAL len, slack_norm, two;
	two = 2;

	if (x_lat.N == 0)
		return false;

	/****************************************/
	/*                                      */
	/*   Hier wird zunächst überprüft, ob   */
	/* x_lat im ursprünglichen Gitter liegt */
	/*                                      */
	/****************************************/

	if (compute_coords(L, R, pmt, x_lat, coord, true) != 1) {
		cerr << "check_sol: could not compute valid coords!" << endl;
		return false;
	}

	if (B*coord != x_lat) {
		cerr << "B*coord - x_lat = " << (B*coord - x_lat) << endl;
		return false;
	}

	if (rtype == HEU)
		prb_exists = false;

	if (prb_exists) {

		if (x_lat[x_lat.N] < 0)
			x_lat = -x_lat;

		if (x_lat[x_lat.N] != r) {
			cerr << "Inconsistency 0 detected" << endl;
			return false;
		}

		/******************************************************************/
		/*																						*/
		/*	In the case: aardal == 0 && ineq > 0, x_lat should look like:  */
		/*																					   */
		/*		[ (2*A_u*x_prob - (l_u + r_u)) | 0,0, ... 0 | 				   */
		/*			-r + 2*c[1]*x_prob[1], ...,-r + 2*c[sdim]*x_prob[sdim]   */
		/*		| r ]																		   */
		/*																					   */
		/*	The zeroes represent: A_g*x_prob - b_g (which should be null!) */
		/*	and they weren't stripped off, because the Aardal step has     */
		/*	been omitted.																	*/
		/*																						*/
		/*	In cases where AARDAL == 1 -- the zeroes are stripped off.		*/
		/*																						*/
		/******************************************************************/

		if (aardal)
			m = ineq;
		else 
			m = ineq + A_g.M;

		x_prob.resize(sdim);

		/**********************************************************/
		/* In the general case, when x_lat[x_lat.N] == r we have: */
		/*				x_lat[j] = -r + 2*c[j]*x_prob[j]					 */
		/**********************************************************/

		for (j=1; j<=idx; j++) 
			x_prob[j] = (1 + x_lat[j+m]) / (val+1);

		for (j=idx+1; j<=sdim; j++) 
			x_prob[j] = (r + x_lat[j+m]) / (2*c[j+m]);

		if (rtype != HEU) {

			null.resize(sdim);
			null.clear();

			if (!(null <= x_prob && x_prob <= r_x)) {
				cerr << "0 <= x_prob <= r_x is not satisfied!" << endl;
				return false;
			}
		}

		if (sdim < n) {

			if (sdim != 0) { // NTRU - Fall

				if (ineq > 0) {
					cerr << "0 < sdim < A_u.N, ineq > 0 is not implemented!" << endl;
					return false;
				}

				modul_vec.resize(n - sdim);
				for (j=1; j<=modul_vec.N; j++)
					modul_vec[j] = A_g[j][sdim +j];

				A_g.resize(A_g.M, sdim);

				null = A_g*x_prob - b_g;
				for (j=1; j<=modul_vec.N; j++) 
					null[j] = modulo(null[j], modul_vec[j]);

				if (null.is_zero()) {
					cout << ext_prec << "x_prob = " << x_prob << endl;
					fout << ext_prec << x_prob << " | " << params << endl;
				}

			} else {
				cerr << "The case sdim == 0 is not implemented!" << endl;
				return false;
			}

		} else {

			if (A_g.M == 0 || A_g*x_prob == b_g) {

				if (rtype != HEU) {
					if (!aardal) {
						for (j=(m-A_g.M) + 1; j<=m; j++) {
							if (x_lat[j] != 0) { 
								cerr << "Inconsistency 2 detected" << endl;
								return false;
							}
						 }
					}
				}

				slack_norm = 0;

				if (ineq > 0) {

					if (rtype == SOL)
						for (j=1; j<=ineq; j++)
							if (-(r_u[j] - l_u[j]) > x_lat[j] 
									|| x_lat[j] > (r_u[j] - l_u[j])) {
								cerr << "Inconsistency 3 detected" << endl;
								return false;
							}

					x_lat_sub = x_lat;
					x_lat_sub.resize(ineq);

					if ((A_u * x_prob * two - (l_u + r_u)) != x_lat_sub) {
						cerr << x_prob << endl;
						cerr << A_u * x_prob * two - (l_u + r_u) << endl;

						cerr << "Inconsistency 4 detected" << endl;
						return false;
					}

					null = A_u*x_prob;
					if (rtype == SOL) {
						if (!(l_u <= null && null <= r_u)) {
							cerr << "Inconsistency 5 detected" << endl;
							return false;
						}

					} else if (rtype == SLK) {

						for (i=1; i<=ineq; i++) {
							len = FMAX(l_u[i] - null[i], null[i] - r_u[i]);
							slack_norm += FMAX(TO_REAL(0), len);
						}
					}
				}

				cout << ext_prec << "x_prob = " << x_prob;
				if (rtype == SLK)
					cout << " -- Slack_Norm = " << slack_norm;
				cout << endl;

				fout << std_prec;
				if (rtype == SLK)
					fout << slack_norm << " -- ";
				fout << ext_prec << x_prob << " | " << params << endl;

			} else  {

				cerr << "A_g*x_prob = " << A_g*x_prob << endl;
				cerr << "b_g = " << b_g << endl;
				cerr << "x_prob = " << x_prob << endl;
				cerr << "Inconsistency 6 detected!" << endl;
				return false;
			}
		}

	} else {

		len = SQRT(x_lat.quad_euklid_norm());

		cout << ext_prec << "x_lat = " << x_lat << " ∈ L, ";
		cout << "|| x_lat ||_2 = " << std_prec << len << endl;

		fout << std_prec << len << " -- ";
		fout << ext_prec << x_lat << " | " << params << endl;
	}

	return true;
}

bool transformation_check(Matrix<REAL> &B_in, Matrix<REAL> &B_curr, 
		Vector<Matrix <REAL> > &TT) 
{
	register long i;
	Matrix<REAL> A;
	REAL d, d0;

	if (TT.N == 0) {
		cerr << "There is no transformation matrix available!" << endl;
		return false;
	}

	d = 1;
	A = B_in;

	for (i=1; i<=TT.N; i++) {

		d0 = ABS(TT[i].determinant());

		if (ABS(d0 - 1) > 0.4) {
			cerr << "The transformation is not unimodular!" << endl;
			cerr << ext_prec << "|det TT[" << i << "]| = " << d0;
			cerr << ", prec = " << prec << endl;
			return false;
		}
		
		d = d0*d;
		A = TT[i]*A;
	}

	if ((A == B_curr)) {
		cerr << "The transformation is correct and unimodular." << endl;
		return true;
	} else {
		cerr << "The transformation is not correct!" << endl;
		cerr << "prec = " << prec << endl;
		return false;
	}
}

void remove_close(string const &ostr, ofstream &fout)
{
	if (fout.tellp() == 0) {
		fout.close();
		remove(ostr.c_str());
	} else
		fout.close();
}

void usage(char *prg) 
{
	cerr << prg << " [--prec=" << prec << "] file.map_XXXXX" << endl;
	exit(1);
}
