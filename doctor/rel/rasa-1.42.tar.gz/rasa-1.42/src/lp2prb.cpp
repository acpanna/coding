#include "matrix.h"
#include "defs.h"

#include <limits>
#include <iostream>
#include <fstream>
#include <cstring>

#define BUFFER 4096

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " *.lp");
}


/*****************************************************************/
/* Atoi can't recognize the case, where a coefficient is missing */
/* in front of the variable. Atoi interprets this as 0 although  */
/*                 it should be 1 in this case.                  */
/*****************************************************************/

REAL null_check(REAL z, char *p, bool s) 
{
	if (z == 0) {

		while (*p != 'x' && *p != '0') 
			p++;

		if (*p == 'x') {

			if (s) 
				return 1;
			else
				return -1;

		} else
			return 0;

	} else 
		return z;
}

int main(int argc, char **argv)
{
	char buff[BUFFER], *ptr;
	register long i, j, k, n, m_ur, m_ul, m_u, m_g, n_ur, n_ul, n_u, n_g;

	REAL zahl;

	string istr, ostr;

	Matrix<REAL> A_u, A_g;
	Vector<REAL> l_u, r_u, b_g, r_x;
	
	if (argc != 2)
		ERROR("Usage: " + string(argv[0]) + " *.lp");

	istr = string(argv[argc-1]);

	strncpy(buff, argv[argc-1], BUFFER);
	ptr = strstr(buff, ".lp");
	if (ptr == NULL) 
		usage(argv[0]);
	*ptr = 0;

	ostr = string(buff) + string(".prb");

	ifstream fin(istr.c_str());
	if (!fin.good())
		ERROR("The input file [ " + istr + " ] could not be opened!");

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	cerr << "Note: If the lp-file contains an objective function,\n";
	cerr << "you should reformulate it as an inequation l <= ... <= u,\n";
	cerr << "with bounds, which satisfy your needs -- the prb format\n";
	cerr << "can't deal with an objective function!\n";
	cerr << "This converter is not perfect, but it should" << endl;
	cerr << "work correctly, as long as ALL variables are named" << endl;
	cerr << "with a lower case 'x'." << endl;
	cerr << endl;

	/*******************************/
	/* Determine the dimensions of */
	/* the linear equation system  */
	/*******************************/

	while (!fin.eof()) {
		fin.getline(buff, BUFFER);

		if (strcasestr(buff, "Subject To"))
			break;
	}

	m_ul = m_ur = m_g = n_ul = n_ur = n_g = 0;

	while (!fin.eof()) {

		fin.getline(buff, BUFFER);

		if (strcasestr(buff, "Bounds") 
			|| strcasestr(buff, "General")
				|| strcasestr(buff, "Binary"))
			break;
	
		if (strstr(buff, "<=")) {

			ptr = buff; 
			while (*ptr != '\0') {

				if (*ptr == 'x') {
					j = atoi((ptr+1));
					if (j > n_ur) 
						n_ur = j;
				}

				ptr++;
			}

			m_ur++;

		} else if (strstr(buff, ">=")) {

			ptr = buff; 
			while (*ptr != '\0') {

				if (*ptr == 'x') {
					j = atoi((ptr+1));
					if (j > n_ul) 
						n_ul = j;
				}

				ptr++;
			}

			m_ul++;

		} else if (strstr(buff, "=")) {

			ptr = buff; 
			while (*ptr != '\0') {

				if (*ptr == 'x') {
					j = atoi((ptr+1));
					if (j > n_g) 
						n_g = j;
				}

				ptr++;
			}

			m_g++;
		
		} else if (strcmp(buff, "\n") == 0 || strcmp(buff, "\r") == 0 || strcmp(buff, "\r\n") == 0)
				continue;

		else 
			ERROR("The file [ " + string(argv[1]) + " ] is incomplete!");
	}

	if (m_ur != m_ul || n_ur != n_ul)
		ERROR("The amount of <= and >= equations differ!");

	m_u = m_ur;
	n_u = n_ur;

	n = LMAX(n_u, n_g);

	cerr << "InEquations: " << m_u << endl;
	cerr << "Equations: " << m_g << endl;
	cerr << "Variables: " << n << endl;

	r_x.resize(n);
	for (j=1; j<=r_x.N; j++)
		r_x[j] = -1;

	/***************************/
	/* Determine the bounds of */
	/* the involved variables  */
	/***************************/
	
	if (strcasestr(buff, "Bounds")) {

		while (!fin.eof()) {

			fin.getline(buff, BUFFER);

			/********* Uppercase version *********/
			
			string buff_str(buff);
			k = buff_str.length(); 
			for (i=0; i<k; i++)
				buff_str[i] = toupper(buff_str[i]);

			/*************************************/

			if (strstr(buff, "<=")) {
				
				j = 0;
				ptr = buff;

				while (*ptr != '\0') {

					if (*ptr == 'x') 
						j = atoi((ptr+1));

					if (*ptr == '=') {
						if (j == 0) {
							if (atoi(buff) != 0)
								ERROR("You can only use the lower bound 0!");

						} else {
							r_x[j] = atoi(ptr+1);

							if (r_x[j] == 0) {

								// 0 <= x_j <= 0 ist sinnlos 
								// ==> 0 <= x_j <= infinity
								 
								r_x[j] = std::numeric_limits<double>::max();
							}

							j = 0;
						}
					}

					ptr++;
				}
				
			} else if (strcasestr(buff_str.c_str(), "FREE")) {

				ptr = buff;

				while (*ptr != '\0') {

					if (*ptr == 'x') {
						j = atoi((ptr+1));
						
						if (r_x[j] != -1)
							ERROR("Bound Error1 ( j = " << j << " )");

						r_x[j] = 0;
					}

					ptr++;
				}

			} else if (strcmp(buff, "\n") == 0 || strcmp(buff, "\r") == 0 || strcmp(buff, "\r\n") == 0)
				continue;

			else
				break;
		}
	}

	if (strcasestr(buff, "General")) {

		while (!fin.eof()) {
			fin.getline(buff, BUFFER);
			if (strcasestr(buff, "Binary")) 
				break;

			ptr = buff;
			while (*ptr != '\0') {

				if (*ptr == 'x') {
					j = atoi((ptr+1));

					if (r_x[j] == -1)
						r_x[j] = 0;
				}

				ptr++;
			}
		}
	}

	if (strcasestr(buff, "Binary")) {

		while (!fin.eof()) {
			fin.getline(buff, BUFFER);
			
			ptr = buff;
			while (*ptr != '\0') {

				if (*ptr == 'x') {
					j = atoi((ptr+1));

					if (r_x[j] == -1)
						r_x[j] = 1;
				}

				ptr++;
			}
		}
	}

	A_g.resize(m_g, n);
	A_u.resize(m_u, n);
	
	l_u.resize(m_u);
	r_u.resize(m_u);
	b_g.resize(m_g);

	A_u.clear();
	A_g.clear();
	l_u.clear();
	r_u.clear();
	b_g.clear();

	fin.clear();              
	fin.seekg(0, ios::beg); 
	
	while (!fin.eof()) {
		fin.getline(buff, BUFFER);

		if (strcasestr(buff, "Subject To"))
			break;
	}


	/********************/
	/* Read the problem */
	/********************/

	m_ur = 1;
	m_ul = 1;

	m_g = 1;

	while (!fin.eof()) {
		fin.getline(buff, BUFFER);

		if (strcasestr(buff, "Bounds") 
			|| strcasestr(buff, "General")
				|| strcasestr(buff, "Binary"))
			break;
		
		ptr = buff; 
		
		zahl = atoi(ptr);
		zahl = null_check(zahl, ptr, true); 

		if (strcasestr(buff, "<=")) {

			while (*ptr != '\0') {

				if (*ptr == '-') {
					zahl = -atoi(ptr+1);
					zahl = null_check(zahl, ptr, false); 
				}


				if (*ptr == '+') {
					zahl = atoi(ptr+1);
					zahl = null_check(zahl, ptr, true); 
				}

				if (*ptr == 'x') {
					j = atoi((ptr+1));
					A_u[m_ur][j] = zahl;
				}

				if (*ptr == '=') 
					r_u[m_ur] = atoi(ptr+1);
					
				ptr++;
			}

			m_ur++;

		} else if (strcasestr(buff, ">=")) {

			while (*ptr != '\0') {

				if (*ptr == '-') {
					zahl = -atoi(ptr+1);
					zahl = null_check(zahl, ptr, false); 
				}

				if (*ptr == '+') {
					zahl = atoi(ptr+1);
					zahl = null_check(zahl, ptr, true); 
				}

				if (*ptr == 'x') {
					j = atoi((ptr+1));

					if (A_u[m_ul][j] != zahl) 
						ERROR("There seems to miss a lower bound!");
				}

				if (*ptr == '=') 
					l_u[m_ul] = atoi(ptr+1);

				ptr++;
			}

			m_ul++;

		} else if (strcasestr(buff, "=")) {

			while (*ptr != '\0') {

				if (*ptr == '-') {
					zahl = -atoi(ptr+1);
					zahl = null_check(zahl, ptr, false); 
				}

				if (*ptr == '+') {
					zahl = atoi(ptr+1);
					zahl = null_check(zahl, ptr, true); 
				}

				if (*ptr == 'x') {
					j = atoi((ptr+1));
					A_g[m_g][j] = zahl;
				}

				if (*ptr == '=') 
					b_g[m_g] = atoi(ptr+1);

				ptr++;
			}

			m_g++;

		} else if (strcmp(buff, "\n") == 0 || strcmp(buff, "\r") == 0 || strcmp(buff, "\r\n") == 0)
			continue;
			
		else 
			ERROR("The file [ " + string(argv[1]) + " ] is incomplete!");
	}
	
	fin.close();

	/***************************/
	/* Swap the free variables */
	/*  to end of the vector   */
	/*    and resize r_x!      */
	/***************************/

	for (j=1; j<=r_x.N; j++) {
		if (r_x[j] == 0) {

			for (k=j+1; k<=r_x.N; k++)
				if (r_x[k] != 0)
					break;

			if (k <= r_x.N) {

				if (A_u.N > 0) {

					for (i=1; i<=A_u.M; i++) {
						zahl = A_u[i][j];
						A_u[i][j] = A_u[i][k];
						A_u[i][k] = zahl;
					}

					l_u.swap(j, k);
					r_u.swap(j, k);
				}

				if (A_g.N > 0) {

					for (i=1; i<=A_g.M; i++) {
						zahl = A_g[i][j];
						A_g[i][j] = A_g[i][k];
						A_g[i][k] = zahl;
					}

					r_x.swap(j, k);
				}

			} else 
				break;
		}
	}

	if (j-1 < r_x.N)
		r_x.resize(j-1);

	// Write the problem file

	fout << ext_prec << A_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << A_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << l_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << b_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << r_x << endl;
	fout << ext_prec << endl;

	fout << ext_prec << 1 << endl;
	                   
	fout << ext_prec << endl << "// A_u, A_g, l_u, r_u, b_g, r_x, aardal" << endl;

	fout.close();

	return 0;
}
