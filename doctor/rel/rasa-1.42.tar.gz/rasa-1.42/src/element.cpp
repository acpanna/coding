template <class DATATYPE>
Element<DATATYPE>::Element() : prev_element(0), next_element(0) { }

template <class DATATYPE>
Element<DATATYPE>::Element(Element<DATATYPE> const &ref) : prev_element(0), next_element(0) 
{
	*this = ref;
}

template <class DATATYPE>
Element<DATATYPE>::Element(DATATYPE const &ref) : prev_element(0), next_element(0) 
{
	this->content = ref;
}

template <class DATATYPE>
Element<DATATYPE>::~Element()
{ 
	prev_element = 0;
	next_element = 0;
}

template <class DATATYPE>
Element<DATATYPE> & 
Element<DATATYPE>::operator=(Element<DATATYPE> const &ref)
{
	content = ref.content;
	return *this;
}

template <class DATATYPE>
bool Element<DATATYPE>::operator==(Element<DATATYPE> const &ref) const
{
	if (content == ref.content)
		return true;
	else 
		return false;
}

template <class DATATYPE>
bool Element<DATATYPE>::operator!=(Element<DATATYPE> const &ref) const
{
	if (content != ref.content)
		return true;
	else 
		return false;
}

template <class DATATYPE_FRIEND>
std::ostream& operator<< (std::ostream& os, Element<DATATYPE_FRIEND> &e)
{
	os << e.content;
	return os;
}		
