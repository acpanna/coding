#ifndef LATTICE__H
#define LATTICE__H

#include "set.h"
#include "stage.h"
#include "sample.h"
#include "solution.h"

#include "matrix.h"

#include <ctime>

template <typename REAL>
class Lattice {

	public:
		Lattice(void);
		~Lattice();
	
		void resize(register long m, register long n = 0);
		
		void init_params(register long verbose, 
			register long btime, register bool trans, register double alpha, 
			register double delta, register long beta, register long deep, 
			register long nprune, register long eprune, register long scale, 
			register long sieve, register long gsa, register bool prj, 
			register long slimit, register long heu); 

		void swap(register long i, register long j); 
		
		long rang(void) const;
	
		void compute_gs_qr(void); 
		void compute_lengths(void);
		void compute_bstar(Lattice &dual_lat);

		bool compute_lat_coords(Vector<REAL> const &b, Vector<REAL> &u); 
		
		void reduce_loop(void);

		void pair_reduce(void); 
		bool best_heu_insert(void); 

		void sort(void);
		void rev_sort(void);
		
		void shuffle(void);
	
		void variate(void); 
		
		void bkz(register double delta, register long beta); 

		bool exshort_sr(register long k, register long m, 
				register double delta, register long gsa, bool prj);
	
		bool short_sr(register long k, register long m, register double delta, 
				register long gsa);

		bool eshort_sr(register long k, register long m, register double delta, 
				register long gsa);

		void sieve(register double gamma); 

		void scale(void); // NEW

		bool check_solution(Vector<REAL> &ref);
		bool check_best_heu(Vector<REAL> &ref); 
		bool check_best_slk(Vector<REAL> const &ref);
		
		void check_trans(void);

		void print_best_heu(void);
		void print_best_slk(void);

		void print_stats(void);
		void print_sol(void);
		
		void write_nrm(void);
		void write_map(void);

	private:
		void init(void);
		
		void new_solution(Vector<REAL> const &ref);
		
		void check_solution(void);
		
		void check_solution(register long i);

		void check_solution(Vector<REAL> const &coord,
				register long jj, register long kk);
		
		bool check_best_heu(register long i); 

		REAL slk_abw(Vector<REAL> const &vec);

		void compute_bstar(Lattice &dual_lat, register long k, register long m); 
		void compute_gs_classic(void);
		void compute_gs_classic(register long k, register long m);
		void compute_gs_classic(register long k);
		
		void compute_bdach(register long k, register long m);
		
		bool size_reduce(register long k);

		long deep_reduce(register long k, register double delta);
		long lovasz_reduce(register long k, register double delta);

		long lll(register long k, register long m, register double delta);
	
		void compute_utilda_bnds(REAL const &F2, register long t);
	
		bool check_nprune(REAL const &F_oo, REAL const &F_1, REAL const &F_2, 
				REAL const &q, Lattice &dual_lat, register long t);
		
		bool check_utilda(register long t, register long ss);

		REAL compute_bstar_bnd(Vector<REAL> const &Bstar_t, 
				REAL const &F_oo, REAL const &F_1, REAL const &F_2);

		void compute_ytilda(register long t, register long ss);

		long best_bound(register long u, register long k, register long m, 
				REAL const &delta_c_k);
		
		REAL regula_falsi(
				REAL (Lattice::*f)(Vector<REAL> const &, 
					register long, register long, register long, REAL const &), 
				Vector<REAL> const &len, register long k, register long u, 
				register long m, REAL const &delta_c_k, REAL &a, REAL &b);

		REAL exp_length(Vector<REAL> const &len, 
				register long k, register long u, register long m, 
				REAL const &q);

		long log_success_prob_bound(Vector<REAL> const &len, 
				register long k, register long u, register long m, 
				REAL const &delta_c_k);

		long compute_usa(register long k, register long m, 
				register double delta, register long gsa); 
		
		REAL compute_pi(Vector<REAL> const &lambda, REAL const &len,
				register long k, register long m);
		
		void sa(Sample<REAL> * const sam, 
				register long k, register long m, register long u);

		void basis_replace(Vector<REAL> &coord, 
				register long k, register long m, register long l = 0);
		
		void basis_replace_dual(Vector<REAL> &coord,
				register long k, register long m);

		void next_utilda(register long t, register long ss);

		void set_enum_bounds(REAL const &cbar, REAL &F_oo, REAL &F_1, REAL &F_2,
				bool full_enum);

		bool compute_stage(REAL const &F_2, register long t, register long ss);

		long schnorr_strategy(register long k, register long m); 
		long buchmann_strategy(register long k, register long m, 
				register double delta); 

		bool variate_sol(void); 

		void babai(Matrix<REAL> const &L, 
				Matrix<REAL> const &R, Vector<long> const &pmt, 
				Vector<REAL> const &vec, Vector<REAL> &lat_vec); 

		void fill_sieve(void); 

		void scale(register long j, bool max); 
		
		void basis_extend(Vector<REAL> &u, 
				register long jj, register long kk); 

		void basis(Vector<REAL> &u, 
				register long jj, register long kk); 

		REAL anz_chk_abw(Vector<REAL> const &vec); 
		
		REAL max_chk_abw(Vector<REAL> const &vec); 

		REAL all_chk_abw(Vector<REAL> const &vec); 
		
		REAL def_chk_abw(Vector<REAL> const &vec);  

//				bool pds(register long k, register long m, register double delta, 
//				register long gsa);
	
/*	
		long compute_minmax_block(register long k, register long m, 
				register bool max); 

		void coord_extend(Vector<REAL> &coord_ex, 
				Vector<REAL> const &coord, 
				register long start, register long end, register long dim);
*/

//		void inhomogenous_index(register long k, long &m);
//		void extract_inhomogenous_part(void); 

		template <typename REAL_FRIEND>
		friend std::istream& operator>> (std::istream &i, 
				Lattice<REAL_FRIEND> &ref);

		template <typename REAL_FRIEND>
		friend std::ostream& operator<< (std::ostream &o, 
				Lattice<REAL_FRIEND> const &ref);
	
	public:
		time_t create_time;

		long iters;
		long slks;

		long M, N;
		long S;

		Matrix<REAL> B_curr, B, T;
	
		/*************************************************/
		/* TT is a vector which contains the unimodular, */
		/*      transformation matrices such that:       */
		/*                                               */
		/*   B = TT[TT.N - 1] * ... * TT[1] * B_orig     */
		/*      and: T = TT[T.N], B_curr = T * B         */
		/*************************************************/
	
		Vector<Matrix<REAL> > TT;
		
		Vector<REAL> check_lbnd;
		Vector<REAL> check_ubnd;
		Vector<REAL> check_anz0;
		
		std::string params;

		std::string nrm_file;
		std::string map_file;

	private:
		
		bool TRANS;
		
		double ALPHA;
		double DELTA;
		
		long BETA;
		long DEEP;
	
		long NPRUNE;
		long EPRUNE;
		
		long SCALE;
		long SIEVE;
		
		long GSA;
		bool PRJ;
		long SLIMIT;

		long VTS;
		bool RND;
		
		long VERB;
		long BTIME;
		
		Matrix<REAL> mu;
		Matrix<REAL> Bdach; 
		Matrix<REAL> Bgram;
		Matrix<REAL> Btilda;
		
		Vector<REAL> b;
		Vector<REAL> c;
		
		Vector<Stage> stage; // NEW

		Vector<REAL> scale_vector; 

		long b_min_idx;
		long b_max_idx;
		long c_min_idx;
		long c_max_idx;

		REAL b_min;
		REAL b_max;
		
		REAL c_min;
		REAL c_max;

		REAL best_heu_abw; 
		REAL best_heu_norm;
		REAL best_slk_abw; 
		
		Solution<REAL> best_heu, best_slk, *solution;
		
		Set<Vector<REAL> > sieve_set;

		long deep_insert;
		long bkz_nprune;
		
		long triv_sub;
		long ntriv_sub;

		long pair_cnt;
		long short_cnt;
		long eshort_cnt;

		long heu_improve; 
		long slk_improve; 

		bool heu_update;

		REAL (Lattice::*abw_fptr)(Vector<REAL> const &vec);
};
		
#include "lattice.cpp"

#endif
