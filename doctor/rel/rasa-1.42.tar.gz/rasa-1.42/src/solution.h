#ifndef SOLUTION__H
#define SOLUTION__H

#include "vector.h"

template <typename DATATYPE>
class Solution : public Vector<DATATYPE> {

	public:
		Solution();
		Solution(Solution const &ref);
		~Solution();

		Solution const & operator=(Vector<DATATYPE> const &ref);
		Solution const & operator=(Solution const &ref);
	
		template <typename DATATYPE_FRIEND>
		friend std::ostream& operator<< (std::ostream &o, Solution<DATATYPE_FRIEND> const &ref);

	public:
		time_t time;
};

#include "solution.cpp"

#endif
