#ifndef DEFS__H
#define DEFS__H

#include <cmath>
#include <cassert>
#include <NTL/RR.h>
#include <unistd.h>

typedef NTL::RR INF_REAL;

typedef double FIN_REAL;

#ifdef FIN_DTYPE
	#define TO_REAL(i) ((double) (i))
	#define TO_LONG(i) ((long) (i))

	typedef FIN_REAL REAL;
#endif

#ifdef INF_DTYPE
	#define TO_REAL(i) (NTL::to_RR(i))
	#define TO_LONG(i) (NTL::to_long(i))

	typedef INF_REAL REAL;
#endif

#define ASSERT(x)		(assert((x)))

#define CEIL(x)		(ceil((x)))
#define FLOOR(x)		(floor((x)))

#define SQRT(x)		(sqrt((x)))
#define LOG2(x)		(log((x)) / log(2))


#define SC_CNT 50


/* Defines the maximal number of iteration loops 
   for certain approximation functions */
#define LOOP_LIMIT 100000 

/* Defines the maximum difference a REAL value is
 	allowed to have for being considered as zero */
#define EPSILON 0.0000001

/* Defines the maximum value which the entries of the
   transformation matrix are allowed to have */
#define T_MAX_VAL 10000 

/* Defines the maximum number of transformation matrices
 	to keep on the transformation stack in order to prevent 
	precision errors */
#define T_MATRIX_NUMBER 1000

/* Defines the standard width of the utilda interval */
#define BANDWIDTH	10

/* Defines the standard computing precision */
#define PRECISION	64

/* Defines the standard / extended output precision*/
#define STD_OUT_PRECISION 8
#define EXT_OUT_PRECISION 1000

/* Defines the number of precomputed primes */
#define PRIMES 1000

#endif
