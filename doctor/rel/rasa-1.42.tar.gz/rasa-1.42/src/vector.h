#ifndef VECTOR__H
#define VECTOR__H

#include <iostream>
#include <fstream>

#include "defs.h"
#include "error.h"

template <typename DATATYPE>
class Vector {

	public:
		Vector();
		Vector(register long n);
		Vector(Vector const &ref);
		virtual ~Vector(); 

		Vector const & operator= (Vector const &ref);
		Vector const & operator+=(Vector const &ref);
		Vector const & operator-=(Vector const &ref);

		Vector const & operator*=(Vector const &ref);
		Vector const & operator/=(Vector const &ref);

		Vector const & operator*=(DATATYPE const &ref);
		Vector const & operator/=(DATATYPE const &ref);
		Vector const & operator%=(DATATYPE const &ref);
				
		Vector operator+(Vector const &ref) const;
		Vector operator-(Vector const &ref) const;
		Vector operator/(Vector const &ref) const;
		
		Vector operator*(DATATYPE const &ref) const;
		Vector operator/(DATATYPE const &ref) const;
		Vector operator%(DATATYPE const &ref) const;
		
		DATATYPE operator*(Vector const &ref) const;
		DATATYPE & operator[] (register long j) const;

		Vector operator-(void) const;

		bool operator==(Vector const &ref) const;
		bool operator!=(Vector const &ref) const;
		bool operator<=(Vector const &ref) const;
		bool operator>=(Vector const &ref) const;

		bool check_finite(register long k, DATATYPE &bnd) const; 
		bool is_abs_equal(Vector const &ref) const;
		
		long zeroes(void) const;

		bool is_zero(void) const;
		bool is_sparse(void) const;

		void resize(register long n);
		void swap(register long i, register long j);
		void clear(register long start = 0, register long end = 0);

		void push_back(DATATYPE &dat);
		
		DATATYPE value(void) { return quad_euklid_norm(); } const
		
		DATATYPE quad_euklid_norm(void) const;
		DATATYPE eins_norm(register long n = 0) const;
		DATATYPE sup_norm(void) const;

		void print_subvector(register long i, register long j) const;
		DATATYPE gcd(register long i, register long j) const;

		template <typename DATATYPE_FRIEND> 
		friend std::istream& operator>> (std::istream &i, 
				Vector<DATATYPE_FRIEND> &ref);
	public:
		long N;
		DATATYPE *data;
};

template <typename DATATYPE> 
bool read_vector(std::ifstream &fin, 
		Vector<DATATYPE> &x_lat);

#include "vector.cpp"

#endif
