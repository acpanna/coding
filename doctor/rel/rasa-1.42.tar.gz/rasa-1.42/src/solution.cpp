template <typename DATATYPE>
Solution<DATATYPE>::Solution() : Vector<DATATYPE>(), time(0) 
{}

template <typename DATATYPE>
Solution<DATATYPE>::Solution(Solution<DATATYPE> const &ref) : Vector<DATATYPE>(ref), time(ref.time) 
{}

template <typename DATATYPE>
Solution<DATATYPE>::~Solution() 
{}

template <typename DATATYPE>
Solution<DATATYPE> const & Solution<DATATYPE>::operator=(Vector<DATATYPE> const &ref)
{ 
	Vector<DATATYPE> *tmp = this;
	(*tmp) = ref;
	return *this; 
}

template <typename DATATYPE>
Solution<DATATYPE> const & Solution<DATATYPE>::operator=(Solution<DATATYPE> const &ref)
{ 
	Vector<DATATYPE> const *tmp = &ref;
	(*this) = (*tmp);
	time = ref.time; 
	return *this; 
}

template <typename DATATYPE_FRIEND>
std::ostream& operator<< (std::ostream &o, Solution<DATATYPE_FRIEND> const &ref)
{ 
	print_time(o, ref.time); 
	o << " | "; 
	o << (Vector<DATATYPE_FRIEND>) ref; 
	return o; 
}
