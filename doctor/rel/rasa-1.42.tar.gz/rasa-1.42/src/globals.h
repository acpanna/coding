#ifndef GLOBALS__H
#define GLOBALS__H

#include "defs.h"

#include "zz.h"

#include <cstdlib>
#include <string>
#include <iostream>


inline REAL ABS(REAL const &x) 
{ if (x >= 0) return x; else return -x; }

inline REAL ROUND(REAL const &x) 
{ if (x >= 0) return CEIL(x - 0.5); else return FLOOR(x + 0.5); }

inline REAL FMAX(REAL const &x, REAL const &y) 
{ if (x > y) return x; else return y; }

inline REAL FMIN(REAL const &x, REAL const &y) 
{ if (x < y) return x; else return y; }

inline long LMAX(long x, long y) 
{ if (x > y) return x; else return y; }

inline long LMIN(long x, long y) 
{ if (x < y) return x; else return y; }


void send_signal(long signal);

unsigned int new_seed(unsigned int seed = 0);

void print_time(std::ostream &s, time_t t);

std::ostream &ext_prec(std::ostream &out);
std::ostream &std_prec(std::ostream &out);

long min_prime_factor(register long nbr);
long median_prime_factor(register long nbr);
long max_prime_factor(register long nbr);

REAL pow2(REAL const &base);

long rand_eq_long(register long min, register long max);
REAL rand_eq_real(REAL const &min, REAL const &max);

REAL rand_norm(REAL const &min, REAL const &max);

REAL ggT(REAL const &x, REAL const &y);
REAL modulo(REAL const &value, REAL const &modul);
REAL extended_euclid(REAL const &a, REAL const &b, REAL &s, REAL &t);

extern long prime[PRIMES+1];

extern long prec;

extern long sol;

extern long slk;

#endif
