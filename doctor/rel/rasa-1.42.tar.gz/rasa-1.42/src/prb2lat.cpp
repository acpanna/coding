#include <NTL/LLL.h> 
#include <fstream> 
#include <sstream> 
#include <cstring>

#include "error.h"
#include "globals.h"

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " [--dia=idx,val] *.prb");
}

int main(int argc, char **argv)
{
	char buff[4096], *ptr;
	string istr, ostr;

	bool aardal = true;
	
	long rang, sdim, ineq = 0;

	bool insufficient = true;
	double start_time, delta = 0.75;

	register long i, j, j1, j2, m, n, idx;

	string dia_str;
	stringstream stream;

	NTL::ZZ N1, N2, val, ggT, R, tmp;

	NTL::mat_ZZ AA, A_u, A_g, lat, L, T;
	NTL::vec_ZZ l_u, r_u, rr, r_x, bb, b_g;
	NTL::vec_ZZ ll, uu, aa, cc, l, u, a, c, x;

	dia_str = "";

	if (argc < 2 || argc > 5)
		usage(argv[0]);

	for (i=1; i<argc; i++) {

		if (strncmp(argv[i], "--dia=", 6) == 0) {
			strcpy(buff, argv[i]+6);
			istringstream iss(buff, istringstream::in);
			iss >> dia_str;
		} else if (strncmp(argv[i], "-", 1) == 0) 
			usage(argv[0]);
		else 
			istr = argv[i];
	}

	strncpy(buff, istr.c_str(), 4096);
	ptr = strstr(buff, ".prb");
	if (ptr == NULL) 
		usage(argv[0]);
	*ptr = 0;

	ostr = string(buff) + string(".lat");

	ifstream fin(istr.c_str());
	if (!fin.good())
		ERROR("The input file [ " + istr + " ] could not be opened!");

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	fin >> A_u;
	fin >> A_g;
	fin >> l_u;
	fin >> r_u;

	if (l_u.length() != r_u.length())
		ERROR("The dimensions of the inequation bounds differ!");
	fin >> b_g;
	fin >> r_x;

	if (r_x.length() == 0) {
		ERROR("You can't use " + string(argv[0]) + 
				" with problems, where x is free [ <==> sdim == 0 ]!");
	}
	
	fin >> aardal; // NEW
	
	fin.close();

	for (j=0; j<r_x.length(); j++) 
		if (r_x[j] <= 0)
			ERROR("r_x has to be > 0 in each of its components!");

	ineq = A_u.NumRows(); // NEW
	
	m = A_g.NumRows();
	
	if (m > 0)
		n = A_g.NumCols();
	else
		n = A_u.NumCols();

	sdim = r_x.length();	// NEW -- wegen NTRU (modulo q)
	
	start_time = NTL::GetTime();

	/********************************************************/
	/* At first we have to check if there exists a general, */
	/*  integer solution x for the problem A_g * x = b_g!   */
	/********************************************************/
	
	if (NTL::LatticeSolve(x, transpose(A_g), b_g)) {
		cerr << "The system of equations is solvable!" << endl;
		//cerr << "x = " << x << endl;
	} else
		ERROR("The system A_g * x = b_g is not solvable!");

	if (aardal) {
	
		/***************************************************************/
		/*  If the dimension of the lattice shall be reduced (Aardal), */
		/* we have to make sure that the row rank of A_g is smaller or */
		/*            equal to the column rank of A_g.                 */
		/***************************************************************/

		cerr << "Aardal reduction is enabled!" << endl;

		AA.SetDims(m, n+1);
		for (i=1; i<=m; i++) {
			for (j=1; j<=n; j++)
				AA(i, j+1) = A_g(i, j);
			AA(i, 1) = -b_g(i);
		}

		rang = G_LLL_FP(AA, delta);

		if (rang < m) {
		
			NTL::mat_ZZ A_g_orig;
			NTL::vec_ZZ b_g_orig;
			
			A_g_orig = A_g;
			b_g_orig = b_g;

			A_g.kill();
			A_g.SetDims(rang, n);

			b_g.kill();
			b_g.SetLength(rang);

			for (i=m-rang; i<m; i++)  {
				for (j=0; j<n; j++)  
					A_g[i - m + rang][j] = AA[i][j + 1]; 
				b_g[i - m + rang] = -AA[i][0];
			}

			m = rang;
			
			cerr << "*** Linear dependencies detected -- the prb file gets modified! ***" << endl;

			// Save the modified A_g, b_g and their originals in the prb file!
			 
			ofstream fout_red(istr.c_str());

			fout_red << ext_prec << A_u << endl;
			fout_red << endl;
			fout_red << ext_prec << A_g << endl;
			fout_red << endl;
			fout_red << ext_prec << l_u << endl;
			fout_red << endl;
			fout_red << ext_prec << r_u << endl;
			fout_red << endl;
			fout_red << ext_prec << b_g << endl;
			fout_red << endl;
			fout_red << ext_prec << r_x << endl;
			fout_red << endl;
			fout_red << aardal << endl;
			fout_red << endl;
			fout_red << ext_prec << A_g_orig << endl;
			fout_red << endl;
			fout_red << ext_prec << b_g_orig << endl;

			fout_red << endl << "// A_u, A_g, l_u, r_u, b_g, r_x, aardal, A_g_orig, b_g_orig" << endl;
			fout_red.close();
		}
	}

	lat.SetDims(m+sdim+1, n+1);

	l.SetLength(sdim+1);
	u.SetLength(sdim+1); 
	a.SetLength(sdim+1);
	c.SetLength(sdim+1);
	
	if (dia_str != "") {

		string token;
		istringstream iss(dia_str);

		getline(iss, token, ',');
		idx = atoi(token.c_str());

		getline(iss, token, ',');
		val = atoi(token.c_str());

		if (idx > sdim)
			ERROR("idx has to be <= sdim!");

	} else { 
		idx =	0;
		val = 0;
	}
		
	// Bestimme das kgV der Komponenten von r_x
	// R = kgv(r_x[0], r_x[1], ..., r_x[n-1])
	//
	// c[j] = R / r_x[j]
	//
	// siehe hierzu Seiten 8/9 in
	// http://btmdx1.mat.uni-bayreuth.de/~haaner/papers/mark_split.pdf

	if (sdim == 0) 
		R = 1;
	else {

		ggT = R = r_x[idx];
		for (j=idx+1; j<sdim; j++) {
			ggT = GCD(R, r_x[j]);
			R = (R * r_x[j]) / ggT;
		}
	}
	
	for (j=0; j<idx; j++) { // NEW
		u[j] = r_x[j]*val + (r_x[j] - 1);
		l[j] = -1; 
	}
	
	for (j=idx; j<sdim; j++) {
		c[j] = R / r_x[j];
		u[j] = R;
		l[j] = -u[j];
	}
/*
	cerr << "c = " << c << endl;
	cerr << "l = " << l << endl;
	cerr << "u = " << u << endl;
	cerr << "A_g = " << A_g << endl;
	cerr << "b_g = " << b_g << endl;
*/
	for (j=0; j<sdim; j++) {
		if ((u[j] % 2) == 0)
			a[j] = 0;
		else
			a[j] = -1;
	}

	l[sdim] = -R;
	u[sdim] = R;
	a[sdim] = -1;

	for (i=0; i<m; i++)
		lat[i][0] = -b_g[i];

	for (i=m; i<m+idx; i++) // NEW
		lat[i][0] = -1;

	for (i=m+idx; i<m+sdim; i++)
		lat[i][0] = -R;

	for (i=0; i<m; i++)
		for (j=1; j<n+1; j++) 
			lat[i][j] = A_g[i][j-1];

	for (i=m; i<m+idx; i++) // NEW
		lat[i][i-m+1] = val+1;

	for (i=m+idx; i<m+sdim; i++)
		lat[i][i-m+1] = 2*c[i-m];

	lat[m+sdim][0] = R;
	for (j=idx+1; j<sdim+1; j++)
		lat[m+sdim][j] = 0;

	N1 = NTL::max(n, m);
	N2 = 10*N1;

	N2 = N1;

	if (aardal && m > 0) {

		while (insufficient) {
		
			L = NTL::transpose(lat);

			L[0][m+sdim] *= N1; 

			for (i=0; i<n+1; i++)
				for (j=0; j<m; j++)
					L[i][j] *= N2;

			NTL::G_LLL_RR(L, T, delta);
//			NTL::G_LLL_FP(L, T, delta);

			insufficient = false;

			for (i=1; i<=n-m+1; i++) { 
				if (!insufficient) {
					for (j=1; j<=m; j++) {
						if (L(i, j) != 0) {
							insufficient = true;
							N2 *= 10;
							break;
						}
					}
				}
			}
			
			if (!insufficient) {
				for (i=1; i<=n-m; i++) {
					if (L(i, m+sdim+1) != 0) {
						insufficient = true;
						N1 *= 10; 
						break;
					}
				}
			}

			if (!insufficient) {
				if (NTL::abs(L(n-m+1, m+sdim+1)) != R*N1) { 
					insufficient = true;
					N1 *= 10; 
				}	
			}
		}

		L(n-m+1, m+sdim+1) /= N1; 

		/**************************************************/
		/*   The Aardal reduction was succesful, hence    */
		/* unnecessary rows and columns are stripped off. */
		/**************************************************/

		lat.SetDims(n-m+1, sdim+1);
		for (i=1; i<=n-m+1; i++) 
			for (j=m+1; j<=m+sdim+1; j++)
				lat(i, j - m) = L(i, j);

		L = NTL::transpose(lat);
		lat = L;
	
	} else {
		T = NTL::ident_mat_ZZ(n+1);  
		L = lat;
	}

	if (ineq > 0) {

		AA.SetDims(ineq, n+1);
		for (i=1; i<=ineq; i++) { 
			AA(i, 1) = -(l_u(i) + r_u(i));

			for (j=2; j<=n+1; j++)
				AA(i, j) = 2*A_u(i, j-1);
		}

		A_u = transpose(AA);

		j1 = A_u.NumCols();

		if (aardal)  {

			/*****************************************/
			/*   Apply the Aardal-transformation T   */
			/* to the the inequations stored in A_u. */
			/*****************************************/
			 
			A_u = T*A_u;  

			j2 = j1;

		} else  
			j2 = j1 + m;

		L.SetDims(lat.NumRows() + j1, lat.NumCols());

		for (i=1; i<=j1; i++)
			for (j=1; j<=lat.NumCols(); j++) 
				L(i, j) = A_u(j, i);

		for (i=j1+1; i<=lat.NumRows() + j1; i++)
			for (j=1; j<=lat.NumCols(); j++) 
				L(i, j) = lat(i - j1, j);
		
	} else {

		j1 = 0;
		
		if (aardal) 
			j2 = 0;
		else 
			j2 = m;
	}

	ll.SetLength(l.length() + j2);
	uu.SetLength(u.length() + j2);
	aa.SetLength(a.length() + j2);
	cc.SetLength(c.length() + j2);

	for (j=1; j<=j1; j++) {
		ll(j) = -(r_u(j) - l_u(j));
		uu(j) = -ll(j);
		aa(j) = 0;
		cc(j) = 0;
	}
	
	for (j=j1+1; j<=j2; j++) 
		ll(j) = uu(j) = aa(j) = cc(j) = 0;
		
	for (j=j2+1; j<=j2 + sdim + 1; j++) {
		ll(j) = l(j - j2);
		uu(j) = u(j - j2);
		aa(j) = a(j - j2);
		cc(j) = c(j - j2);
	}
	
	l = ll;
	u = uu;
	a = aa;
	c = cc;

	lat = transpose(L);
	
	stream << (NTL::GetTime() - start_time);

	fout << ext_prec << lat << endl;
	fout << endl;
	fout << ext_prec << l << endl;
	fout << ext_prec << u << endl;
	fout << ext_prec << a << endl;
	fout << endl;
	fout << ext_prec << c << endl;
	fout << endl;
	fout << ext_prec << R << endl;
	fout << ext_prec << idx << endl; 	// NEW
	fout << ext_prec << val << endl; 	// NEW
	fout << endl;
	fout << ext_prec << ineq << endl;	// NEW 

	fout << endl;
	fout << ext_prec << T << endl;		// NEW

	fout << endl << "// lattice, lbnd, ubnd, anz0, c, R, idx, val, ineq, T";
	fout << endl << "// " + stream.str() + " sec(s)";
	fout << endl;

	fout.close();

	cerr << "Lattice file: " << ostr << endl;
	cerr << "Time: " << stream.str() << " sec(s)" << endl;

	
	return 0;
}
