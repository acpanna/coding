#ifndef QQ__H
#define QQ__H

#include <iostream>

#define QQ_TYPE_BND 10000000000
#define QQ_TYPE_EPS 0.000000001

typedef double QQ_TYPE;

class QQ;

void add(QQ& ret, const QQ& a, const QQ& b);
void sub(QQ& ret, const QQ& a, const QQ& b);

class QQ {

	friend std::istream& operator >>(std::istream& s, QQ& x);  
	friend std::ostream& operator <<(std::ostream& s, const QQ& a); 

	public:
		QQ_TYPE zaehler;
		QQ_TYPE nenner;

		QQ();
		
		QQ(int src);
		QQ(long src);
		QQ(QQ_TYPE src);

		QQ(long z, long n);
		QQ(QQ_TYPE z, QQ_TYPE n);

      QQ(const QQ &src);
		QQ(const char * const src);
						  
		QQ& operator =(int);
		QQ& operator =(long);
		QQ& operator =(QQ_TYPE);
		QQ& operator =(const QQ&);
		QQ& operator =(const char * const);
		
		inline QQ& operator++(void) // prefix
		{ add(*this, *this, 1); return *this; }

		inline QQ operator++(int) // postfix
		{ QQ ret(*this); add(*this, *this, 1); return ret; }

		inline QQ& operator--(void) // prefix
		{ add(*this, *this, -1); return *this; }

		inline QQ operator--(int) // postfix
		{ QQ ret(*this); add(*this, *this, -1); return ret; }

		QQ& kuerzen(void);
};

long compare(const QQ& a, const QQ& b);

void com_denom(QQ_TYPE &a_z, QQ_TYPE &b_z, QQ_TYPE &ab_n, 
		const QQ &a, const QQ &b);

void gcd(QQ_TYPE &ggt, QQ_TYPE const &a, QQ_TYPE const &b);

void div(QQ& ret, const QQ& a, const QQ& b);
void mul(QQ& ret, const QQ& a, const QQ& b);
void power(QQ& ret, const QQ& a, const QQ& b);
void abs(QQ &ret, QQ const &src);
void sqrt(QQ& z, const QQ& a);

QQ ceil(const QQ& a);
QQ floor(const QQ& a);
QQ log(const QQ& a);

inline long sign(const QQ& a)
{ if (a.zaehler < 0) if (a.nenner >= 0) return -1; return 1; }

inline long IsZero(const QQ& a)
{ return IsZero(a.zaehler); }

inline long IsOne(const QQ& a)
{ return (a.zaehler == a.nenner); }


inline bool operator ==(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) == 0); }

inline bool operator !=(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) != 0); }

inline bool operator <(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) < 0); }

inline bool operator <=(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) <= 0); }

inline bool operator >(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) > 0); }

inline bool operator >=(const QQ &lts, const QQ &rts)
{ return (compare(lts, rts) >= 0); }


inline void negate(QQ &ret, QQ const &src) 
{ ret.zaehler = -src.zaehler; ret.nenner = src.nenner; }


inline QQ operator +(const QQ &lts, const QQ &rts) 
{ QQ c; add(c, lts, rts); return c; }

inline QQ& operator +=(QQ &lts, const QQ &rts)
{ add(lts, lts, rts); return lts; }

inline QQ operator -(const QQ &lts, const QQ &rts) 
{ QQ c; sub(c, lts, rts); return c; }

inline QQ& operator -=(QQ &lts, const QQ &rts) 
{ sub(lts, lts, rts); return lts; }

inline QQ operator -(const QQ &src)
{ QQ ret; negate(ret, src); return ret; }	


inline QQ abs(const QQ& a)
{ QQ x; abs(x, a); return x; }

inline QQ sqrt(const QQ& a) 
{ QQ ret; sqrt(ret, a); return ret; }


inline QQ operator *(const QQ &lts, const QQ &rts) 
{ QQ c; mul(c, lts, rts); return c; }

inline QQ& operator *=(QQ &lts, const QQ &rts) 
{ mul(lts, lts, rts); return lts; }
	
inline QQ operator /(const QQ &lts, const QQ &rts) 
{ QQ c; div(c, lts, rts); return c; }	
		
inline QQ& operator /=(QQ &lts, const QQ &rts) 
{ div(lts, lts, rts); return lts; }


inline QQ pow(const QQ& a, const QQ& b)
{ QQ x; power(x, a, b); return x; }

inline void inv(QQ& z, const QQ& a)
{ z.zaehler = a.nenner; z.nenner = a.zaehler; }


inline long to_long(QQ const &a)
{ QQ ret; ret = floor(a); return ((long) ret.zaehler); }

inline QQ to_QQ(QQ_TYPE const &a)
{ QQ ret(a); return ret; }

inline QQ to_QQ(QQ const &a) 
{ return a; }

#endif
