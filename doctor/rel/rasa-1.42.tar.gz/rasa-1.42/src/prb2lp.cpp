#include "matrix.h"

#include <iostream>
#include <fstream>
#include <cstring>

#define BUFFER 4096

using namespace std;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " *.prb");
}

int main(int argc, char **argv)
{
	char buff[BUFFER], *ptr;
	register long i, j, n;
	string istr, ostr;

	if (argc != 2)
		ERROR("Usage: " + string(argv[0]) + " *.prb");

	istr = string(argv[argc-1]);

	strncpy(buff, argv[argc-1], BUFFER);
	ptr = strstr(buff, ".prb");
	if (ptr == NULL) 
		usage(argv[0]);
	*ptr = 0;

	ostr = string(buff) + string(".lp");

	ifstream fin(istr.c_str());
	if (!fin.good())
		ERROR("The input file [ " + istr + " ] could not be opened!");

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	Matrix<REAL> A_u, A_g;
	Vector<REAL> l_u, r_u, b_g, r_x;

	fin >> A_u;
	fin >> A_g;
	fin >> l_u;
	fin >> r_u;
	fin >> b_g;
	fin >> r_x;

	fin.close();

	n = LMAX(A_g.N, A_u.N);

	fout << ext_prec << "Minimize" << endl;
	fout << ext_prec << " obj:" << endl;
	fout << ext_prec << "Subject To" << endl;

	for (i=1; i<=A_u.M; i++) {

		fout << " ";

		for (j=1; j<=A_u.N; j++) {
			if (A_u[i][j] != 0) {
				if (A_u[i][j] < 0)
					fout << ext_prec << "- " << -A_u[i][j] << " x" << j << " ";
				else
					fout << ext_prec << "+ " << A_u[i][j] << " x" << j << " ";
			}
		}

		fout << ext_prec << "<= " << r_u[i] << endl;

		fout << " ";

		for (j=1; j<=A_u.N; j++) {
			if (A_u[i][j] != 0) {
				if (A_u[i][j] < 0)
					fout << ext_prec << "- " << -A_u[i][j] << " x" << j << " ";
				else
					fout << ext_prec << "+ " << A_u[i][j] << " x" << j << " ";
			}
		}

		fout << ext_prec << ">= " << l_u[i] << endl;
	}
		
	for (i=1; i<=A_g.M; i++) {

		fout << " ";

		for (j=1; j<=A_g.N; j++) {
			if (A_g[i][j] != 0) {
				if (A_g[i][j] < 0) 
					fout << ext_prec << "- " << -A_g[i][j] << " x" << j << " ";
				else
					fout << ext_prec << "+ " << A_g[i][j] << " x" << j << " ";
			}
		}

		fout << ext_prec << "= " << b_g[i] << endl;
	}

	fout << ext_prec << "Bounds" << endl;
	for (j=1; j<=r_x.N; j++)  
		fout << ext_prec << " 0 <= x" << j << " <= " << r_x[j] << endl;
	for (j=r_x.N + 1; j<=n; j++)  
		fout << ext_prec << " x" << j << " FREE" << endl;
//		fout << ext_prec << " -INFINITY <= x" << j << " <= +INFINITY" << endl;

	fout << ext_prec << "General" << endl;
	for (j=1; j<=n; j++)  
		fout << ext_prec << " x" << j;
	fout << ext_prec << endl;
	
	fout << ext_prec << "End" << endl;
	fout.close();

	return 0;
}
