#include "polynom.h"
#include "matrix.h"

#include <iostream>

using namespace std;

int main(void)  
{
	Vector<double> ew;
	Polynom<double> p, p1, p2;
	Matrix<double> A, B;


	cin >> A;
/*
	long min = LMIN(A.M, A.N);

	A.resize(min, min);

	p = A.characteristic_polynom();

	p1 = p.real_root_factor();
	
	cerr << "p(x) = " << p << endl;
	cerr << "real_p(x) = " << p1 << endl;

	p2 = p / p1;

	cerr << "p(x) / real_p(x) = " << p2 << endl;
*/
/*
	time_t t0, t1, t2, t3;
	Matrix<double> B(4,5), Q, R;

	B[1][1] = 0;
	B[1][2] = 0;
	B[1][3] = 1;
	B[1][4] = 0;
	B[1][5] = 0;

	B[2][1] = 2;
	B[2][2] = 1;
	B[2][3] = 0;
	B[2][4] = 1;
	B[2][5] = 0;

	B[3][1] = 1;
	B[3][2] = 0;
	B[3][3] = 0;
	B[3][4] = 0;
	B[3][5] = 0;

	B[4][1] = 1;
	B[4][2] = 2;
	B[4][3] = 3;
	B[4][4] = 0;
	B[4][5] = 0;


	cin >> B;

	B = B.transpose();
	cerr << out_mod << "Read!" << endl;

	time(&t2);
	B.qr(Q,R);
	time(&t3);

	if (B!= (Q*R))
		cerr << out_mod << "B!= QR"<< endl;
	//cerr << out_mod << "B = " << B << endl;
	//cerr << out_mod << "Q*R = " << Q*R << endl;

	time(&t0);
	B.compute_qr(Q, R);
	time(&t1);

	if (B!= (Q*R))
		cerr << out_mod << "B!= QR"<< endl;
	//cerr << out_mod << "B = " << B << endl;
	//cerr << out_mod << "Q*R = " << Q*R << endl;

	std::cerr << out_mod << std::endl;
	
	cerr << out_mod << "My time: " << t1 - t0 << endl;
	cerr << out_mod << "Other time: " << t3 - t2 << endl;
*/
/*
	Matrix<double> A(3, 5);
	Vector<double> b(3), c(5), x(5); 

	A[1][1] = 0;
	A[1][2] = 2;
	A[1][3] = 1;
	A[1][4] = 0;
	A[1][5] = 0;

	A[2][1] = 2;
	A[2][2] = 3;
	A[2][3] = 0;
	A[2][4] = 1;
	A[2][5] = 0;

	A[3][1] = 1;
	A[3][2] = 0;
	A[3][3] = 0;
	A[3][4] = 0;
	A[3][5] = 1;

	c[1] = -3;
	c[2] = -1;
	c[3] = 0;
	c[4] = 0;
	c[5] = 0;

	b[1] = 6;
	b[2] = 13;
	b[3] = 5;
	
	
	cerr << out_mod << "Costs: " << c << endl;

	A.simplex(b, c, x);

	cerr << out_mod << "Optimal: " << x << endl;
	cerr << out_mod << "Minimal value: " << (c*x) << endl;
*/

	return 0;
}
