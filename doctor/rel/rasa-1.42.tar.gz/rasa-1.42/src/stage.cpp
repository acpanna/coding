Stage::Stage() : ytilda(TO_REAL(0)), vtilda(TO_REAL(0)), ctilda(TO_REAL(0)), utilda_lb(TO_REAL(0)), utilda_ub(TO_REAL(0)), utilda(TO_REAL(0)), Delta(TO_REAL(0)), delta(TO_REAL(0)), nprune(false) { }

void Stage::clear(void)
{ 
	ytilda = TO_REAL(0); 
	vtilda = TO_REAL(0); 
	ctilda = TO_REAL(0); 
	
	utilda_lb = TO_REAL(0);
	utilda_ub = TO_REAL(0);
	utilda = TO_REAL(0);

	Delta = TO_REAL(0); 
	delta = TO_REAL(0); 
	nprune = false; 
}
