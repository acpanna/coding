#include <fstream> 
#include <cstring>

#include "matrix.h"

using namespace std;
using namespace NTL;

void usage(char *str) 
{
	ERROR("Usage: " + string(str) + " *.lat|*.lat_*");
}

int main(int argc, char **argv)
{
	register long m, i, j;

	char buff[4096], *ptr;
	string lstr, pstr, ostr;

	Matrix<REAL> AA_u, AA_g, A_u, A_g, T, tmp_mat;
	Vector<REAL> ll_u, rr_u, bb_g, l_u, r_u, b_g, r_x, rr_x, tmp_vec;

	Vector<Matrix <REAL> > TT;

	REAL tmp_scalar, two;

	if (argc != 2)
		usage(argv[0]);

	lstr = argv[1];

	strncpy(buff, lstr.c_str(), 4096);
	ptr = strstr(buff, ".lat");
	if (ptr == NULL) 
		usage(argv[0]);
	*ptr = 0;

	pstr = string(buff) + string(".prb");
	ostr = string(buff) + string("_free.prb");

	ptr++;
	ptr = strstr(ptr, "_");
	if (ptr != NULL) {

		ifstream fin_lat(lstr.c_str());
		if (!fin_lat.good())
			ERROR("The input file [ " + lstr + " ] could not be opened!");

		fin_lat >> tmp_mat;
		fin_lat >> TT;

		fin_lat.close();

		strncpy(buff, lstr.c_str(), 4096);
		ptr = strstr(buff, ".lat_");

		ptr += 4;
		*ptr = 0;
		
		lstr = string(buff);
	}

	ifstream fin_lat(lstr.c_str());
	if (!fin_lat.good())
		ERROR("The input file [ " + lstr + " ] could not be opened!");
	
	ifstream fin_prb(pstr.c_str());
	if (!fin_prb.good())
		ERROR("The input file [ " + pstr + " ] could not be opened!");

	ofstream fout(ostr.c_str());
	if (!fout.good())
		ERROR("The output file [ " + ostr + " ] could not be opened!");

	two = 2;

	fin_prb >> A_u; 
	fin_prb >> A_g; 
	fin_prb >> l_u; 
	fin_prb >> r_u; 
	fin_prb >> b_g; 
	fin_prb >> r_x; 

	fin_prb.close();

	fin_lat >> tmp_mat;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	
	fin_lat >> tmp_scalar;
	fin_lat >> tmp_scalar;
	fin_lat >> tmp_scalar;
	fin_lat >> tmp_scalar;
	
	fin_lat >> T;

	fin_lat.close();

	/**********************************************/
	/* Multiplizieren der Transformationsmatrizen */ 
	/* 		 	des aktuellen Gitters 				 */
	/**********************************************/

	for (i=1; i<=TT.N; i++) 
		T = TT[i] * T;

	/******************************/
	/* Aufstellen der Gleichungen */
	/******************************/

	AA_g.resize(A_g.M, A_g.N + 1);
	
	for (i=1; i<=A_g.M; i++) {
		AA_g[i][1] = -b_g[i];
		for (j=1; j<=A_g.N; j++) 
			AA_g[i][j + 1] = A_g[i][j];
	}

	A_g = AA_g * T;

		AA_g.resize(A_g.M + 1, A_g.N);

	bb_g.resize(AA_g.M);

	for (i=1; i<=A_g.M; i++) {
		for (j=1; j<=A_g.N; j++) 
			AA_g[i][j] = A_g[i][j];

		bb_g[i] = 0;
	}

		for (j=1; j<=AA_g.N; j++) 
			AA_g[AA_g.M][j] = T[1][j];

		bb_g[AA_g.M] = 1;
	
	/********************************/
	/* Aufstellen der Ungleichungen */
	/********************************/

	tmp_vec = -(l_u + r_u);

	if (A_u.M > 0) {

		AA_u.resize(A_u.M, A_u.N + 1);
		for (i=1; i<=A_u.M; i++) {
			AA_u[i][1] = tmp_vec[i];
			for (j=1; j<=A_u.N; j++) 
				AA_u[i][j + 1] = two * A_u[i][j];
		}

		A_u = AA_u * T;
	}

	m = T.M - 1;

	AA_u.resize(m + A_u.M, LMAX(A_u.N, A_g.N));

	ll_u.resize(AA_u.M);
	rr_u.resize(AA_u.M);

	/////////////////////////////////////////////////////

	for (i=1; i<=m; i++) {
		for (j=1; j<=AA_u.N; j++) 
			AA_u[i][j] = T[i+1][j];

		ll_u[i] = 0;
		rr_u[i] = r_x[i]; 
	}
	
	/////////////////////////////////////////////////////

	tmp_vec = (r_u - l_u);
	for (i=1; i<=A_u.M; i++) {
		for (j=1; j<=A_u.N; j++) 
			AA_u[i + m][j] = A_u[i][j];

		ll_u[i + m] = -tmp_vec[i];
		rr_u[i + m] = tmp_vec[i];
	}

	/////////////////////////////////////////////////////

	rr_x.resize(0); // sdim == 0 <==> x ist freier Vektor

	/////////////////////////////////////////////////////
 
	fout << ext_prec << AA_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << AA_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << ll_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << rr_u << endl;
	fout << ext_prec << endl;
	fout << ext_prec << bb_g << endl;
	fout << ext_prec << endl;
	fout << ext_prec << rr_x << endl;
	fout << ext_prec << endl;

	fout << ext_prec << 1 << endl;

	fout << ext_prec << endl;

	fout << ext_prec << endl << "// AA_u, AA_g, ll_u, rr_u, bb_g, rr_x, aardal";
	fout << ext_prec << endl;

	fout.close();
	
	return 0;
}
