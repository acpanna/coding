#include <sstream>
#include <cfloat>
#include <cmath>

using namespace std;

template <typename REAL>
void Lattice<REAL>::init(void)
{
	create_time = time(NULL);

	nrm_file = "";
	map_file = "";

	params = "";
	
	VERB = 0;
	BTIME = 0;
	
	TRANS = true;

	ALPHA = 0.5;
	DELTA = 0.99;

	BETA = 20;
	DEEP = 0;

	NPRUNE = 0;
	EPRUNE = 0;
	
	SCALE = 0;
	SIEVE = -1;

	GSA = 0;
	PRJ = false;
	SLIMIT = 0;

	iters = 0;
	slks = 0;
	
	M = 0;
	N = 0;

	S = 0;

	B_curr = 0;
	B = 0;

	T = 0;
	TT = 0;

	mu = 0;
	Bdach = 0;
	Bgram = 0;
	Btilda = 0;
	
	b = 0;
	c = 0;
	
	stage = 0;

	scale_vector = 0;

	check_lbnd = 0;
	check_ubnd = 0;
	check_anz0 = 0;

	best_heu_abw = -1;
	best_heu_norm = 0;
	best_heu = 0;

	best_slk_abw = -1;

	solution = 0;

	b_min_idx = 0;
	b_max_idx = 0;
	c_min_idx = 0;
	c_max_idx = 0;
	
	b_min = TO_REAL(0);
	b_max = TO_REAL(0);
	c_min = TO_REAL(0);
	c_max = TO_REAL(0);

	deep_insert = 0;
	bkz_nprune = 0;

	triv_sub = 0;
	ntriv_sub = 0;

	pair_cnt = 0;
	short_cnt = 0;
	eshort_cnt = 0;

	heu_improve = 0;
	slk_improve = 0;
	
	heu_update = false;
	
	abw_fptr = &Lattice::def_chk_abw; 
}

template <typename REAL>
void Lattice<REAL>::resize(register long m, register long n)
{
	if (m <= 0 || n < 0)
		ERROR("invalid size");
	
	if (n == 0) 
		n = N;
	
	B_curr.resize(m, n);
	B.resize(m, n);

	if (m > T.M)
		T.resize(m, m); 
	
	mu.resize(m+1, n);

	Bdach.resize(m+1, n);
	Bgram.resize(m+1, m+1);
	
	Btilda.resize(m+1, n);

	b.resize(m+1);
	c.resize(m+1);
	
	stage.resize(m+1);
	scale_vector.resize(n);

	M = m;

	if (n > 0)
		N = n;
}

template <typename REAL>
Lattice<REAL>::Lattice(void)
{
	init();
}

template <typename REAL>
Lattice<REAL>::~Lattice() 
{ 
	if (solution)
		delete [] solution;

	solution = 0;
}

template <typename REAL>
void Lattice<REAL>::init_params(register long verbose, 
		register long btime, register bool trans, register double alpha, 
		register double delta, register long beta, register long deep, 
		register long nprune, register long eprune, register long scale,
		register long sieve, register long gsa, register bool prj, 
		register long slimit, register long heu)
{
	register long i, j;

	if (verbose > 3 || verbose < 0)
		ERROR("--verbose=[0,1,2,3]");

	VERB = verbose;

	BTIME = btime;
	TRANS = trans;

	ALPHA = alpha;
	DELTA = delta;

	BETA = beta;
	DEEP = deep;

	if (nprune > 2 || nprune < 0)
		ERROR("--nprune=[0,1,2]");
	NPRUNE = nprune;
	
	if (eprune > 3 || eprune < 0)
		ERROR("--eprune=[0,1,2,3]");
	EPRUNE = eprune;

	SCALE = scale;
	for (j=1; j<=N; j++)
		scale_vector[j] = TO_REAL(1);

	if (sieve != -1)
		SIEVE = sieve_set.elements_max = sieve; 

	GSA = gsa;
	PRJ = prj;

	SLIMIT = slimit;

	/*
		The heuristic function switch
													*/
	if (heu == 0)
		abw_fptr = &Lattice::def_chk_abw; 
	else if (heu == 1)
		abw_fptr = &Lattice::anz_chk_abw; 
	else if (heu == 2)
		abw_fptr = &Lattice::max_chk_abw;
	else if (heu == 3)
		abw_fptr = &Lattice::all_chk_abw;
	else
		ERROR("--heu=[0,1,2,3]");

	for (i=1; i<=M; i++) 
		check_solution(i); 
}

template <typename REAL>
void Lattice<REAL>::swap(register long i, register long j)
{
	if (i != j) {
		B_curr.swap(i, j);

		if (TRANS)
			T.swap(i, j);

		mu.swap(i, j);

		b.swap(i, j);
		c.swap(i, j);
	}
}

template <typename REAL>
void Lattice<REAL>::check_trans(void)
{
	register long i, j;
	bool transform_error = true;

	REAL det;

	/***********************************************/
	/* T is the transformation matrix,             */
	/* which maps the originating basis matrix (B) */
	/* to the current basis matrix (B_curr).       */
	/***********************************************/
	
	if (!TRANS) {
		// cerr << "*** Transformation Checks are disabled! ***" << endl;
		write_map();
		return;
	}

	/***************************************/
	/*                                     */
	/* In several tests it is ensured that */
	/* the transformation T is unimodular. */
	/*                                     */
	/***************************************/

	det = ABS(T.determinant());
	if (ABS(ABS(det) - 1) <= 0.4) { 	// T should have an integer determinant,
		transform_error = false;		// hence <= 0.4 should be sufficient ...

	} else {

		Matrix<REAL> T2;
		T2 = T;

		for (i=1; i<=T2.M; i++)
			for (j=i+1; j<=T2.M; j++)
				if (T2[j].quad_euklid_norm() > T2[i].quad_euklid_norm())
					T2.swap(i, j);

		det = ABS(T2.determinant());
		if (ABS(ABS(det) - 1) <= 0.4) {
			transform_error = false;

		} else {

			for (i=1; i<=T2.M; i++)
				for (j=i+1; j<=T2.M; j++)
					if (T2[j].quad_euklid_norm() < T2[i].quad_euklid_norm())
						T2.swap(i, j);

			det = ABS(T2.determinant());
			if (ABS(ABS(det) - 1) <= 0.4) {
				transform_error = false;

			} else {

				Matrix<REAL> Q, R;
				T.qr(Q, R);

				det = 1;
				for (i=1; i<=R.M; i++)
					det *= R[i][i];

				if (ABS(ABS(det) - 1) <= 0.4) {
					transform_error = false;
				} 

			} 
		}
	}

	if (transform_error) {

		if (VERB == 3) {
			WARNING("Transformation error detected!");
//			WARNING("T = " << ext_prec << T << std_prec);
			WARNING("det T = " << det);
		}

		// Fetch the last known (correct) 
		// transformation from the stack.
		 
		if (TT.N != 0) {

			T = TT[TT.N];
		
			B_curr = T*B;
			B = B_curr;

		} else {

			// In the worst case there is no transformation matrix 
			// stored on the stack. The current basis matrix has to be 
			// reinitialized with the original one.
			 
			B_curr = B;

			// Challenge: Try to make the transformation valid again ...
		}

		TT.resize(TT.N + 1);
		T.make_one(T.M);
	}

	/**************************************************/
	/*																  */
	/* If we get to this point, the transformation is */ 
	/* 			correct and unimodular.               */
	/*																  */
	/**************************************************/

	for (i=1; i<=T.M; i++) {
		for (j=1; j<=T.M; j++) {
#ifdef FIN_DTYPE
			if (ABS(T[i][j]) > T_MAX_VAL) {
#endif
#ifdef INF_DTYPE
			if (ABS(T[i][j]) > LMAX(T_MAX_VAL, pow(2, prec - 10))) {
#endif
				if (TT.N == 0) 
					TT.resize(TT.N + 1);
/*
				cerr << "**************TT1****************" << endl;
				cerr << "T[" << i << "] = " << T[i] << endl;
*/
				TT[TT.N] = T;

				B_curr = T*B;
				B = B_curr;

				T.make_one(T.M);
				TT.resize(TT.N + 1);

				break;
			}
		}

		if (j <= T.M) // If break was executed within the j-loop, this is true
			break;
	}

	if (TT.N > T_MATRIX_NUMBER) {
		cerr << "TT.N > T_MATRIX_NUMBER --> *** RE_EXECUTION! ***" << endl;
		send_signal(10);
	}

	/********************************************/
	/*										 	   		  */
	/* The current basis matrix gets recomputed */
	/*     and is (eventually) rescaled         */
	/*												   	  */
	/********************************************/

	B_curr = T * B;

	if (SCALE)
		for (i=1; i<=B_curr.M; i++)
			B_curr[i] *= scale_vector;

	//	cerr << "**************TT2****************" << endl;

	if (TT.N == 0) 
		TT.resize(TT.N + 1);
	
	TT[TT.N] = T;

	write_map();
}

template <typename REAL>
void Lattice<REAL>::print_stats(void)
{	
	register long i;

	REAL defect;
	REAL b_curr, b_mean, c_curr, c_mean;
	
	check_trans();
	compute_lengths();
	write_nrm();

	if (VERB) {
		cerr << endl;
		cerr << "---------------------------- Some statistics -----------------------------" << endl;
	}

	b_mean = b[1] / M; 
	c_mean = c[1] / M;

	defect = (log(b[1]) - log(c[1]));

	for (i=2; i<=M; i++) {
		b_curr = b[i];
		b_mean += (b_curr / M);

		c_curr = c[i];
		c_mean += (c_curr / M);

		defect += (log((b[i])) - log(c_curr));
	}

	if (VERB) {

		if (SCALE) {
			cerr << endl;
			cerr << "scale_vector = " << scale_vector << endl;
		}
	}

	if (VERB) {
		cerr << std_prec;
		cerr << "\nShortest base vector: ";
		cerr << "||b_" << b_min_idx << "||^2 = " << b_min;
		cerr << "\nLongest base vector: ";
		cerr << "||b_" << b_max_idx << "||^2 = " << b_max;
		cerr << endl;
		cerr << "\nShortest orthogonal vector: ";
		cerr << "||PI_" << c_min_idx << "(b_" << c_min_idx << ")||^2 = " << c_min;
		cerr << "\nLongest orthogonal vector: ";
		cerr << "||PI_" << c_max_idx << "(b^_" << c_max_idx << ")||^2 = " << c_max;
		cerr << endl;
		cerr << endl;
		cerr << "Mean base vector length: " << b_mean << endl;
		cerr << "Mean orthogonal vector length: " << c_mean << endl;
		cerr << endl;
		cerr << "Logarithmic orthogonal defect: " << defect << endl;
		cerr << endl;
		cerr << "Transformation matrices: " << TT.N << endl;
		cerr << endl;
		cerr << "Deep insertions: " << deep_insert << endl;
		cerr << "Pairwise reductions: " << pair_cnt << endl;
		cerr << "Heuristic improvements: " << heu_improve << endl;

		if (slks) {
			cerr << "Slack improvements: " << slk_improve << endl;
		}

		cerr << "Pruned enumeration trees: " << bkz_nprune << endl;
		
		cerr << endl;
		cerr << "Sampling insertions (short / eshort): ";
		cerr << "( " << short_cnt << " / " << eshort_cnt << " )" << endl;
		cerr << endl;
		cerr << "Basis substitutions (triv / ntriv): ";
		cerr << "( " << triv_sub << " / " << ntriv_sub << " )" << endl; 
	}

	if (VERB) {
		
		print_sol();

		cerr << endl;
		cerr << "--------------------------------------------------------------------------" << endl;
	}
}

template <typename REAL>
void Lattice<REAL>::print_best_heu(void)
{
	cerr << std_prec << endl;
	cerr << "H(best_heu) = " << best_heu_abw;
//	cerr << ", || best_heu ||_2 = " << best_heu_norm;

	if (best_heu_abw != -1) {
		cerr << " -- [ ";
		print_time(cerr, best_heu.time);
		cerr << " ]";
	}
}

template <typename REAL>
void Lattice<REAL>::print_best_slk(void)
{
	cerr << std_prec << endl;
	cerr << "S(best_slk) = " << best_slk_abw;
	
	if (best_slk_abw != -1) {
		cerr << " -- [ ";
		print_time(cerr, best_slk.time);
		cerr << " ]";
	}
}

template <typename REAL>
void Lattice<REAL>::print_sol(void)
{
	print_best_heu();

	if (slks) 
		print_best_slk();
		
	cerr << endl;

	if (S > 0) {
		cerr << endl;
		cerr << "Solutions found: " << S << endl;
		cerr << endl;
		cerr << "[ The first solution/s was/were found after: ";

		for (long i=0; i<LMIN(3, S); i++) {
			print_time(cerr, solution[i].time);
			cerr << " ";
		}

		cerr << "]" << endl;
	}
}

template <typename REAL>
void Lattice<REAL>::write_nrm(void)
{
	register long i;
	ofstream fout(nrm_file.c_str());

	fout << ext_prec << "yC <- c( ";
	for (i=1; i<=M; i++) {
		if (i > 1) fout << ext_prec << ", ";
		fout << ext_prec << c[i];
	}

	fout << ext_prec << ") " << endl;
	fout << ext_prec << "yB <- c( ";

	for (i=1; i<=M; i++) {
		if (i > 1) fout << ext_prec << ", ";
		fout << ext_prec << b[i];
	}

	fout << ext_prec << ") " << endl;
	fout.close();
}

template <typename REAL>
void Lattice<REAL>::write_map(void)
{
	register long i, j;
	ofstream fout(map_file.c_str());

	Matrix<REAL> *B_tmp = 0;
	
	if (SCALE)
		B_tmp = new Matrix<REAL>(B_curr.M, N);

	if (SCALE) 
		for (i=1; i<=B_curr.M; i++)
			(*B_tmp)[i] = B_curr[i] / scale_vector;
	else
		B_tmp = &B_curr;

	for (i=1; i<=B_tmp->M; i++)
		for (j=1; j<=B_tmp->N; j++)
			if (ABS((*B_tmp)[i][j]) < EPSILON)
				(*B_tmp)[i][j] = 0;

	fout << ext_prec << params << endl;
	fout << endl;

	fout << ext_prec << (*B_tmp) << endl;
	fout << endl;

	if (SCALE)
		delete B_tmp;

	fout << ext_prec << TT << endl; 
	fout << endl;
	fout << ext_prec << best_heu << " -- " << best_heu_norm << endl;
	fout << ext_prec << best_slk << " -- " << best_slk_abw << endl;

	if (S > 0)  {
		fout << endl;
		for (i=0; i<S; i++) 
			fout << ext_prec << solution[i] << endl;
	} 

	fout.close();
}

/*
	This function adds a new solution to the pool of
	already found solutions and takes care that there
	are no double entries.
*/
template <typename REAL>
void Lattice<REAL>::new_solution(Vector<REAL> const &ref)
{
	register long j;
	Vector<REAL> tmp(ref);
	Solution<REAL> *tmp_solution;

	check_trans(); // At first have to check if everything is alright, 
	// before a solution for an incorrect transformation gets written.

	if (SCALE) 
		tmp /= scale_vector;

	//cerr << ext_prec <<"ref= " << ref << endl;
	//cerr << ext_prec << "scvec =" << scale_vector << endl;
	//cerr << ext_prec << tmp << endl;

	for (j=0; j<S; j++) 
		if (tmp.is_abs_equal((Vector<REAL>) solution[j]))
			return;
	S++;
	tmp_solution = solution;
	solution = new Solution<REAL>[S];
	for (j=0; j<S-1; j++) 
		solution[j] = tmp_solution[j];
	
	if (tmp_solution)
		delete [] tmp_solution;

	solution[S-1] = tmp;
	solution[S-1].time = time(NULL) - create_time;

	if (sol > 0 && S == sol) 
		send_signal(15);
}

/*
	The QR-decomposition of the 
	base matrix is done in here.
*/
template <typename REAL>
void Lattice<REAL>::compute_gs_qr(void) 
{
	register long i, j;

	Matrix<REAL> A;
	Matrix<REAL> Q, R;

	A = B_curr.transpose();
	A.qr(Q, R);

	for (i=1; i<=Q.M; i++) 
		for (j=1; j<=Q.N; j++) 
			Q[i][j] *= R[j][j];
	
	for (i=1; i<=R.M; i++) {
		for (j=i+1; j<=R.N; j++) 
			R[i][j] /= R[i][i];
		
		R[i][i] = 1;
	}

	Bdach = Q.transpose();
	mu = R.transpose();
	
	for (i=1; i<=M; i++) 
		c[i] = Bdach[i].quad_euklid_norm();
}

/*
	The euclidean lengths of 
	the (orthogonal) base 
	vectors are computed here.
*/
template <typename REAL>
void Lattice<REAL>::compute_lengths(void)
{
	register long i;

	b_min = 0;
	b_max = 0;
	c_min = 0;
	c_max = 0;

	compute_gs_qr();

	for (i=1; i<=M; i++) {

		b[i] = B_curr[i].quad_euklid_norm();
			
		if (b[i] < b_min || b_min == 0) {
			b_min_idx = i;
			b_min = b[i];
		}
		
		if (b[i] > b_max) {
			b_max_idx = i;
			b_max = b[i];
		}
			
		if (c[i] < c_min || c_min == 0) {
			c_min_idx = i;
			c_min = c[i];
		}
		
		if (c[i] > c_max) {
			c_max_idx = i;
			c_max = c[i];
		}
	}
}

template <typename REAL>
void Lattice<REAL>::variate(void)
{
	register long idx = 0;

	if (VERB >= 2)
		cerr << ext_prec << "-> Variating base vectors ... " << endl;

	if (variate_sol()) 
		return;

	if (idx == 0) {

		if (rand_eq_long(0, 1))
			sort();
		else
			shuffle();

		return rev_sort();
	}
}

template <typename REAL>
bool Lattice<REAL>::variate_sol(void)
{
	register long i, idx = 0;

	static long curr_sol = 0;

	if (S > 0 && curr_sol < S)  {

		Vector<long> pmt;
		Vector<REAL> coord, tmp;
		
		Matrix<REAL> A;
		Matrix<REAL> L, R;
		
		tmp = solution[curr_sol];

		if (SCALE)
			tmp *= scale_vector;

		for (i=1; i<=M; i++)
			if (ABS(B_curr[i][N]) == tmp[N])
				idx = ((rand_eq_long(0, idx) > 0) ? idx : i);

		if (idx == 0) 
			return false;

		swap(idx, M);

		A = B_curr.transpose();
		A.gauss(L, R, pmt);
/*
		cerr << "tmp[N] = " << tmp[N] << endl;
		cerr << "B_curr[M][N] = " << B_curr[M][N] << endl;
*/
		if (compute_coords(L, R, pmt, tmp, coord, true) != 1)
			ERROR("compute_coords5 -- matrix is not regular");

		if (ABS(coord[M]) == 1) { 

			if (VERB >= 2)
				cerr << "-> Variating base vector (" << idx << ") ..." << endl;

			if (TRANS) {
				T[M] *= coord[M];
				for (i=1; i<M; i++)
					T[M] += T[i]*coord[i];
			}

			B_curr[M] = tmp;
			curr_sol++;

		} else
			return false;

		return true;

	} else 
		return false;
}

template <typename REAL>
void Lattice<REAL>::shuffle(void)
{
	register long i, j, k;
	
	static long curr_shf = 0;
	curr_shf++;

	if (VERB >= 2) {
		cerr << "-> Shuffling base vectors ";
		cerr << "(" << curr_shf << " shuffle(s)) ..." << endl;
	}

	for (k=1; k<curr_shf; k++) {

		i = rand_eq_long(1, M);
		j = rand_eq_long(1, M);

		swap(i, j);
	}
}

/*
	Heuristically sort the basis, such that:
		H(B[1]) <= H(B[2]) <= ... <= H(B[m])
*/
template <typename REAL>
void Lattice<REAL>::sort(void)
{
	bool sorted = false;
	register long i, j;
	Vector<REAL> hb;

	if (VERB >= 2)
		cerr << "-> Heuristic Sorting ... " << endl;

	hb.resize(M);

	for (i=1; i<=M; i++)
		hb[i] = (this->*abw_fptr)(B_curr[i]);
	
	while (!sorted) {
		sorted = true;

		for (i=1; i<M; i++) {
			for (j=i+1; j<=M; j++) {

				if (hb[j] < hb[i]) {
					hb.swap(i, j);
					swap(i, j);
					sorted = false;
				}
			}
		}
	}
}

/*
 	Locate the base vector with the best
	heuristic deviation and put it at the end
	of the basis
*/
template <typename REAL>
void Lattice<REAL>::rev_sort(void)
{
	register long i, idx;
	REAL hd, min;

	idx = 1;
	min = (this->*abw_fptr)(B_curr[1]);

	for (i=2; i<=M; i++) {
		hd = (this->*abw_fptr)(B_curr[i]);

		if (hd < min) {
			idx = i;
			min = hd;
		}
	}

	swap(idx, M);
}

template <typename REAL>
void Lattice<REAL>::check_solution(void)
{
	register long i;

	for (i=1; i<=M; i++) 
		check_solution(i);
}

template <typename REAL>
void Lattice<REAL>::check_solution(register long i)
{
	check_solution(B_curr[i]);
}

template <typename REAL>
void Lattice<REAL>::check_solution(Vector<REAL> const &coord, 
		register long jj,	register long kk)
{
	register long i;
	Vector<REAL> lat_vec;

	lat_vec = B_curr[jj] * coord[jj];
	
	for (i=jj+1; i<=kk; i++)
		lat_vec += B_curr[i] * coord[i];
	
	check_solution(lat_vec);
}

template <typename REAL>
bool Lattice<REAL>::check_solution(Vector<REAL> &ref)
{
	bool ret = false;
	register long i, j;
	
	if (!ref.is_zero()) { 
	
		bool try_negative;
		Vector<REAL> *vec;
		
		for (i=1; i<=2; i++) {

			try_negative = false;

			if (i == 1) 
				vec = &ref;
			else {
				vec = new Vector<REAL>;
				*vec = -ref;
			}

			for (j=slks+1; j<=N; j++) {

				if (check_anz0[j] != 0 && (*vec)[j] == 0) {
					check_best_heu(*vec);
					if (i == 2)  {
						delete vec;
					}
					return ret;
				}

				if ((*vec)[j] < check_lbnd[j] || (*vec)[j] > check_ubnd[j]) {
					check_best_heu(*vec);
					try_negative = true;
					break;
				}
			}

			if (try_negative) 
				continue;

			if (slk >= 0) 
				check_best_slk(*vec);

			for (j=1; j<=slks; j++) {

				if (check_anz0[j] != 0 && (*vec)[j] == 0) {
					check_best_heu(*vec);
					if (i == 2)  {
						delete vec;
					}
					return ret;
				}

				if ((*vec)[j] < check_lbnd[j] || (*vec)[j] > check_ubnd[j]) {
					check_best_heu(*vec);
					try_negative = true;
					break;
				}
			}
			
			if (try_negative) 
				continue;

			new_solution(*vec);
			check_best_heu(*vec);

			ret = true;
			break;
		}

		if (i >= 2)
			delete vec;
	}

	return ret;
}

template <typename REAL>
bool Lattice<REAL>::check_best_heu(register long i)
{
	return check_best_heu(B_curr[i]);
}

template <typename REAL>
bool Lattice<REAL>::check_best_heu(Vector<REAL> &ref) 
{
	REAL abw;

	if (!ref.is_sparse()) { 

		abw = (this->*abw_fptr)(ref);

		if (best_heu_abw == -1 || abw <= best_heu_abw) {

			if (SCALE) {
				best_heu = ref / scale_vector;
			} else
				best_heu = ref;

			if (best_heu_abw == -1 || abw < best_heu_abw) {
				best_heu.time = time(NULL) - create_time;
				heu_update = true; // wegen best_heu_insert
			}
			
			best_heu_abw = abw;
			best_heu_norm = SQRT(best_heu.quad_euklid_norm());
			
			heu_improve++;

			if (SIEVE != -1) 
				sieve_set.insert(best_heu); 
			
			return true;
		}
	}

	return false;
}

template <typename REAL>
bool Lattice<REAL>::check_best_slk(Vector<REAL> const &ref)
{
	REAL abw;
	abw = slk_abw(ref);

	if (best_slk_abw == -1 || abw <= best_slk_abw) {
		
		if (SCALE)
			best_slk = ref / scale_vector;
		else
			best_slk = ref;

		if (best_slk_abw == -1 || abw < best_slk_abw)  
			best_slk.time = time(NULL) - create_time;

		best_slk_abw = abw;

		slk_improve++;

		if (SIEVE != -1) 
			sieve_set.insert(best_slk); 

		if (best_slk_abw <= slk) {

			if (best_slk_abw == 0)
				new_solution(ref);
			else
				send_signal(15);
		}

		return true;
	}

	return false;
}

/*
	The first "slks" lattice components reflect inequations 
	for the underlying linear problem. 

	This function computes how much these inequations are "injured".

	For this we have to know:
		s_i := MAX(0, (l_u - A_u*x)_i , (A_u*x - r_u)_i) for i = 1,2,...,slks 

	If y is a lattice vector it looks like this:
		y = (2*A_u*x - (l_u + r_u), ...)
		     ---------------------
			         =: y'

	Via prb2lat we get: check_ubnd = r_u - l_u

	So in order to compute s_i, we have to:
		
	a) 1. Subtract check_ubnd from y':
			==> 2*A_u*x - 2*r_u 	
		2. Divide by 2
			==> A_u*x - r_u

	b) 1. Add check_ubnd to y':
			==> 2*A_u*x - 2*l_u
		2. Divide by 2
			==> A_u*x - l_u
		3. Negate
		   ==> l_u - A_u*x
	 
	See chapters 1.4.1 / 5.3 of the dissertation for further details.
*/
template <typename REAL>
REAL Lattice<REAL>::slk_abw(Vector<REAL> const &vec)
{
	register long j;
	REAL abw, t1, t2;

	abw = 0;
	
	if (SCALE) {

		for (j=1; j<=slks; j++) {
			t1 = ((vec[j] / scale_vector[j]) - check_ubnd[j]) / 2;
			t2 = -(((vec[j] / scale_vector[j]) + check_ubnd[j]) / 2);

			abw += (FMAX(TO_REAL(0), FMAX(t1, t2)));
		}

	} else {

		for (j=1; j<=slks; j++) {
			t1 = (vec[j] - check_ubnd[j]) / 2;
			t2 = -((vec[j] + check_ubnd[j]) / 2);

			abw += (FMAX(TO_REAL(0), FMAX(t1, t2)));
		}
	}

	return abw;
}

template <typename REAL>
long Lattice<REAL>::rang(void) const
{
	Vector<long> pmt;
	Matrix<REAL> L, R;

	return B_curr.transpose().gauss(L, R, pmt);
}

/* 
	Compute the integer coords for a lattice vector, 
		such that: vector = (B_curr)^T * coord
*/
template <typename REAL>
bool Lattice<REAL>::compute_lat_coords(Vector<REAL> const &vector, 
		Vector<REAL> &coord)
{
	Vector<long> pmt;
	Matrix<REAL> A, L, R;
	
	long status;

	A = B_curr.transpose();
	A.gauss(L, R, pmt);

	status = compute_coords(L, R, pmt, vector, coord, true);

	if (status != 1) {
		return false;
/*
		if (status == 0)
			ERROR("compute_lat_coords -- lattice has not full rank!");
		
		if (status == -1 || status == -2)
			ERROR("compute_lat_coords -- vector is not part of the lattice!");

		cerr << "status = " << status << endl;
		cerr << "vector = " << vector << endl;
		cerr << "L*R*coord = " << L*R*coord << endl;
		cerr << "pmt = " << pmt << endl;
*/
	} else
		return true;
}

template <typename REAL>
void Lattice<REAL>::compute_gs_classic(void)
{
	compute_gs_classic(1, M);
}

template <typename REAL>
void Lattice<REAL>::compute_gs_classic(register long k, 
		register long m)
{
	register long i;

	for (i=k; i<=m; i++)  
		compute_gs_classic(i);
	
	if (NPRUNE == 2) 
		compute_bdach(k, m);
}

template <typename REAL>
void Lattice<REAL>::compute_bdach(register long k, 
		register long m)
{
	register long i, j;

	for (i=k; i<=m; i++) {
		Bdach[i] = B_curr[i];
		
		for (j=1; j<i; j++)
			Bdach[i] -= Bdach[j]*mu[i][j];
	}
}

/* 
	This functions computes the k-th dual base vector 
*/
template <typename REAL>
void Lattice<REAL>::compute_bstar(Lattice &dual_lat, 
		register long k, register long m) 
{
	register long i, j;

	Matrix<REAL> Rt;
	Vector<REAL> x;

	/************************************************************************/
	/*                             														*/
	/* 	We have B = B_dach * mu^T = 													*/
	/*																								*/
	/*						  [ 1 / ||B_dach[1]||_2			 ]								*/
	/* 		= B_dach * [			...	 		 		 ]								*/
	/* 					  [			1 / ||Bdach[m]||_2 ]								*/
	/*																								*/
	/*										[ ||B_dach[1]||_2					 ]				*/
	/* 								* 	[				...					 ]	* mu^T	*/
	/*										[					||B_dach[m]||_2 ]				*/
	/*																								*/
	/*			= Q * R <==> Q = B * R^(-1)												*/
	/*																								*/
	/*		And for the dual base we have:												*/
	/*																								*/
	/*			B_dual = Q * (R^(-1))^T = B * R^(-1) * (R^(-1))^T					*/
	/* 	<==> B_dual[k] = B_dual * e_k = B * R^(-1) * (R^(-1))^T * e_k		*/
	/*																								*/
	/* 	So in order to easily compute B_dual[k] the equation system			*/
	/*																								*/
	/*			x = R^(-1) * (R^(-1))^T * e_k <==> R^T * R * x = e_k				*/
	/*																								*/
	/*		has to be solved.																	*/
	/*																								*/
	/*		And so we get: 																	*/
	/*									B_dual[k] = B * x 									*/
	/*																							   */
	/************************************************************************/

	Rt.resize(m, m);

	for (i=1; i<=m; i++) {
		for (j=1; j<i; j++)  
			Rt[i][j] = mu[i][j] * SQRT(c[j]); 
		Rt[i][i] = SQRT(c[i]);
	}

	for (i=1; i<=m; i++) 
		for (j=i+1; j<=m; j++) 
			Rt[i][j] = 0.0;
#if 0
	Vector<REAL> e_k;
	Vector<long> pmt;

	e_k.resize(m);

	pmt.resize(m);
	for (i=1; i<=m; i++) { 
		pmt[i] = i;
		e_k[i] = 0;
	}
	
	e_k[k] = 1;

	if (compute_coords(Rt, Rt.transpose(), pmt, e_k, x, true, false) != 1)
		ERROR("compute_coords: Rt*R ist not regular!");
#else
	x.resize(m);

	for (j=1; j<=m; j++) {

		if (j == k)
			x[j] = TO_REAL(1);
		else
			x[j] = TO_REAL(0);

		for (i=1; i<=j-1; i++)
			x[j] -= (Rt[j][i] * x[i]);

		x[j] /= Rt[j][j];
	}

	for (j=m; j>=1; j--) {
		for (i=j+1; i<=m; i++)
			x[j] -= (Rt[i][j] * x[i]);

		x[j] /= Rt[j][j];
	}
#endif

	for (j=1; j<=N; j++) {
		dual_lat.B_curr[k][j] = 0;
		for (i=1; i<=m; i++) 
			dual_lat.B_curr[k][j] += (B_curr[i][j] * x[i]); 	
		
		dual_lat.B[k][j] = dual_lat.B_curr[k][j];
	}
}

/* 
	This function computes the dual base
*/
template <typename REAL>
void Lattice<REAL>::compute_bstar(Lattice &dual_lat) 
{
	register long i;
	dual_lat.resize(M, N);

	compute_gs_qr();
	for (i=1; i<=M; i++) 
		compute_bstar(dual_lat, i, M);
#if 0
	Matrix<REAL> CCC, E;
	CCC = (B_curr * dual_lat.B_curr.transpose());

	for (i=1; i<=CCC.M; i++) {
		for (long j=1; j<=CCC.N; j++) {
			if (ABS(CCC[i][j]) < EPSILON)
				CCC[i][j] = 0;
		}
	}
	
	cerr << CCC << endl;
	E.make_one(CCC.M);

	if (E == CCC)
		cerr << "ok" << endl;
	else
		cerr << "nok" << endl;

	exit(1);
#endif
}

/* 
	The classic routine for computing Gram-Schmidt data 
*/
template <typename REAL>
void Lattice<REAL>::compute_gs_classic(register long k)
{
	bool recompute;
	register long i, j;
	REAL s, t;

	Vector<REAL> buf(k-1);

	do {

		recompute = false;

		for (j=1; j<=k-1; j++) {

			s = (B_curr[j] * B_curr[k]);
			Bgram[k][j] = Bgram[j][k] = s;

			t = 0;
			for (i=1; i<=j-1; i++) 
				t += (mu[j][i] * buf[i]);

			mu[k][j] = (buf[j] = (s - t)) / c[j];
		}

		s = 0;
		for (j=1; j<=k-1; j++) {
			s += (mu[k][j] * buf[j]);
		}

		Bgram[k][k] = B_curr[k] * B_curr[k];

		c[k] = Bgram[k][k] - s;

		if (c[k] <= 0) {

			/***********************************************************/
			/* If we run in this case, we probably have some condition */
			/*     problems ==> Try Householder QR-decomposition       */
			/***********************************************************/ 	

			compute_lengths();

			if (c[k] <= 0) {
				
				/*****************************************************/
				/* Ausblenden von Vektoren, die Probleme verursachen */
				/*****************************************************/

				B_curr[k][0] = -1; // NEW
				for (i=k+1; i<=M; i++) 
					if (B_curr[i][0] != -1) 
						break;

				if (i <= M) {
					swap(k, i);
					recompute = true;

				} else {

					if (VERB == 3)
						WARNING("No valid base vector could be found!");

					c[k] = 0;
				}
			}
		}

		mu[k][k] = 1;

	} while (recompute);
}

/* 
	This function modifies the k-th base vector,
	such that |mu[k][j]| <= 1/2 for all 1 <= j < k
*/
template <typename REAL>
bool Lattice<REAL>::size_reduce(register long k)
{	
	bool ret = false;
	register long i, j;
	REAL mu1, t;

	compute_gs_classic(k, k);

	if (B_curr[k][0] == -1) // NEW 
		return false;

	for (j = k-1; j >= 1; j--) {
		t = ABS(mu[k][j]);

		if (t > 0.5) {

			mu1 = ROUND(mu[k][j]);

			if (mu1 == 1) {
				for (i = 1; i <= j-1; i++)
					mu[k][i] -= mu[j][i];
			}
			else if (mu1 == -1) {
				for (i = 1; i <= j-1; i++)
					mu[k][i] += mu[j][i];
			}
			else {
				for (i = 1; i <= j-1; i++)
					mu[k][i] -= mu1*mu[j][i];
			}

			mu[k][j] -= mu1;
			
			B_curr[k] -= B_curr[j]*mu1;

			if (TRANS)
				T[k] -= T[j]*mu1;

			ret = true;
		}
	}

	if (ret) {
		
		// If you leave this part out you will get an
		// "internal error3" when running: 
		//
		// 		./rasa test/challenge/ch-500.lat

		//cerr << "c_k old = " << c[k] << endl;
		compute_gs_classic(k, k);
		//cerr << "c_k new = " << c[k] << endl;
	}

	if (B_curr[k].is_zero()) {
/*
		for (i=k+1; i<=M; i++) { 

			if (!B_curr[i].is_zero()) {
				swap(k, i);
				return size_reduce(k);
			}
		}

		// If the execution path reaches this point,
		// the remaining base vectors are zero vectors
		
		cerr << "*** size-reduce: Lattice has not full rank!" << endl;
*/
		ERROR("size-reduce: Lattice has not full rank!");
	}

	return ret;
}

/*
	The extended Lovasz condition with deep insertions.
*/
template <typename REAL>
long Lattice<REAL>::deep_reduce(register long k, 
		register double delta)
{
	register long l = 1;

	REAL t1, t2;

	t1 = B_curr[k].quad_euklid_norm(); 
	t2 = c[1];

	while (l < k) {

#if 0
		if (t1 < delta*t2) {

			if (l <= DEEP || k-l <= DEEP) { 

				deep_insert++;

				while (l < k) {
					swap(k, k-1);
					k--;
				}
			}
#else
		if ((l <= DEEP || k-l <= DEEP) && (t1 < delta*t2)) {
	
			deep_insert++;

			while (l < k) {
				swap(k, k-1);
				k--;
			}
#endif
			return k;

		} else {

			t1 = t1 - pow2(mu[k][l]) * t2;
			t2 = c[l+1];

			l++;
		}
	}

	return (k+1);
}

/* 
	The Lovasz condition gets checked in here.
*/
template <typename REAL>
long Lattice<REAL>::lovasz_reduce(register long k, 
		register double delta)
{
	REAL t1, t2;

	t1 = c[k] + pow2(mu[k][k-1]) * c[k-1];
	t2 = c[k-1];

	if (t1 < delta*t2) {
		swap(k, k-1);		
		k--;

		return k;
	}

 	return (k+1);
}

/*
	The LLL-reduction algorithm calls size_reduce
	and afterwards lovasz / deep_reduce.
*/
template <typename REAL>
long Lattice<REAL>::lll(register long k, register long m, 
		register double delta)
{
	register long i, new_k = k;
	register long swap_limit; 

	Vector<long> J;

	/*************************************************/
	/*  To prevent infinite loops, we count in J[k], */
	/*  how often the k-th basis vector gets swapped */
	/*   during this lll call. If it is swapped too  */
	/*    often, we step one vector further.         */
	/*************************************************/
	
	J.resize(m);
	J.clear();

	while (k <= m) {
	
		if (k < new_k)
			new_k = k;

		check_solution(k);
		if (size_reduce(k))
			check_solution(k);

		if (B_curr[k][0] == -1) // NEW
			return k;

      if (k < 2) {
			k++;
			continue;
		}

		swap_limit = 0;
		for (i=k; i<=m; i++) 
			swap_limit += J[i];
		swap_limit /= 2;
		swap_limit++;

		if (J[k] < swap_limit) {

			J[k]++;

			if (DEEP > 0) 
				k = deep_reduce(k, delta);
			else 
				k = lovasz_reduce(k, delta);

		} else {

			J[k]--;
			k++;
		}
	}

	return new_k;
}

template <typename REAL>
void Lattice<REAL>::set_enum_bounds(REAL const &cbar, 
		REAL &F_oo, REAL &F_1, REAL &F_2, bool full_enum)
{

	if (full_enum) {

		F_2 = SQRT(FMAX(check_lbnd.quad_euklid_norm(),
								check_ubnd.quad_euklid_norm()));

		F_oo = FMAX(check_lbnd.sup_norm(), check_ubnd.sup_norm());
		F_1 = FMAX(check_lbnd.eins_norm(), check_ubnd.eins_norm());

	} else {

		/* ||ctilda[t]||_2 <= ||cbar||_2 = F_2*F_2 */

		F_2 = SQRT(cbar);

		F_oo = F_2; 	// F_00 = max { ||v||_oo : ||v||_2 = F_2 }
		F_1 = N * F_2;	// F_1 = max { ||v||_1 : ||v||_2 = F_2 }
	
	}
}

/*
	This function computes a maximal bound for |utilda[t]|.
*/
template <typename REAL>
void Lattice<REAL>::compute_utilda_bnds(REAL const &F_2, register long t) 
{
	REAL X;

	/**********************************************************************/
	/* |utilda[t] + ytilda[t]| <= F_2 * ||Bdach[t]||2 / (||Bdach[t]||2)^2 */
	/**********************************************************************/

	X = F_2 * (1.0 / SQRT(c[t]));

	stage[t].utilda_lb = -X - stage[t].ytilda;
	stage[t].utilda_ub =  X - stage[t].ytilda;
	
	stage[t].utilda_lb = CEIL(stage[t].utilda_lb);
	stage[t].utilda_ub = FLOOR(stage[t].utilda_ub);
}

/*
	Another maximal bound for |utilda[t]| is calculated 
	in here. For this the 00-, 1- and 2-norm of the t-th 
	dual base vector get computed.
*/
template <typename REAL>
REAL Lattice<REAL>::compute_bstar_bnd(Vector<REAL> const &Bstar_t, REAL const &F_oo, REAL const &F_1, REAL const &F_2)
{
	register long j;

	REAL bstar_1, bstar_2, bstar_oo, t1;
	bstar_1 = 0; bstar_2 = 0; bstar_oo = 0;;

	for (j=1; j<=N; j++) {
		t1 = ABS(Bstar_t[j]);
		bstar_1 += t1;
		bstar_2 += t1*t1;
		bstar_oo = FMAX(t1, bstar_oo);
	}

	/**************************************************************************/
	/* utilda[t] = utilda*B * Bstar[t] ==> |utilda[t]| = |<utilda*B, Bstar[t]>| */
	/**************************************************************************/

	/****************************************************/
	/* The application of the Hölder inequality yields: */
	/* //////////////////////////////////////////////// */
	/*                                                  */
	/*			a) |utilda[t]| <= F_oo * bstar_				 */
	/* 		b) |utilda[t]| <= F_2 * bstar_2				 */
	/* 		c) |utilda[t]| <= F_1 * bstar_oo				 */
	/*                                                  */
	/****************************************************/

	bstar_2 = SQRT(bstar_2);
	bstar_1 *= F_oo;
	bstar_2 *= F_2;
	bstar_oo *= F_1;

	t1 = FMIN(bstar_1, bstar_2);
	t1 = FMIN(t1, bstar_oo);
	
	return t1;
}

/*
	The pruning tests (see chapter 2.4 of the dissertation) 
	are implemented in this function.
*/
template <typename REAL>
bool Lattice<REAL>::check_nprune(REAL const &F_oo, REAL const &F_1, 
		REAL const &F_2, REAL const &q, Lattice &dual_lat,	register long t) 
{
	if (!NPRUNE)
		return false;

	REAL tmp, t0, t1, d2;
	register long i;

	d2 = c[t];

	/********************************************************************/
	/* |utilda[t] + ytilda[t]| > F_2 * ||Bdach[t]||2/(||Bdach[t]||2)^2, */
	/********************************************************************/

	if (q > (F_2 / SQRT(d2))) 
		return true;

	if (NPRUNE == 2) {

		t0 = 0;
		t1 = 0;

		for (i=1; i<=N; i++) {
			tmp = ABS(Btilda[t][i]);
			t1 += tmp;
			t0 = FMAX(t0, tmp);
		}

		/***************************************/
		/* ctilda[t] > F_oo * ||Btilda[t]|||1, */
		/***************************************/

		if (stage[t].ctilda > F_oo * t1) 
			return true;

		/***************************************/
		/* ctilda[t] > F_1 * ||Btilda[t]|||oo, */
		/***************************************/

		if (stage[t].ctilda > F_1 * t0) 
			return true;
		
		t0 = 0;
		t1 = 0;
		for (i=1; i<=N; i++) {
			tmp = ABS(Bdach[t][i]);
			t1 += tmp;
			t0 = FMAX(t0, tmp);
		}

		/********************************************************************/
		/* |utilda[t] + ytilda[t]| > F_oo * ||Bdach[t]||1/(||Bdach[t]||2)^2 */
		/********************************************************************/
	
		if (q > F_oo * (t1 / d2)) 
			return true;

		/***********************************************************************/
		/* |utilda[t] + ytilda[t]| > F_1 * ||Bdach[t]||oo / (||Bdach[t]||2)^2, */
		/***********************************************************************/

		if (q > F_1 * (t0 / d2)) 
			return false;

		if (dual_lat.B_curr[t][0] == 0) {
			compute_bstar(dual_lat, t, M);
			dual_lat.B_curr[t][0] = 1;
		}
		
		/************************************/
		/* |utilda[t]| > F_p * ||Bstar[t]||q */
		/************************************/

		tmp = compute_bstar_bnd(dual_lat.B_curr[t], F_oo, F_1, F_2);
		if (ABS(stage[t].utilda) > tmp)
			return true;
	}

	/*********************************************/
	// If the execution flow reaches this point, //
	//  we can NOT prune the enumeration tree!   //
	/*********************************************/
	
	return false;
}

/*
	This function checks that the first 
	non-zero coefficient of the vector
	which gets enumerated is > 0.
*/
template <typename REAL>
bool Lattice<REAL>::check_utilda(register long t, 
		register long ss)
{
	register long i;

	if (stage[t].utilda > stage[t].utilda_ub 
			|| stage[t].utilda < stage[t].utilda_lb) 
		return false;

	if (stage[t].utilda_lb <= 0) {
		for (i=t+1; i<=ss; i++)
			if (stage[i].utilda != 0)
				break;

		if (i > ss) {
			while (stage[t].utilda <= 0)
				next_utilda(t, ss);

				if (stage[t].utilda > stage[t].utilda_ub)
					return false;
		}
	}

	return true;
}

template <typename REAL>
void Lattice<REAL>::compute_ytilda(register long t, 
		register long ss) 
{
	register long i;
	REAL tmp;
	
	tmp = 0;
	for (i = t+1; i <= ss; i++)
		tmp += stage[i].utilda*mu[i][t];

	stage[t].ytilda = tmp;
}

/*
	This method gets called, when a backtracking step has to be made during 
	the BKZ enumeration. It is responsible for calling compute_ytilda /
	compute_utilda_bnds and initializes the needed variables for this stage.
*/
template <typename REAL>
bool Lattice<REAL>::compute_stage(REAL const &F_2, register long t,
		register long ss) 
{
	compute_ytilda(t, ss);
	compute_utilda_bnds(F_2, t); 

	if (stage[t].utilda_lb >= stage[t].utilda_ub && t < ss) {
		return false;
	}
	
	stage[t].vtilda = ROUND(-stage[t].ytilda);
	stage[t].Delta = TO_REAL(0);

	if (stage[t].vtilda > -stage[t].ytilda) 
		stage[t].delta = TO_REAL(-1);
	else 
		stage[t].delta = TO_REAL(1);

	stage[t].nprune = false;

	stage[t].utilda = stage[t].vtilda;

	return true;
}

/*
	The next value for utilda[t] is computed in this function
*/
template <typename REAL>
void Lattice<REAL>::next_utilda(register long t, 
		register long ss)
{
	if (t < ss && !(stage[t].nprune))
		stage[t].Delta = -stage[t].Delta;

	if (stage[t].Delta * stage[t].delta >= 0) 
		stage[t].Delta += stage[t].delta;

	stage[t].utilda = stage[t].vtilda + stage[t].Delta;
}

template <typename REAL>
void Lattice<REAL>::bkz(register double delta, 
		register long beta)
{
	bool cond, clean = false, t_plus = false, t_minus = false;

	register long i, t, jj, ss, kk, hh, zz;
	register long new_k;

	time_t start_tt, last_tt, tt;
	time_t interval_tt = 3600; 

	REAL F_oo, F_1, F_2;
	REAL cbar, q;
	
	Vector<REAL> ubar; 
	ubar.resize(M);

	Lattice dual_lat;
	
	time(&last_tt);
	start_tt = last_tt;
	
	dual_lat.resize(M, N);

	for (i=1; i<=M; i++)
		B_curr[i][0] = 0;

	beta = LMIN(beta, M);

	if (VERB >= 2)
		cerr << "-> BKZ reducing ( beta = " << beta << " ) ... " << endl;

	if (B_curr[lll(1, M, delta)][0] == -1) 
		return;
	
	if (M > 1 && beta > 2) {

		if (beta > M) 
			beta = M;

		jj = 0;
		zz = 0;

		while (zz < M-1) {

			jj++;

			if (jj == M) {
				jj = 1;
				clean = true; 
			}

			kk = LMIN(jj+beta-1, M);
			hh = LMIN(kk+1, M);

			//// BEGINN Initialisierung ////

			cbar = c[jj];
			
			for(i=jj; i<=kk+1; i++) 
				stage[i].clear();
				
			ubar.clear(jj, kk);

			if (NPRUNE == 2) {
				for (i=jj; i<=kk+1; i++) 
					Btilda[i].clear();
			}

			ubar[jj] = stage[jj].utilda = 1;

			set_enum_bounds(cbar, F_oo, F_1, F_2, (beta >= M));

			ss = t = jj;
			
			if (!compute_stage(F_2, jj, ss)) 
				ERROR("utilda_lb / ub error1");

			//// ENDE Initialisierung ////
		
			while (t <= kk) {

				time(&tt);

				if (BTIME && (tt - start_tt >= BTIME)) { 
					lll(jj, M, delta);
					return;
				}
		
				if (tt > last_tt + interval_tt) {

					last_tt = tt;

					if (VERB >= 2) 
						cerr << "* ";

					compute_lengths();
				}

				//// BEGINN Initialisierung der Grenzen ////
				
				if (t_plus) {
					t_plus = false;

					if (t > ss) {
						if (!compute_stage(F_2, t, ss))
							ERROR("utilda_lb / ub error2");

						ss = LMAX(ss, t);
					} else
						next_utilda(t, ss);
				}

				if (t_minus) {
					t_minus = false;

					if (!compute_stage(F_2, t, ss)) {
						t++;
						t_plus = true;
						continue;
					}
				}

				if (!check_utilda(t, ss)) {
					t++;
					t_plus = true;
					continue;
				}

				//// ENDE Initialisierung der Grenzen ////

				q = stage[t].ytilda + stage[t].utilda;
				
				stage[t].ctilda = stage[t+1].ctilda + pow2(q)*c[t];

				if (NPRUNE == 2)
					Btilda[t] = Btilda[t+1] + Bdach[t]*q;

				if (EPRUNE) {
					  
					register long l = kk + jj - t;
					register long k = l - jj + 1, n = kk - jj + 1;
					
					/* EXTREME Pruning */

					if (EPRUNE == 1) { // Linear Bounding Function

						cond = (SQRT(stage[t].ctilda) 
								< SQRT(TO_REAL(k)/TO_REAL(n)) * F_2);
					
					} else if (EPRUNE == 2) { // Step Bounding Function

						if (t >= (jj + kk) / 2)
							cond = (SQRT(stage[t].ctilda) < SQRT(ALPHA) * F_2);
						else
							cond = (SQRT(stage[t].ctilda) < F_2);

					} else { // Piecewise-Linear Bounding Function

						REAL term;

						if (t >= (jj + kk) / 2) 
							term = (2*ALPHA - 1 + ((1 - ALPHA)*2*(k-1)+1) / n);
						else 
							term = ((ALPHA*2*k) / n);

						cond = (SQRT(stage[t].ctilda) < SQRT(term) * F_2);
					}

				} else {

					/* STANDARD Enumeration Condition */

					// If the euclidean norm of the projected vector 
					// is smaller than F_2 [ == SQRT(cbar) ], then it is 
					// a substitution candidate for the t-th base vector.

					cond = (SQRT(stage[t].ctilda) < F_2);
				}

				if (cond) {
				
					if (check_nprune(F_oo, F_1, F_2, ABS(q), dual_lat, t)) {

						bkz_nprune++;

						if (stage[t].nprune == false) {
							next_utilda(t, ss);
							
							stage[t].nprune = true;
							continue;
						} 

						cond = false;
					}
				} 
					
				//// BEGINN Backtracking - Check ////

				if (cond) {
						
					if (t > jj) {
						t_minus = true;
						t--;
					}

					else {

						for (i = jj; i <= kk; i++) 
							ubar[i] = stage[i].utilda;

						check_solution(ubar, jj, kk); 

						cbar = stage[jj].ctilda;
						set_enum_bounds(cbar, F_oo, F_1, F_2, (beta >= M));
					}

				} else {

					t++;
					t_plus = true;
				}

				//// ENDE Backtracking - Check ////
			
			}
				
			cond = (cbar < delta*c[jj]);

			//// BEGINN der Basistransformation ////

			if (cond) {

				basis_extend(ubar, jj, kk);
				new_k = lll(jj, hh, delta);

				if (B_curr[new_k][0] == -1) 
					return;

				if (new_k < jj) 
					jj = new_k - 1; 

				zz = 0;

				clean = false;
			} 

			//// ENDE der Basistransformation ////
			
			else {	

				new_k = hh+1;

				if (!clean) {

					new_k = lll(hh, hh, delta);
						
					if (B_curr[new_k][0] == -1) 
						return;

					if (new_k < jj) 
						jj = new_k - 1; 
				}
				
				zz++;
			}

			for (i=new_k; i<=hh; i++)
				check_solution(i);

			for (i=1; i<=M; i++)
				dual_lat.B_curr[i][0] = 0;
		}
	}

	time(&tt);
	last_tt = tt;
}

/*
	If ||{-1, 1} * b_i + {-1 , 1} * b_j|| < max {||b_i|| , ||b_j||}, 
	then replace the larger of b_i, b_j with {-1, 1} b_i + {-1, 1} * b_j
*/
template <typename REAL>
void Lattice<REAL>::pair_reduce(void) 
{
	bool retry = true;

	register long idx;
	register long h, i, l;

	Vector<REAL> tmp_vec;
	REAL r, b_h, b_i;;

	if (VERB >= 2) {
		cerr << ext_prec << "-> Pairwise Reduction ...";
		cerr << endl;
	}

	while (retry) {

		retry = false;

		for (h=1; h<=M; h++) {
			for (i=1; i<=M; i++) {

				if (i == h)
					continue;

				for (l=-1; l<=1; l+=2) {

					B_curr[0] = B_curr[h] + B_curr[i]*TO_REAL(l);
					check_solution(0);

					r = (this->*abw_fptr)(B_curr[0]);

					b_h = (this->*abw_fptr)(B_curr[h]);
					b_i = (this->*abw_fptr)(B_curr[i]);

					if (r < b_h)
						idx = h;
					else if (r < b_i)
						idx = i;
					else {

						r = (this->*abw_fptr)(-B_curr[0]);

						if (r < b_h)
							idx = -h;
						else if (r < b_i)
							idx = -i;
						else 					
							continue;
					}

					if (TRANS)
						tmp_vec = (T[h] + T[i]*TO_REAL(l));

					if (idx < 0) {
						idx = -idx;
						B_curr[0] = -B_curr[0];

						if (TRANS) 
							tmp_vec = -tmp_vec;
					} 

					b[idx] = B_curr[0].quad_euklid_norm();
					B_curr[idx] = B_curr[0];
					if (TRANS) 
						T[idx] = tmp_vec;

					pair_cnt++;
					retry = true;
				}
			}
		}
	}
}

template <typename REAL>
bool Lattice<REAL>::best_heu_insert(void) 
{
	register long j;
	bool ret;
	
	Vector<REAL> coord, *vector;

	if (VERB >= 2)
		cerr << "-> Inserting best heuristic vector ... " << endl;

	if (heu_update) {
					
		heu_update = false;

		if (SCALE) {
			vector = new Vector<REAL>(best_heu);
			for (j=1; j<=N; j++)
				(*vector)[j] *= scale_vector[j];
		} else
			vector = &best_heu;

		if ((ret = compute_lat_coords(*vector, coord))) 
			basis_replace(coord, 1, M, M);

		if (SCALE)
			delete vector;

		return ret;
	}

	return false;
}

template <typename REAL>
REAL Lattice<REAL>::regula_falsi(
	REAL (Lattice::*f)(Vector<REAL> const &, 
		register long, register long, register long, REAL const &), 
	Vector<REAL> const &len, register long k, register long u, 
	register long m, REAL const &delta_c_k, REAL &a, REAL &b) 
{
	register long i;
	REAL x, x_old, eps;
	
	x_old = b;

	if (((this->*f)(len, k, u, m, a) - delta_c_k) 
			* ((this->*f)(len, k, u, m, b) - delta_c_k) > 0) {
		ERROR("f(a)*f(b) >= 0!");
	}
	
	eps = EPSILON;
	
	i = 0;

	while (i < LOOP_LIMIT) {

		x = a - ((this->*f)(len, k, u, m, a) - delta_c_k) * (b - a) / 
			(((this->*f)(len, k, u, m, b) - delta_c_k) 
				- ((this->*f)(len, k, u, m, a) - delta_c_k));

		if (ABS(x - x_old) < eps*ABS(x))
			return x;

		x_old = x;
		
		if (((this->*f)(len, k, u, m, a) - delta_c_k) *
				((this->*f)(len, k, u, m, x) - delta_c_k) > 0)
			a = x;
		else
			b = x;

		i++;
	}

	if (VERB == 3)
		WARNING("regula_falsi: LOOP_LIMIT reached!");

	return x;
}

/* 
	The expected length of a sampled lattice vector is calculated 
	in this function (see chapter 3.3 of the dissertation).
*/
template <typename REAL>
REAL Lattice<REAL>::exp_length(Vector<REAL> const &len, register long k, 
	register long u, register long m, REAL const &q)
{
	register long i;
	REAL sum, sum2;

	sum = sum2 = 0;
	
	for (i=1; i<=k-1; i++) 
		sum += (pow(q, TO_REAL(k-i))*len[i]);
	
	for (i=k; i<=m-u-1; i++)
		sum += len[i];

	sum *= TO_REAL(1.0/12.0);
	
	for (i=m-u; i<=m-1; i++)
		sum2 += len[i];

	sum2 *= TO_REAL(1.0/3.0);

	sum += sum2;
	sum += len[m];

	return sum;
}

/*
 	The root of the function:
			f(q) := exp_length(..., q) - delta*c[k] 

	is computed in here. This is accomplished with 
	a call to the regula_falsi method.
*/
template <typename REAL>
long Lattice<REAL>::log_success_prob_bound(Vector<REAL> const &len,  
	register	long k, register long u, register long m, REAL const &delta_c_k)
{
	REAL a, b, q;

	a = 0;
	b = 1;

	if (exp_length(len, k, u, m, b) <= delta_c_k)
		return -1;
	else if (exp_length(len, k, u, m, a) >= delta_c_k) 
		return -m;

	q = regula_falsi(&Lattice::exp_length, len, k, u, m, delta_c_k, a, b);

	return TO_LONG(FLOOR((log(q)/log(2.0)) * (k*(k-1)/4.0) - 1)); 
}

/*
 	This procedure calculates for the parameter u an exponent p, such that
	the probability to locate a lattice vector b with:

					||PI_k(b)||^2 <= delta * || Bdach[k]||^2 
	
	gets maximal, if at least 2^(-p) vectors are sampled.
*/
template <typename REAL>
long Lattice<REAL>::best_bound(register long u, register long k, 
		register long m, REAL const &delta_c_k) 
{
	REAL tmp;
	register long i, j;
	register long bnd, max;
	
	Vector<REAL> len(m);

	// Ludwig's ESHORT-Variante
	for (i=1; i<k; i++)
		len[i] = 0;
	for (i=k; i<=m; i++)
		len[i] = c[i];

	// Bubble-Sort Variante (sortiert die Laengen der ersten 
	// m-u-1 orthogonalen Basisvektoren absteigend und 
	// laesst die letzten u+1 fix)
	for (i=k; i<=m-u-1; i++) {
		for (j=i+1; j<=m-u-1; j++)
			if (len[j] > len[i]) {
				tmp = len[i];
				len[i] = len[j];
				len[j] = tmp;
			}
	}

	// Berechne die beste Grenze
	max = log_success_prob_bound(len, k, u, m, delta_c_k);
	for (j=k+1; j<=m-u; j++) {
		bnd = log_success_prob_bound(len, j, u, m, delta_c_k);
		if (bnd > max)
			max = bnd;
	}

	return max;
}

template <typename REAL>
long Lattice<REAL>::buchmann_strategy(register long k, 
		register long m, register double delta) 
{
	REAL delta_c_k;
	register long u, p;

	delta_c_k = delta*c[k];

	// Compute that u for which the success 
	// probability is sufficiently high enough.

	for (u=1; u<m; u++) {
		p = best_bound(u, k, m, delta_c_k);
		if (-p <= u) 
			break;
	}

	if (u >= m) { 
		
		if (VERB == 3) 
			WARNING("buchmann_strategy: success probability too small!");

		u = 2;
	}

	return u;
}

template <typename REAL>
long Lattice<REAL>::schnorr_strategy(register long k, 
		register long m) 
{
	register long i, j, best_u;
	register long best_k;
	
	REAL best_w, w, Q;
	Vector<REAL> q(m);

	// Bestimmung von Q

	for (i=k+1; i<=m; i++) {
		q[i] = c[i] / c[k];
		q[i] = pow(q[i], TO_REAL(1.0/(i-1)));
	}

	for (i=k+1; i<=m; i++) { 
		for (j=i+1; j<m; j++) 
			if (q[j] < q[i]) {
				Q = q[i];
				q[i] = q[j];
				q[j] = Q;
			}
	}

	// Q wird der Median
	
	if ((m-k-1) % 2 == 0)
		Q = (1.0/2.0) * (q[(m-k-1)/2 + 1] + q[(m-k-1)/2 + 2]);
	else
		Q = q[(m-k)/2 + 1];
	
	// 0.75 <= Q < 1

	Q = FMAX(Q, TO_REAL(0.75));
	Q = FMIN(Q, TO_REAL(0.999999));

	k = 1;
	best_u = 1;
	best_k = 1;

	best_w = (1.0/12.0) * (1.0 + (Q + 3.0*pow(Q, TO_REAL(3.0)))/(1.0-Q));

	while (3*k + best_u < m) {

		w = (1.0 / 12.0) * (k*pow(Q, TO_REAL(k-1.0)) + (pow(Q, TO_REAL(1.0*k)) 
					+ 3.0*pow(Q, TO_REAL(3.0*k)))/(1.0-Q));

		if (w < 0.99)
			break;

		if (w < best_w) {
			best_k = k;
			best_w = w;
		}

		k++;
		best_u = TO_LONG(1+CEIL((-k*(k-1)*log(Q))/(log(2.0)*4))); 
	}

	if (3*k + best_u >= m) {
			
		if (VERB == 3)
				WARNING("schnorr_strategy: success probability too small!");

		if (best_w < 2.0) 
			best_u = TO_LONG(1+CEIL((-best_k*(best_k-1)*log(Q))/(log(2.0)*4))); 
		else {
			best_u = 2; 
		}
	}

	return best_u;
}

/*
 	The sample algorithm SA expects a parameter u, which is computed 
	in this procedure according to the selected GSA strategy.
*/
template <typename REAL>
long Lattice<REAL>::compute_usa(register long k, 
		register long m, register double delta, register long gsa)
{
	compute_lengths();
	if (gsa == 1) 
		return schnorr_strategy(k, m);
	else if (gsa == 2)
		return buchmann_strategy(k, m, delta);
	else
		ERROR("This gsa strategy is not implemented!");
}

/*
	The random sampling routine, which generates 
	lattice vectors for which: 
		
	a)	| <b, B_dach[j]> / <B_dach[j], B_dach[j]> |	<= 1/2 for j=1,2,...,m-u-1
	b)	| <b, B_dach[j]> / <B_dach[j], B_dach[j]> |	<= 1 for j=m-u,m-u+1,...,m
*/
template <typename REAL>
void Lattice<REAL>::sa(Sample<REAL> * const sam, register long k, 
		register long m, register long u)
{
	register long i, j;
	REAL lower, upper, _mu_;
		
	sam->U[m] = 1;
	sam->MU[m] = 1.0; 

	for (i=1; i<m; i++) {
		sam->U[i] = 0;
		sam->MU[i] = mu[m][i];
	}

	sam->B = B_curr[m];

	for (i=m-1; i>=m-u; i--) {

		lower = CEIL(sam->MU[i] - 1);
		upper = FLOOR(sam->MU[i] + 1);

		_mu_ = rand_eq_real(lower, upper); 

		sam->B = sam->B - B_curr[i]*_mu_;
		sam->U[i] -= TO_REAL(_mu_);

		for (j=1; j<i; j++)
			sam->MU[j] = sam->MU[j] - _mu_ * mu[i][j];
		sam->MU[i] = sam->MU[i] - _mu_;
	}

	for (; i>=k; i--) {

		lower = CEIL(sam->MU[i] - 0.5);
		upper = FLOOR(sam->MU[i] + 0.5);

		_mu_ = rand_eq_real(lower, upper); 

		sam->B = sam->B - B_curr[i]*_mu_;
		sam->U[i] -= TO_REAL(_mu_);

		for (j=1; j<i; j++)
			sam->MU[j] = sam->MU[j] - _mu_ * mu[i][j];
		sam->MU[i] = sam->MU[i] - _mu_;
	}
}	

/*
	This function scans the coord vector between the k-th 
	and m-th coordinate for an entry which equals to +- 1. 
	
	If no such entry could be found the basis gets 
	extended with help of the basis(_extend) function.
	
	In the other case, when such a entry could be located,
	the corresponding base vector is modified by adding up 
	the remaining coordinate / base vector products.
	
	Both cases end with a swap of the 
	k-th base vector to the l-th position.
*/
template <typename REAL>
void Lattice<REAL>::basis_replace(Vector<REAL> &coord,
		register long k, register long m, register long l)
{
	register long i, o;

	for (o=m; o>=k; o--) 
		if (ABS(coord[o]) == 1)
			break;

	if (o < k) { 
		basis_extend(coord, k, m); 
		for (i=k; i<l; i++) 
			swap(i, i+1);

	} else {

		if (coord[o] == -1) {
			B_curr[o] = -B_curr[o];

			if (TRANS)
				T[o] = -T[o];
		}

		for (i=k; i<o; i++)  
			B_curr[o] += (B_curr[i] * TO_REAL(coord[i]));
		
		for (i=o+1; i<=m; i++)  
			B_curr[o] += (B_curr[i] * TO_REAL(coord[i]));

		if (TRANS)  {
			for (i=k; i<o; i++) 
				T[o] += (T[i] * TO_REAL(coord[i]));
			for (i=o+1; i<=m; i++) 
				T[o] += (T[i] * TO_REAL(coord[i]));
		}

		if (l < k)
			l = k;

		if (l < o) {
			for (i=o; i>l; i--) 
				swap(i, i-1);
		} else {
			for (i=o; i<l; i++) 
				swap(i, i+1);
		}
	}
}

/*
	This function realizes the replacement step for the dual base, 
	which is described at the end of chapter 3.4 of the dissertation.
*/
template <typename REAL>
void Lattice<REAL>::basis_replace_dual(Vector<REAL> &coord, register long k, 
		register long m)
{
	register long i, km_2;

#ifdef REVERSED
	// Reverse the order of the base vectors
	 
	km_2 = ((m-k) / 2);

	for (i=k; i<=km_2; i++) 
		swap(i, m-i+k);
#endif
	for (i=m; i>k; i--) {
		swap(i, i-1);
		
		B_curr[i] -= (B_curr[i-1] * TO_REAL(coord[i-1]));

		if (TRANS)
			T[i] -= (T[i-1] * TO_REAL(coord[i-1]));
	}
}

template <typename REAL>
REAL Lattice<REAL>::compute_pi(Vector<REAL> const & lambda, REAL const & len,
		register long k, register long m)
{
	register long i;
	REAL pi;

	if (k > m/2) {

		pi = 0;
		for (i=k; i<=m; i++) 
			pi += pow2(lambda[i]) * c[i];

	} else {

		pi = len;
		for (i=1; i<k; i++) 
			pi -= pow2(lambda[i]) * c[i];
	}

	return pi;
}

/* 
 	The next routine combines SHORT and ESHORT 
*/
template <typename REAL>
bool Lattice<REAL>::exshort_sr(register long k, register long m, 
		register double delta, register long gsa, bool prj)
{
	time_t start;
	register long i, l, u, zz, limit;

	Vector<REAL> delta_b, delta_c;

	Vector<Sample<REAL> > sample; 
	Sample<REAL> *sam;

	if (VERB >= 2) {
		cerr << "-> ExSHORT Sampling ( k = " << k << ", m = ";
		cerr << m << " ) ..." << endl;
	}

	time(&start);

	if (SLIMIT < (limit = pow(2, u = compute_usa(k, m, delta, gsa)))) {

		if (VERB == 3)
			WARNING("Sample Limit is too small: " << SLIMIT << " < " << limit);

		limit = SLIMIT;
	}

	delta_b.resize(m);
	delta_c.resize(m);

	for (zz=k; zz<=m; zz++) 
		delta_b[zz] = delta * b[zz];

	if (prj) 
		for (zz=k; zz<=m; zz++) 
			delta_c[zz] = delta * c[zz];

	sample.resize(m); 

	for (i=0; i<=m; i++) {
		sample[i].U.resize(m);
		sample[i].MU.resize(m);
		sample[i].B.resize(N);
		sample[i].len = sample[i].pi = 0;
	}

	sam = &(sample[0]);

	for (l=0; l<limit; l++) {

		sa(sam, k, m, u);
		sam->len = sam->B.quad_euklid_norm();
		check_solution(sam->U, k, m);

		for (zz=k; zz<=m; zz++) {

			if ((sam->len <= delta_b[zz] && sample[zz].len == 0) 
					|| (sam->len < sample[zz].len)) {
				
				if (prj)
					sam->pi = compute_pi(sam->MU, sam->len, k, m);
				sam->pos = i+1;

				sswap(sample[zz], (*sam));
				break;
			}

			if (prj) {

				if (zz == k) 
					sam->pi = compute_pi(sam->MU, sam->len, k, m);
				else  
					sam->pi -= pow2(sam->MU[zz-1]) * c[zz-1];

				if ((sam->len <= delta_b[zz]) && 
						((sam->pi <= delta_c[zz] && sample[zz].pi == 0) 
						 || (sam->pi < sample[zz].pi)) ) { 

					sam->pos = -(l+1);

					sswap(sample[zz], (*sam));
					break;
				}
			}
		}
	}

	// Find the best sample vector
	 
	for (i=k; i<=m; i++) 
		if (sample[i].len > 0 || sample[i].pi > 0) 
			break;

	if (i <= m) {
	
		if (sample[i].pos > 0)
			short_cnt++;
		else
			eshort_cnt++;

		basis_replace(sample[i].U, i, m); 

		if (SIEVE != -1) { 

			if (SCALE)
				sieve_set.insert(sample[i].B / scale_vector);
			else
				sieve_set.insert(sample[i].B); 
		}

		return true;
	} 

	return false;
}

/* 
 	The random sampling routine ESHORT
*/
template <typename REAL>
bool Lattice<REAL>::eshort_sr(register long k, 
		register long m, register double delta, register long gsa)
{
	time_t start;
	register long i, l, u, zz, limit;

	Vector<REAL> delta_c;

	Vector<Sample<REAL> > sample; 
	Sample<REAL> *sam;

	delta_c.resize(m);

	sample.resize(m); 
	for (i=0; i<=m; i++) {
		sample[i].U.resize(m);
		sample[i].MU.resize(m);
		sample[i].B.resize(N);
		sample[i].len = sample[i].pi = 0;
	}

	sam = &(sample[0]);
	
	if (VERB >= 2) {
		cerr << "-> ESHORT Sampling ( k = " << k << ", m = ";
		cerr << m << " ) ..." << endl;
	}

	time(&start);
	
	limit = pow(2, u = compute_usa(k, m, delta, gsa));

	if (SLIMIT < limit) {

		if (VERB == 3)
			WARNING("Sample Limit is too small: " << SLIMIT << " < " << limit);

		limit = SLIMIT;
	}

	for (l=0; l<limit; l++) {

		sa(sam, k, m, u);
		
		check_solution(sam->U, k, m);

		for (zz=k; zz<=m; zz++) {

			delta_c[zz] = delta * c[zz];
			if (delta_c[zz] < EPSILON)
 				continue;

			if (zz == k) {
			
				sam->len = sam->B.quad_euklid_norm();

				if (zz > m/2) {

					sam->pi = 0;
					for (i=zz; i<=m; i++) 
						sam->pi += pow2(sam->MU[i]) * c[i];

				} else {

					sam->pi = sam->len;
					for (i=1; i<zz; i++) 
						sam->pi -= pow2(sam->MU[i]) * c[i];
				}

			} else  
				sam->pi -= pow2(sam->MU[zz-1]) * c[zz-1];
			
			if (((sam->pi < delta_c[zz] && sample[zz].pi == 0) 
						|| (sam->pi < sample[zz].pi && sample[zz].pi != 0))
							&& sam->len <= b[zz]) { 

				sswap(sample[zz], (*sam));
				sample[zz].pos = l+1;

				break;
			}
		}
	}
	
	// Find the best sample vector
	for (i=k; i<=m; i++)
		if (sample[i].pi > 0) 
			break;

	if (i <= m) {
		basis_replace(sample[i].U, i, m); 

	   eshort_cnt++;

		if (SIEVE != -1) { 

			if (SCALE)
				sieve_set.insert(sample[i].B / scale_vector);
			else
				sieve_set.insert(sample[i].B); 
		}

		return true;
	} 

	return false;
}

/* 
 	The random sampling routine SHORT
*/
template <typename REAL>
bool Lattice<REAL>::short_sr(register long k, register long m, 
		register double delta, register long gsa)
{
	time_t start;
	register long i, l, u, zz, limit;

	Vector<Sample<REAL> > sample; 
	Sample<REAL> *sam;

	sample.resize(m); 
	
	for (i=0; i<=m; i++) {
		sample[i].U.resize(M);
		sample[i].MU.resize(M);
		sample[i].B.resize(N);
		sample[i].len = sample[i].pi = 0;
	}

	sam = &(sample[0]);
	
	if (VERB >= 2) {
		cerr << "-> SHORT Sampling ( k = " << k << ", m = ";
		cerr << m << " ) ..." << endl;
	}

	time(&start); 
	
	limit = pow(2, u = compute_usa(k, m, delta, gsa));

	if (SLIMIT < limit) {

		if (VERB == 3)
			WARNING("Sample Limit is too small: " << SLIMIT << " < " << limit);

		limit = SLIMIT;
	}

	for (i=0; i<limit; i++) {
		sa(sam, k, m, u);
		
		check_solution(sam->U, k, m);

		sam->len = sam->B.quad_euklid_norm();

		for (zz=k; zz<=m; zz++) {

			if ((sam->len < delta * b[zz] && sample[zz].len == 0) 
					|| (sam->len < sample[zz].len && sample[zz].len != 0)) {
				
				sswap(sample[zz], (*sam));
				sample[zz].pos = i+1;

				break;
			}
		}
	}
	
	// Find the best sample vector
	for (l=k; l<=m; l++)
		if (sample[l].len > 0) 
			break;

	if (l <= m) {
		basis_replace(sample[l].U, l, m); 

		short_cnt++;

		if (SIEVE != -1) {

			if (SCALE)
				sieve_set.insert(sample[l].B / scale_vector);
			else
				sieve_set.insert(sample[l].B); 
		}

		return true;
	} 

	return false;
}

/*
	This function computes for a given vector
	the lattice coordinates. These coordinates
	are rounded to integer values and the 
	corresponding lattice vector is returned.
*/
template <typename REAL>
void Lattice<REAL>::babai(Matrix<REAL> const &L, 
	Matrix<REAL> const &R, Vector<long> const &pmt, 
	Vector<REAL> const &vec, Vector<REAL> &lat_vec) 
{
	Vector<REAL> coord;
	
	compute_coords(L, R, pmt, vec, coord, true);
	lat_vec = B_curr.transpose()*coord;
}

template <typename REAL>
void Lattice<REAL>::fill_sieve(void)
{
	register long j;

	Vector<long> pmt;
	Vector<REAL> vec, lat_vec;
	Matrix<REAL> A, L, R;

	A = B_curr.transpose();
	A.gauss(L, R, pmt);

	while (sieve_set.elements < sieve_set.elements_max) {

		vec.resize(N);
		vec.clear();

		for (j=1; j<=N; j++) {

			if (rand_eq_long(0, 1))
				vec[j] = check_lbnd[j];
			else
				vec[j] = check_ubnd[j];
		}

		if (vec.is_zero()) {

			for (j=1; j<=N; j++) {
				if (rand_eq_long(0, 1))
					vec[j] = -1;
				else
					vec[j] = 1;
			}
		}

		babai(L, R, pmt, vec, lat_vec);

		if (SCALE)
			sieve_set.insert(lat_vec / scale_vector);
		else
			sieve_set.insert(lat_vec);
	}
}

template <typename REAL>
void Lattice<REAL>::sieve(register double gamma) 
{
	register long i;
	REAL abw, min, R;

	Vector<REAL> d_vec;
	Set<Vector<REAL> > c_set, s_set2;
	Element<Vector<REAL> > *v_element, *c_element, *best_element;

	if (best_heu_norm != 0)
		sieve_set.insert(best_heu); 

	for (i=1; i<=M; i++) { 
		if (!B_curr[i].is_zero()) {

			if (SCALE)
				sieve_set.insert(B_curr[i] / scale_vector);
			else
				sieve_set.insert(B_curr[i]); 
		}
	}

	if (VERB >= 2) {
		cerr << "-> Sieving (" << sieve_set.elements;

		if (sieve_set.elements_max > 0)
			cerr << " + " << sieve_set.elements_max - sieve_set.elements;
		
		cerr << ") vectors ..." << endl; 
	}

	if (sieve_set.elements < sieve_set.elements_max) 
		fill_sieve();
	
	c_set.elements_max  = sieve_set.elements_max;
	s_set2.elements_max = sieve_set.elements_max;

	while (1) {

		R = 0;
		
		v_element = sieve_set.first_element;

		while (v_element != 0) {
			R = FMAX(R, (this->*abw_fptr)(v_element->content));
			v_element = v_element->next_element;
		}

		c_set.clear();
		s_set2.clear();
		
		//cerr << "sieve_set = " << sieve_set << endl;

		v_element = sieve_set.first_element;

		while (v_element != 0) {

			//cerr << "c_set = " << c_set << endl;

			if ((this->*abw_fptr)(v_element->content) <= gamma*R) {
				s_set2.insert(v_element->content);

			} else {

				c_element = c_set.first_element;

				while (c_element != 0) {
					d_vec = v_element->content - c_element->content;

					if (d_vec.is_zero())
						continue;

					abw = (this->*abw_fptr)(d_vec);

					if (abw <= gamma*R) {
						s_set2.insert(d_vec);
						break;
					}

					c_element = c_element->next_element;
				}

				if (c_element == 0)
					c_set.insert(v_element->content);
			}

			v_element = v_element->next_element;
		}

		if (s_set2.elements == 0) 
			break;
			
		sieve_set = s_set2;
	} 

	v_element = sieve_set.first_element;
	
	best_element = v_element;
	min = (this->*abw_fptr)(best_element->content);

	while (v_element != 0) {
		abw = (this->*abw_fptr)(v_element->content);
		if (abw < min)
			best_element = v_element;

		v_element = v_element->next_element;
	}

	check_solution(best_element->content);
}


/*******************************************************/
/*       The default deviation function computes       */
/* the euclidean distance between the submitted vector */
/*      and the midpoint of the two bound vectors.     */
/*******************************************************/

template <typename REAL>
REAL Lattice<REAL>::def_chk_abw(Vector<REAL> const &vec) 
{
	Vector <REAL> mid, tmp;
	
	mid = (check_ubnd - check_lbnd) / 2;
	tmp = vec - mid;

	if (SCALE)
		tmp /= scale_vector;
	
	return tmp.quad_euklid_norm();
}


/*********************************************/
/* Calculate how often a vector violates the */
/*    solution vector bound constraints.     */
/*********************************************/

template <typename REAL>
REAL Lattice<REAL>::anz_chk_abw(Vector<REAL> const &vec) 
{
	bool valid; 
	register long j;
	REAL anz_abw;
	
	anz_abw = 0;

	for (j=1; j<=N; j++) {
		if ((check_anz0[j] == -1) && (vec[j] == 0))
			valid = false;
		else
			valid = (check_lbnd[j] <= vec[j] && vec[j] <= check_ubnd[j]);

		if (!valid) 
			anz_abw++;
	}

	return anz_abw;
}


/**************************************************/
/* Compute the deviation for the vector component */
/* which violates the constration bounds at most. */
/**************************************************/

template <typename REAL>
REAL Lattice<REAL>::max_chk_abw(Vector<REAL> const &vec) 
{
	register long j;
	REAL curr_abw, max_abw;

	max_abw = 0;

	for (j=1; j<=N; j++) {
		curr_abw = FMAX(check_lbnd[j] - vec[j], vec[j] - check_ubnd[j]);
		
		if (curr_abw <= 0) {
			if (vec[j] == 0 && check_anz0[j] == -1)
				curr_abw = 1;

		} else if (SCALE)
			curr_abw /= scale_vector[j];

		if (curr_abw > max_abw) 
			max_abw = curr_abw;
	}

	return max_abw;
}


/**************************************************/
/* Sums up the deviation of each vector component */
/**************************************************/

template <typename REAL>
REAL Lattice<REAL>::all_chk_abw(Vector<REAL> const &vec) 
{
	register long j;
	REAL abw, dist;

	abw = 0;

	for (j=1; j<=N; j++) {
		dist = FMAX(check_lbnd[j] - vec[j], vec[j] - check_ubnd[j]);

		if (dist <= 0) {
			if (vec[j] == 0 && check_anz0[j] == -1)
				abw++;

		} else {

			if (SCALE)
				dist /= scale_vector[j];

			abw += dist;
		}
	}

	return abw;
}

/*
	A wrapper function for the basis-
	method which follows afterwards.
*/
template <typename REAL>
void Lattice<REAL>::basis_extend(Vector<REAL> &uu,
		register long jj, register long kk)
{
	register long i, s = 0;

	// Test if this is a (non-)trivial basis extension

	for (i = jj+1; i <= kk; i++) { 

		if (uu[i] != 0) {
			if (s == 0)
				s = i;
			else
				s = -i;
		}
	}

	if (s == 0) {

		// Normally this case should never occur, but if it does 
		// we make sure that no linear dependencies have evolved
		
		if (rang() != M) {
			ERROR("rank is too small!");
		}

	} else if (s > 0) {

		for (i = s; i > jj; i--) 
			swap(i-1, i);

		triv_sub++;

	} else {
		basis(uu, jj, kk);
		ntriv_sub++;
	}
}

/*
	This function implements Hoerner's BASIS algorithm. 
	The vector B_curr*u is inserted as j-th base vector.
	The old vectors b_j,b_(j+1), ..., b_k are modified
	in a way that they don't loose their base character.
*/
template <typename REAL>
void Lattice<REAL>::basis(Vector<REAL> &uu, 
		register long jj, register long kk)
{
	register long i, k;
	REAL tmp, q;

	B_curr[0].resize(N);
	B_curr[0].clear();

	for (i = jj; i <= kk; i++) {
		if (uu[i] == 0) 
			continue;

		B_curr[0] += B_curr[i]*uu[i];
	}
	
	if (B_curr[0].is_zero())
		ERROR("basis can't insert the zero vector!");
	
	b[0] = B_curr[0].quad_euklid_norm();

	check_solution(0); 

	if (TRANS) {
		T[0].resize(T.M);
		T[0].clear();

		for (i = jj; i <= kk; i++) {
			if (uu[i] == 0) 
				continue;
			T[0] += T[i]*uu[i];
		}
	}

	//// ANFANG des Algorithmus BASIS ////

	k = kk;
	while (uu[k] == 0)
		k--;

	// Es muss gelten:
	// 	ggT(uu[jj], uu[jj+1], ..., uu[k]) = 1
	//
	// vgl. Hoerner Diplomarbeit
	
	tmp = uu[k];
	for (i=k-1; i>=jj; i--)
		if (uu[i] != 0)
			tmp = ggT(tmp, uu[i]);

	if (tmp != 1) {

		if (VERB == 3)
			WARNING("ggT != 1 : ggt = " << tmp);

		uu = uu / tmp;
	}
		 
	i = k - 1;

	while (ABS(uu[k]) > 1) {
		while (uu[i] == 0 && i > jj)  
			i--;

		if (uu[i] == 0) {
			uu.print_subvector(jj, kk);
			ERROR("basis can't divide by zero!");
		}
		
		q = ROUND(uu[k] / uu[i]);

		tmp = uu[i];
		uu[i] = uu[k] - q*uu[i];
		uu[k] = tmp;

		swap(k, i);

		B_curr[k] += B_curr[i]*q;

		if (TRANS) 
			T[k] += T[i]*q;
	}

	for (i=k; i>=jj+1; i--) 
		swap(i, i-1);

	swap(jj, 0);
}

template <typename REAL>
void Lattice<REAL>::scale(register long j, bool max)
{
	register long i;
	REAL t, tt;

	if (j < 1 || j > scale_vector.N)
		ERROR("scale index out of range!");

	t = tt = scale_vector[j];

	if (max)
		tt += SCALE;
	else
		tt -= SCALE;
	
	if (tt <= 0)
		tt = 1;

	for (i=1; i<=B_curr.M; i++) {
		B_curr[i][j] /= t;
		B_curr[i][j] *= tt;
	}

	check_lbnd[j] /= t;
	check_lbnd[j] *= tt;

	check_ubnd[j] /= t;
	check_ubnd[j] *= tt;

	scale_vector[j] = tt;
}
	
template <typename REAL>
void Lattice<REAL>::scale(void)
{
	register long i, j;
	register long min_idx, max_idx;

	REAL min_z, max_z;

	Vector<REAL> zeroes;

	if (VERB >= 2) 
		cerr << "-> Scaling routine ..." << endl;

	zeroes.resize(N);
	zeroes.clear();

	for (i=1; i<=M; i++) 
		for (j=1; j<=N; j++) 
			if (B_curr[i][j] == 0)
				zeroes[j]++;

	min_idx = max_idx = 1;
	min_z = max_z = zeroes[1];

	for (j=2; j<=N; j++) {
		if (zeroes[j] >= max_z && rand_eq_long(0, 1)) {
			max_idx = j;
			max_z = zeroes[j];
		}

		if (zeroes[j] <= min_z && rand_eq_long(0, 1)) {
			min_idx = j;
			min_z = zeroes[j];
		}
	}
	
	scale(max_idx, true); 
	scale(min_idx, false);
}

template <typename REAL>
void Lattice<REAL>::reduce_loop(void)
{
	register long cnt;

	iters = 0;

	while (1) {

		if (VERB >= 2)
			cerr << endl;

		do pair_reduce(); 
		while (best_heu_insert()); 
		
		variate();
		bkz(DELTA, BETA);
		check_trans();

		if (GSA) {

			register long k, m;

			k = rand_eq_long(1, M-1);
			m = rand_eq_long(k+1, M);

			cnt = 0; 

			while (exshort_sr(k, m, DELTA, GSA, PRJ) 
					&& cnt++ <= 100) {

				bkz(DELTA, BETA);
				check_trans();
			}
		}
		
		if (SIEVE != -1) 
			sieve(DELTA);

		if (SCALE) 
			scale();

		print_stats();

		if (VERB) {
			cerr << endl;
			cerr << "Total iterations: " << ++iters << endl;
			cerr << "Total running time: ";

			print_time(cerr, (time(NULL) - create_time));

			cerr << endl;
		}
	}
}

/*
	The task of this routine is to locate a base vector B_curr[m], 
	such that its last component is minimal and non-zero. 
	If the vector is not unique, choose the one, for which m gets maximal.
*/
/*
template <typename REAL>
void Lattice<REAL>::inhomogenous_index(register long k, long &m)
{
	register long i;
	REAL curr, min;

	min = 0;
	
	for (i=m; i>=k; i--) {

		curr = B_curr[i][N];

		if (curr != 0 && (min == 0 || curr < min)) {
			min = curr;
			m = i;
		}
	}
}

template <typename REAL>
void Lattice<REAL>::extract_inhomogenous_part(void) 
{
	bool done;
	register long i, j;

	long VERB_OLD, SCALE_OLD;
	REAL scale_vector_last;

	SCALE_OLD = SCALE;
	scale_vector_last = scale_vector[N];
	VERB_OLD = VERB;

	SCALE = N;
	VERB = 0;

	while (true) {

		done = true;

		for (i=1; i<=M; i++) 
			if (i < M && B_curr[i][N] != 0) 
				done = false;

		if (done)
			break;

		scale(N, true);
		bkz(0.99, 20);
	}

	if (SCALE_OLD) {
		SCALE = SCALE_OLD;

		for (i=1; i<=M; i++) {
			B_curr[i][N] /= scale_vector[N];
			B_curr[i][N] *= scale_vector_last;
		}

		check_lbnd[N] /= scale_vector[N];
		check_lbnd[N] *= scale_vector_last;
		
		check_ubnd[N] /= scale_vector[N];
		check_ubnd[N] *= scale_vector_last;

		scale_vector[N] = scale_vector_last;

	 } else {

		for (i=1; i<=M; i++)
			B_curr[i] /= scale_vector;

		check_lbnd /= scale_vector;
		check_ubnd /= scale_vector;
		
		for (j=1; j<=N; j++)
			scale_vector[j] = TO_REAL(1);

		SCALE = 0;
	}

	VERB = VERB_OLD;

	cerr << "extracted: " << B_curr[M] << endl;
}
*/
#if 0
/* 
	This function computes det(R_v,k) for all v = 0,1,...,m-k 
	and chooses in dependence of the boolean parameter max a random index 
	which either maximizes r_v+1,v+1 / det(R_v,k)^(1/k) or
	minimizes r_v+k,v+k / det(R_v,k)^(1/k).
*/

/*
	This method pads a vector with zeroes 
	before the front and after the end.
*/
template <typename REAL>
void Lattice<REAL>::coord_extend(Vector <REAL> &coord_ex, 
		Vector <REAL> const &coord, register long start, register long end, 
		register long dim)
{
	register long j;

	if (start > end || end > dim)
		ERROR("coord_extend index error");

	coord_ex.resize(dim);
	for (j=1; j<start; j++)
		coord_ex[j] = 0;
	for (j=start; j<=end; j++)
		coord_ex[j] = coord[1+j-start];
	for (j=end+1; j<=dim; j++)
		coord_ex[j] = 0;
}

/*
 	Primal-Dual random sampling
*/
template <typename REAL>
bool Lattice<REAL>::pds(register long k, register long m, 
		register double delta, register long gsa)
{
	if (!gsa)
		return false;

	register long v, i, j;

	Vector<REAL> coord, coord_ex;
	Lattice<REAL> dual_lat;

	k = LMAX(3, k);

	if (k > m)
		return false;

	if (VERB >= 2) {
		cerr << "-> Primal-Dual Sampling ( k = " << k << ", m = ";
		cerr << m << " ) ..." << endl;
	}

	compute_lengths();
	
	// Primaler Fall

	// Randomly select the index v, which maximizes
	// 	r_v+1,v+1 / det(R_v,k)^(1/k)

	v = compute_minmax_block(k, m, true);

	if (v == -1) 
		return false;

	if (short_sr(v+1, v+k, delta, gsa)) {
		primal_cnt++;

		return true;
	}

	// Dualer Fall

	// Randomly select the index v, which minimizes 
	// 	r_v+k,v+k / det(R_v,k)^(1/k)

	v = compute_minmax_block(k, m, false);

	if (v == -1) 
		return false;

	compute_bstar(dual_lat);
/*
/////////////////////////////////////////////////

	Matrix<REAL> R, R_inv;
	Lattice<REAL> dual_lat;

	R.resize(M, M);

	for (i=1; i<=M; i++)
		for (j=1; j<=M; j++)
			R[i][j] = (mu[j][i] * SQRT(c[i]));

	R_inv = R.inverse(true, true);
	//gnf_lat.B = R_inv;
	
	/////////////////////////////////////////////////
*/	

#ifdef REVERSED
 	j = m / 2;
	for (i=1; i<=j; i++)
		dual_lat.swap(i, m-i+1);
#endif

	for (i=1; i<=k; i++)
		dual_lat.swap(i, v+i);
	
	dual_lat.resize(k);
	dual_lat.compute_lengths();

	if (dual_lat.short_sr(coord, 1, k, delta, gsa)) {
      coord_extend(coord_ex, coord, v+1, v+k, m);
		basis_replace_dual(coord_ex, v+1, v+k);
		dual_cnt++;

		return true;
	} 

	return false;
}
#endif

/*
	The input / read operator
*/
template <typename REAL_FRIEND>
istream& operator>> (istream &i, Lattice<REAL_FRIEND> &ref) 
{
	REAL tmp_scalar;
	Vector<REAL> tmp_vec;

	// The lattice is read 
	// from the input stream

	i >> ref.B;

	ref.B_curr = ref.B;

	ref.T.make_one(ref.B.M);

	if (ref.B.M != ref.B_curr.M || ref.B.N != ref.B_curr.N)
		ERROR("lattice dimensions are incorrect");
		
	if (ref.B.M != ref.T.M || ref.T.M != ref.T.N) 
		ERROR("transformation matrix dimensions are incorrect");

	ref.resize(ref.B.M, ref.B.N);

	// The check vectors are read 
	// from the input stream
	 
	i >> ref.check_lbnd;
	i >> ref.check_ubnd;
	i >> ref.check_anz0;

	i >> tmp_vec;

	i >> tmp_scalar;
	i >> tmp_scalar;
	i >> tmp_scalar;

	// The amount of slk-variables
	// is read from the input stream

	i >> ref.slks;

	if (ref.check_lbnd.N != ref.N 
			|| ref.check_lbnd.N != ref.check_ubnd.N
				|| ref.check_lbnd.N != ref.check_anz0.N)

		ERROR("check vector dimensions are incorrect");

	return i;
}

/*
	The output / write operator
*/
template <typename REAL_FRIEND>
ostream& operator<< (ostream &o, 
		Lattice<REAL_FRIEND> const &ref) 
{
	o << ref.B_curr << endl;
	o << ref.T << endl;
	o << ref.B << endl; 

	return o;
}

