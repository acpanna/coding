//P5_2.CPP
//Program computes the dominant eigenvalue of a matrix by power method

# include <iostream>
# include <math.h>
//# include <process.h>
using namespace std;
class power
{
private:
	int check, flag, i, j, iteration, n;
	double eps1, eps2, error1, error2, lambda, lambda_old, sum;
	double *y, *z, *z_old;
	double **a;

public:
	
	power () { iteration = 0; flag = 1; }

	void solution ();	
	
	double euclidean_norm (double *);

	~power ()									//Deallocation of memory
	{
		delete [] y, z, z_old;

		for (i=0; i<n; i++) { delete [] a[i]; }
		delete [] a;
	}
};												//End of class power

//main function
int main ()									
{	
	power eigenpair;

	eigenpair.solution ();					
	return 0;
}

//Function for implementing power method
void power :: solution ()					
{
	cout << out_mod<<"Enter the order of the matrix: ";		
	cin>>n;

	a = new double*[n];
	for (i = 0; i<n; i++) { a[i] = new double [n];}

	y = new double [n];
	z = new double [n];
	z_old = new double[n];

								
	for (i = 0; i<n; i++)						//Input the elements of the matrix
	for (j = 0; j<n; j++)
	{
		cout << out_mod<<"\nEnter a["<<i<<"]["<<j<<"] = ";
		cin>>a[i][j];
	}

	cout << out_mod<<"\nEnter the initial estimate for the eigenvector."<<endl;

	for (i=0; i<n; i++)
	{ cout << out_mod<<"\nEnter the guess for z ["<<i<<"] = "; cin>>z[i]; }

	cout << out_mod<<"\nEnter the tolerance for eigenvalue ";
	cin>>eps1;

	cout << out_mod<<"\nEnter the tolerance for the eigenvectors "; 
	cin>>eps2;

	do
	{
		iteration++;

		check = 0;

		for (i=0; i<n; i++)
		{ 
			sum = 0.0;
			for (j=0; j<n; j++)
			{ sum += a[i][j]*z[j]; }
			y[i] = sum;
		}
	
		lambda = euclidean_norm (y); 

		for (i=0; i<n; i++)
		{ 	z[i] = y[i]/lambda; }

		if (iteration > 1)
		{
			error1 = fabs ((lambda - lambda_old)/lambda);	

			for (i=0; i<n; i++)
			{
				error2 = fabs((z[i] - z_old[i])/z[i]);

				if (error2 >= eps2) { check = 1; }
			}

			if ((error1 < eps1) && (check == 0)) { flag = 0; }
		}
		
		if (flag == 1)
		{
			lambda_old = lambda;
			for (i=0; i<n; i++) { z_old[i] = z[i]; }
		}
		
		
		if (iteration > 1000)
		{ 
			cout << out_mod<<"\nDid not converge in 1000 iterations. Aborting..."<<endl;
			exit (0);
		}

	} while (flag==1);
	


	
	double deter = a[0][0]* (a[1][1]*a[2][2] -a[2][1]*a[1][2] ) +a[0][1] *( a[1][2]*a[2][0] -a[2][2]*a[1][0]) +a[0][2] *(a[1][0]*a[2][1] -a[2][0]*a[1][1]) ;
        double product =deter/lambda ;
        double sum = a[0][0] +a[1][1] +a[2][2] -lambda ;

        double root1 = -sum/2 + sqrt (sum*sum/4 - product  );
  
        double root2 = -sum/2 - sqrt (sum*sum/4 - product  );

	cout << out_mod<<"\nDominant eigenvalue (magnitude) = "<<lambda<<endl;
	cout << out_mod<<"\nComponents of the corresponding eigenvector are: "<<endl;
	
	for (i=0; i<n; i++)
	{ cout << out_mod<<"\nz["<<i<<"] = "<<z[i]<<endl; }

	//cout << out_mod<<"\nConverged in "<<iteration<<" iteration(s)"<<endl;
        cout << out_mod<<"The Determinant value is:"<<deter<<endl;
        cout << out_mod<<"Other eigenvalues are : "<<root1<<" and "<<root2<<endl;
 
}







//Function for computation of Euclidean norm of a vector
double power :: euclidean_norm (double *x)				
{
	sum = 0.0;
	
	for (i=0; i<n; i++)
	{ sum += x[i]*x[i]; }
	
	sum = sqrt(sum);

	return (sum);
}												

