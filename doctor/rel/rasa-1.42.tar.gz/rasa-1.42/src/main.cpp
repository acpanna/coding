#include "globals.h"
#include "lattice.h"

#include "tcp.h" 

#include <pthread.h>
#include <signal.h>
#include <iomanip>
#include <fstream> 
#include <sstream> 
#include <sys/types.h>
#include <unistd.h>
#include <libgen.h>
#include <time.h>

#include "release.h"


void usage(void);
void* timer(void *arg);

void read_params(int argc, char **argv);
void set_param_str(std::ostringstream &oss);

bool read_lattice(void); 

void exit_handler(int sig);

void re_exec_prg(void);
void kill_it(void);


char param[19][1024];

string input_file = "";
string map_file = "";

unsigned int seed = 0;

bool trans = true;

double alpha = 0.5;
double delta = 0.99;

long beta = 20;
long deep = 0;

long btime = 0;
long rtime = 0;

long gsa = 0;
long slimit = 20000;
bool prj = false;

long nprune = 0;
long eprune = 0;

long scale = 0;
long sieve = -1; 

long heu = 0;

long verb = 0;

pthread_t server_thread = 0;
pthread_t time_thread = 0;

pid_t pid;

string prg = "";

Lattice<REAL> lat;
	
Matrix<REAL> A, B;
Matrix<REAL> L, R;
	
Vector<long> pmt;

char star_line[] = "**************************************************************************";

using namespace std;

int main(int argc, char **argv)
{
	struct sigaction exit_action;
	register long i, rank;

	cerr << "RASA v" << string(RELEASE) << " ";
	cerr << "-- (c) Copyright by Heiko Vogel" << endl;
	cerr << endl;

	read_params(argc, argv);
	
	if (!read_lattice())
		return 1;

	seed = 17101978; // FIX

	if (seed)
		new_seed(seed);
	else  
		seed = new_seed();
	
	exit_action.sa_handler = exit_handler;
	sigfillset(&exit_action.sa_mask);
	exit_action.sa_flags = 0;

	sigaction(SIGINT, &exit_action, NULL);
	sigaction(SIGTERM, &exit_action, NULL);
	sigaction(SIGUSR1, &exit_action, NULL);
	
	/***********************************************************/
	/*        Falls der Parameter "rtime" gesetzt wurde,       */
	/*  starte einen Thread, der das Programm beendet, sobald  */
	/*    die vorgegebene Laufzeit in Sekunden erreicht ist.   */
	/***********************************************************/
	
	if (rtime) 
		pthread_create(&time_thread, NULL, timer, (void *) rtime);
	
	/***********************************************************/
	
	cerr << "[ PID = " << pid << " | ";

	A = lat.B_curr.transpose();

	cerr << "M = " << lat.M << ", N = " << lat.N << ", ";
	cerr << "rank = ";

	rank = A.gauss(L, R, pmt);

	cerr << rank << " ]" << endl;
	
	if (rank < lat.M)
		ERROR("The lattice rank is too small!");

	ostringstream oss;
	set_param_str(oss);

	lat.params = oss.str();
	
	if (verb) {
		cerr << endl;
		cerr << "The following parameters are set:" << endl;
		cerr << endl;

		cerr << oss.str() << endl;
		cerr << endl;
	}
	
	/***************************************************************************/

	lat.init_params(verb, btime, trans, alpha, delta, beta, deep, nprune, eprune,
			scale, sieve, gsa, prj, slimit, heu);

	i=2;

	do {
		lat.bkz(delta, i);
		lat.check_trans();
	} while (++i <= beta);
	
	lat.reduce_loop();

	/***************************************************************************/

	return 0;
}

void usage(void) 
{
	cerr << "Usage: " << prg << " [options] *.lat" << endl;
	cerr << endl;
	cerr << "The available options are:" << endl;

	ostringstream oss;
	set_param_str(oss);

	cerr << endl;
	cerr << oss.str();
	cerr << endl;
	
	exit(1);
}

void* timer(void *arg) 
{ 
	time_t start, curr, duration;

	time(&start);
	duration = (long) arg;
	
	while (true) {

		time(&curr);

		if (curr - start >= duration) {
			send_signal(15);
			return NULL;
		}

		sleep(10);
	}
	
	return NULL;
}

void read_params(int argc, char **argv)
{
	register long i;
	string buff = "";

	prg = argv[0];
	
	prec = PRECISION;

	if (argc <= 1)
		usage();

	for (i=1; i<argc; i++) {
	
		if (strncmp(argv[i], "--help", 6) == 0 || strncmp(argv[i], "-h", 2) == 0)
			usage();

		else if (strncmp(argv[i], "--server", 8) == 0) 
			pthread_create(&server_thread, NULL, tcp_server, (void *) 0); // NEW

		else if (strncmp(argv[i], "--trans=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> trans;
		} else if (strncmp(argv[i], "--alpha=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> alpha;
		} else if (strncmp(argv[i], "--delta=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> delta;
		} else if (strncmp(argv[i], "--beta=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> beta;
		} else if (strncmp(argv[i], "--deep=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> deep;
		} else if (strncmp(argv[i], "--heu=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> heu;
		} else if (strncmp(argv[i], "--verb=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> verb;
		} else if (strncmp(argv[i], "--scale=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> scale;
		} else if (strncmp(argv[i], "--nprune=", 9) == 0) {
			buff = argv[i]+9;
			istringstream iss(buff);
			iss >> nprune;
		} else if (strncmp(argv[i], "--eprune=", 9) == 0) {
			buff = argv[i]+9;
			istringstream iss(buff);
			iss >> eprune;
		} else if (strncmp(argv[i], "--prj=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> prj;
		} else if (strncmp(argv[i], "--sieve=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> sieve;
		} else if (strncmp(argv[i], "--gsa=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> gsa;
		} else if (strncmp(argv[i], "--slimit=", 9) == 0) {
			buff = argv[i]+9;
			istringstream iss(buff);
			iss >> slimit;
		} else if (strncmp(argv[i], "--map=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> map_file;
		} else if (strncmp(argv[i], "--btime=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> btime;
		} else if (strncmp(argv[i], "--rtime=", 8) == 0) {
			buff = argv[i]+8;
			istringstream iss(buff);
			iss >> rtime;
		} else if (strncmp(argv[i], "--slk=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> slk;
		} else if (strncmp(argv[i], "--sol=", 6) == 0) {
			buff = argv[i]+6;
			istringstream iss(buff);
			iss >> sol;
		} else if (strncmp(argv[i], "--seed=", 7) == 0) {
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> seed;
		} else if (strncmp(argv[i], "--prec=", 7) == 0) {
#ifdef INF_DTYPE
			buff = argv[i]+7;
			istringstream iss(buff);
			iss >> prec;
#else
			if (prec != PRECISION && strstr(argv[0], "rasa-rr"))
				ERROR("Run rasa-rr, if you want to use the prec parameter!");
#endif
		} else if (strncmp(argv[i], "-", 1) == 0) {
			usage();
		} else 
			input_file = argv[i];
	}

#ifdef INF_DTYPE
	NTL::RR::SetPrecision(prec);
	prec = NTL::RR::precision();

	if (prec < PRECISION)
		ERROR("Please use a precision >= " << PRECISION);

	NTL::RR::SetOutputPrecision(EXT_OUT_PRECISION);
#endif
}

void set_param_str(std::ostringstream &oss) 
{
	std::ostringstream oss2;
	
	oss2.str("");
	oss.str("");

	oss2 << "--alpha=" << alpha;
	sprintf(param[0], "%s", oss2.str().c_str()); 
	oss << "[ " << oss2.str() << " ";
	oss2.str("");

	oss2 << "--delta=" << delta;
	sprintf(param[1], "%s", oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--beta=" << beta;
	strcat(param[2], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--heu=" << heu;
	strcat(param[3], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--gsa=" << gsa;
	strcat(param[4], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--slimit=" << slimit;
	strcat(param[5], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--prj=" << prj;
	strcat(param[6], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--nprune=" << nprune;
	strcat(param[7], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--eprune=" << eprune;
	strcat(param[8], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--seed=" << seed;
	strcat(param[9], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--sieve=" << sieve;
	strcat(param[10], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--scale=" << scale;
	strcat(param[11], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--deep=" << deep;
	strcat(param[12], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--trans=" << trans;
	strcat(param[13], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--btime=" << btime;
	strcat(param[14], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--rtime=" << rtime;
	strcat(param[15], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--slk=" << slk;
	strcat(param[16], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--sol=" << sol;
	strcat(param[17], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");
	
	oss2 << "--verb=" << verb;
	strcat(param[18], oss2.str().c_str()); 
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--prec=" << prec;
	oss << oss2.str() << " ";
	oss2.str("");

	oss2 << "--map=";

	if (map_file != "")
		oss2 << map_file;
	else
		oss2 << "*.map_* ]";

	oss << oss2.str();
}

bool read_lattice(void) 
{
	char *ptr;
	register long i;
	
	string file, map_params;
	stringstream ss;

	Vector<REAL> coord, vec;

	ifstream fin(input_file.c_str());
	if (!fin.good()) {
		cerr << ext_prec << "The file [ " << input_file << " ] can't be opened!";
		cerr << ext_prec << endl;
		return false;
	}

	fin >> lat;
	fin.close();

	pid = getpid();
	ss << pid;

	ptr = strstr((char *) input_file.c_str(), ".lat");

	if (ptr == NULL) 
		usage();

	file = input_file;
	file.erase(ptr - input_file.c_str());

	lat.nrm_file = file + string(".nrm_") + ss.str();
	lat.map_file = file + string(".map_") + ss.str();

	if (map_file != "") {
		
		fin.open(map_file.c_str());
		getline(fin, map_params);

		fin >> lat.B_curr;
		fin >> lat.TT;

		if (lat.TT.N != 0) {

			for (i=1; i<lat.TT.N; i++)
				lat.B = lat.TT[i] * lat.B;
			lat.T = lat.TT[lat.TT.N];

			if (lat.B_curr != lat.T * lat.B) 
				lat.TT.resize(0);
		}

		if (lat.TT.N == 0) {

			// If there is no valid transformation matrix, 
			// then it is (re-)computed right here ...
					
			A = lat.B.transpose();
			A.gauss(L, R, pmt);

			if (trans)
				lat.T.resize(lat.M, lat.M);

			for (i=1; i<=lat.M; i++)  {
				if (compute_coords(L, R, pmt, lat.B_curr[i], coord, true) != 1)
					ERROR("compute_coords -- matrix is not regular");

				if (A*coord != lat.B_curr[i])
					ERROR("Map Error: i = " << i);

				if (trans) 
					lat.T[i] = coord;
			}

			lat.check_trans();
		}

		if (read_vector(fin, vec)) 
			lat.check_best_heu(vec);

		if (read_vector(fin, vec)) 
			lat.check_best_slk(vec);

		while (read_vector(fin, vec)) 
			lat.check_solution(vec);

		fin.close();
	}

	return true;
}

void exit_handler(int sig)
{
	cerr << endl; 
	cerr << "Got signal: ";
	cerr << strsignal(sig);

	if (sig == SIGUSR1) 
		re_exec_prg();
	else 
		kill_it();
}

void re_exec_prg(void)
{ 
	char prec_param[1024], map_param[1024];

	sprintf(prec_param, "--prec=%ld", LMAX(prec, PRECISION));
	sprintf(map_param, "--map=%s", lat.map_file.c_str());

	cerr << "map = " << map_param << endl;
	cerr << "prec = " << prec_param << endl;

	if (access(map_param, R_OK) == 0) {
		execl("./rasa-rr", "rasa-rr", 
				param[0], param[1], param[2], param[3], param[4], param[5], 
				param[6], param[7], param[8], param[9], param[10], param[11], 
				param[12], param[13], param[14], param[15], param[16], param[17], 
				param[18], map_param, prec_param, input_file.c_str(), (char *)0);

	} else {
		execl("./rasa-rr", "rasa-rr", 
				param[0], param[1], param[2], param[3], param[4], param[5], 
				param[6], param[7], param[8], param[9], param[10], param[11], 
				param[12], param[13], param[14], param[15], param[16], param[17], 
				param[18], prec_param, input_file.c_str(), (char *)0);
	}

	// If the function returns unexpectedly, the multiprecision executable
	// could probably not be found, so we bail out with an error message.

	ERROR("Could not execute the multiprecision version of rasa!");
}

void kill_it(void) 
{
	cerr << endl;
	cerr << star_line;
	cerr << endl;

	lat.check_trans();

	/****************************************************/
	/*    	  The map-file is not saved here!          */
	/****************************************************/ 
	/* (This is done in check_trans, in order to ensure */ 
	/*    that the transformation is correct, before    */
	/*      anything gets written down)                 */
	/****************************************************/
	
	lat.print_sol();

	cerr << endl;
	cerr << "The following files contain the results: " << endl;
	cerr << endl;
	cerr << "\t" << lat.map_file << endl;
	cerr << "\t" << lat.nrm_file << endl;
	cerr << endl;
	
	cerr << "Total iterations: " << lat.iters << endl;
	cerr << "Total running time: ";
	print_time(cerr << ext_prec, time(NULL) - lat.create_time);
	cerr << " -- Program terminated" << endl;
	
	_exit(0);
	//kill(pid, 9);
}
