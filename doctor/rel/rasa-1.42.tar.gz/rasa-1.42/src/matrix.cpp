using namespace std;

template <typename DATATYPE>
Matrix<DATATYPE>::Matrix() : M(0), N(0), row(0)
{ }

template <typename DATATYPE>
Matrix<DATATYPE>::Matrix(register long m, register long n) : M(0), N(0), row(0)
{ 
	resize(m, n);
}

template <typename DATATYPE>
Matrix<DATATYPE>::Matrix(register long m, register long n, 
		DATATYPE const * const * const matrix) : M(0), N(0), row(0)
{
	if (m <= 0 || n <= 0)
		ERROR("Matrix: row/column dimension <= 0");

	register long i, j;

	resize(m, n);

	for (i=1; i<=m; i++) 
		for (j=1; j<=n; j++)
				row[i][j] = matrix[i][j]; 
}

template <typename DATATYPE>
Matrix<DATATYPE>::Matrix(Matrix<DATATYPE> const &ref) : M(0), N(0), row(0)
{ 
	*this = ref; 
}

template <typename DATATYPE>
Matrix<DATATYPE>::~Matrix() 
{ 
	if (row)
		delete [] row;

	row = 0;
	M = 0;
	N = 0;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & 
Matrix<DATATYPE>::operator= (Matrix<DATATYPE> const &ref)
{
	if (this == &ref)
		return *this;

	register long i;

	resize(ref.M, ref.N);
	for (i=1; i<=ref.M; i++) 
		row[i] = ref.row[i];

	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & 
Matrix<DATATYPE>::operator+=(Matrix<DATATYPE> const& ref)
{
	if (M != ref.M || N != ref.N)
		ERROR("Matrix: dimension mismatch1");

	register long i;

	for (i=1; i<=M; i++)
		row[i] += ref.row[i];
	
	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & 
Matrix<DATATYPE>::operator-=(Matrix<DATATYPE> const &ref)
{
	if (M != ref.M || N != ref.N)
		ERROR("Matrix: dimension mismatch2");

	register long i;

	for (i=1; i<=M; i++)
		row[i] -= ref.row[i];
	
	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & 
Matrix<DATATYPE>::operator*=(DATATYPE const &ref)
{
	register long i;

	for (i=1; i<=M; i++)
		row[i] *= ref;
	
	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & Matrix<DATATYPE>::operator*=(Matrix<DATATYPE> const &ref)
{
	if (N != ref.M)
		ERROR("Matrix: dimension mismatch3");

	*this = (*this) * ref;

	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE> const & Matrix<DATATYPE>::operator/=(DATATYPE const &ref)
{
	register long i;

	for (i=1; i<=M; i++)
		row[i] /= ref;
	
	return *this;
}

template <typename DATATYPE>
Matrix<DATATYPE>
Matrix<DATATYPE>::operator+(Matrix<DATATYPE> const &ref) const
{
	if (M != ref.M || N != ref.N)
		ERROR("Matrix: dimension mismatch4");

	register long i;

	Matrix ret(*this);
	for (i=1; i<=M; i++)
		ret.row[i] += ref.row[i];
	
	return ret;
}

template <typename DATATYPE>
Matrix<DATATYPE>
Matrix<DATATYPE>::operator-(Matrix<DATATYPE> const &ref) const
{
	if (M != ref.M || N != ref.N)
		ERROR("Matrix: dimension mismatch5");

	register long i;

	Matrix ret(*this);
	for (i=1; i<=M; i++)
		ret.row[i] -= ref.row[i];
	
	return ret;
}

template <typename DATATYPE>
Matrix<DATATYPE>
Matrix<DATATYPE>::operator*(DATATYPE const &ref) const
{
	register long i;

	Matrix ret(*this);
	for (i=1; i<=M; i++)
		ret.row[i] *= ref;
	
	return ret;
}

template <typename DATATYPE>
Matrix<DATATYPE> 
Matrix<DATATYPE>::operator*(Matrix<DATATYPE> const &ref) const
{
	if (N != ref.M)
		ERROR("Matrix: dimension mismatch6");

	register long i, j, k;
	
	Matrix ret(M, ref.N);
	for (i=1; i<=M; i++) {
		for (j=1; j<=ref.N; j++) {
			ret.row[i][j] = 0;
			for (k=1; k<=N; k++) 
				ret.row[i][j] += row[i][k] * ref[k][j];
		}
	}
	
   return ret;
}

template <typename DATATYPE>
Matrix<DATATYPE> 
Matrix<DATATYPE>::operator%(DATATYPE const &modul) const
{
	Matrix ret(M, N);
	register long i, j;

	for (i=1; i<=M; i++)
		for (j=1; j<=N; j++) 
			ret.row[i][j] = modulo(row[i][j], modul);
	
   return ret;
}

template <typename DATATYPE>
Vector<DATATYPE> 
Matrix<DATATYPE>::operator*(Vector<DATATYPE> const &ref) const
{
	if (N != ref.N)
		ERROR("Matrix: dimension mismatch7");

	register long i;

	Vector<DATATYPE> ret(M);
	for (i=1; i<=M; i++)
		ret[i] = row[i] * ref;
	
	return ret;
}

template <typename DATATYPE>
Vector<DATATYPE> & 
Matrix<DATATYPE>::operator[] (register long i) const
{ 
	return row[i]; 
}

template <typename DATATYPE>
bool 
Matrix<DATATYPE>::operator==(Matrix<DATATYPE> const& ref) const
{
	if (M != ref.M || N != ref.N)
		return false;
	
	register long i;

	for (i=1; i<=M; i++) 
		if (row[i] != ref.row[i])
			break;

	if (i > M) 
		return true;

	return false;
}

template <typename DATATYPE>
bool Matrix<DATATYPE>::operator!=(Matrix<DATATYPE> const& ref) const 
{
	return !((*this) == ref);
}

template <typename DATATYPE>
Matrix<DATATYPE> Matrix<DATATYPE>::transpose(void) const
{
	register long i, j;

	Matrix tmp(N, M);

	for (i=1; i<=M; i++)
		for (j=1; j<=N; j++)
			tmp.row[j][i] = row[i][j];

	return tmp;
}

template <typename DATATYPE>
Matrix<DATATYPE> Matrix<DATATYPE>::round(DATATYPE eps) const
{
	register long i, j;
	DATATYPE rnd;

	Matrix<DATATYPE> Ret;
	Ret.resize(M, N);

	if (eps == 0)
		eps = EPSILON;

	for (i=1; i<=M; i++) {
		for (j=1; j<=M; j++) {
			rnd = ROUND((*this)[i][j]);
			if (ABS(rnd - (*this)[i][j]) < eps)
				Ret[i][j] = rnd;
			else
				Ret[i][j] = (*this)[i][j];
		}
	}

	return Ret;
}

template <typename DATATYPE>
Matrix<DATATYPE> Matrix<DATATYPE>::inverse(bool triangular, bool upper) const
{
	if (M != N)
		ERROR("Matrix: dimension mismatch8");
	
	register long i, j;

	Matrix<DATATYPE> L, R, Inv;
	Vector<DATATYPE> e, coord;
	Vector<long> pmt;

	if (!triangular) {

		if (gauss(L, R, pmt) != M)
			ERROR("Matrix: Inversion failed -- rank < M");

	} else {

		if (upper) {
			R = (*this);
			L.make_one(M);
		} else {
			L = (*this);
			R.make_one(M);
		}

		pmt.resize(M);
		for (i=1; i<=M; i++)
			pmt[i] = i;
	}

	e.resize(M);
	e.clear();

	Inv.resize(M, M);

	for (j=1; j<=M; j++) {
		e[j-1] = 0;
		e[j] = 1;

		if (compute_coords(L, R, pmt, e, coord, true, false) != 1)
			ERROR("Inverse: the matrix is not Invertible!");

		for (i=1; i<=M; i++)
			Inv[i][j] = coord[i];
	}

	return Inv;
}

template <typename DATATYPE>
Matrix<DATATYPE> Matrix<DATATYPE>::rows(register long k, register long m) const
{
	register long i, j;

	Matrix ret(m-k+1, N);
	
	for (i=1; i<=ret.M; i++)
		for (j=1; j<=ret.N; j++)
			ret.row[i][j] = row[k-1+i][j];
	return ret;
}

template <typename DATATYPE>
Matrix<DATATYPE> Matrix<DATATYPE>::cols(register long l, register long n) const
{
	register long i, j;

	Matrix ret(M, n-l+1);
	
	for (i=1; i<=ret.M; i++)
		for (j=1; j<=ret.N; j++)
			ret.row[i][j] = row[i][l-1+j];
	return ret;
}

template <typename DATATYPE>
void Matrix<DATATYPE>::house(register long j, Vector<DATATYPE> &v, 
		DATATYPE &beta) 
{
	register long i;

	DATATYPE my, rho, x_1, v_square, v_1;

	x_1 = (*this)[j][j];
	
	v[j] = 1;
	rho = 0;

	for (i=j+1; i<=M; ++i) {
		rho += (*this)[i][j] * (*this)[i][j];
		v[i] = (*this)[i][j];
	}

	if (ABS(rho) < EPSILON*EPSILON) // rho == 0
		beta = 0;
	else {
		my = sqrt(x_1*x_1 + rho);

		if (x_1 <= 0)
			v[j] = x_1 - my;
		else
			v[j] = -rho/(x_1 + my);
		v_1 = v[j];

		v_square = v_1*v_1;
		beta = 2 * v_square/(rho + v_square);

		for (i=j; i<=M; i++)
			v[i] /= v_1;
	}
}

template <typename DATATYPE>
void Matrix<DATATYPE>::qr(Matrix<DATATYPE> &Q, Matrix<DATATYPE> &R) const
{
	if (M < N)
		ERROR("Matrix: The case M < N is not implemented");

	register long i, j, k, jj;
	DATATYPE bmt;

	Vector<DATATYPE> beta;
	Vector<DATATYPE> t;
	Vector<DATATYPE> v;
	
	Matrix<DATATYPE> A;
	
	A = *this;

	Q.resize(M, N);
	R.resize(N, N);

	beta.resize(N);

	t.resize(N);
	v.resize(M);

	for (j=1; j<=N; j++) {
		A.house(j, v, beta[j]);

		for(i=j; i<=N; i++) {
			t[i] = 0;
			for(jj=j; jj<=M; jj++) 
				t[i] += v[jj] * A[jj][i];
		}

		for(i=j; i<=N; i++) {
			bmt = beta[j] * t[i];
			for(jj=j; jj<=M; jj++) 
				A[jj][i] -= bmt*v[jj];
		}

		if (j <= M)
			for(jj=j+1; jj<=M; jj++)
				A[jj][j] = v[jj];
	}

	for (i=1; i<=M; i++) 
		for (j=1; j<=N; j++) {
			if (j == i)
				Q[i][j] = 1;
			else
				Q[i][j] = 0;
		}

	for (k=N; k>=1; k--) {
		for (i=k; i<=N; i++) {
			t[i] = 0;
			for (j=k; j<=M; j++) {
				if (j == k)
					t[i] += Q[j][i];
				else
					t[i] += (A[j][k] * Q[j][i]);
			}
		}

		for (i=k; i<=N; i++) {
			bmt = beta[k] * t[i];
			for (j=k; j<=M; j++) {
				if (j == k)				
					Q[j][i] -= bmt;
				else
					Q[j][i] -= (bmt * A[j][k]);
			}
		}
	}

	for (i=1; i<=M; i++) 
		for (j=1; j<=N; j++) 
			if (i <= j) 
				R[i][j] = A[i][j];
}

template <typename DATATYPE>
long Matrix<DATATYPE>::gauss(Matrix<DATATYPE> &L, Matrix<DATATYPE> &R, 
		Vector<long> &pmt) const
{
	DATATYPE max;
	register long i, j, k, z, zz, rang, min_dim, max_dim;

	z = 0;
	
	min_dim = LMIN(M, N);
	max_dim = LMAX(M, N);
	
	rang = min_dim;

	L.resize(M, N);
	for (i=1; i<=M; i++)
		for (j=1; j<=N; j++)
			L[i][j] = (*this)[i][j];
		
	R.resize(N, N);
	R.clear();

	pmt.resize(max_dim);
	for (j=1; j<=max_dim; j++)
		pmt[j] = j;

	for (j=1; j<=N; j++) {
		max = 0;
		for (i=j; i<=M; i++) {
			if (ABS(L[i][j]) > ABS(max)) {
				max = L[i][j];
				z = i;
			}
		}

		if (ABS(max) < EPSILON) { // max == 0
			rang--;
			continue;
		}

		if (z != j) {
			L.swap(z, j);

			zz = pmt[z];
			pmt[z] = pmt[j];
			pmt[j] = zz;
		}

		for (k=j+1; k<=M; k++) {		
			L[k][j] = (L[k][j] / max);     
			for (i=j+1; i<=N; i++)
				L[k][i] = L[k][i] - (L[k][j] * L[j][i]); 
		}
	}
		
	for (i=1; i<=M; i++) {
		for (j=1; j<=N; j++) 
			if (i <= j && i <= N) {
				R[i][j] = L[i][j];
				L[i][j] = 0;
			} 

		if (i <= N)
			L[i][i] = 1;
	}

	return rang;
}

template <typename REAL>
ZZ Matrix<REAL>::modular_determinant(void)
{
	register long i, j;

	if (M != N)
		ERROR("Matrix: determinant for a non-quadratic matrix is not defined");

	ZZ **mat;

	mat = new ZZ*[this->M];
	ASSERT(mat);

	for (i=0; i<this->M; i++) {
		mat[i] = new ZZ[this->M];
		ASSERT(mat[i]);
	}

	for (i=0; i<this->M; i++) {
		for (j=0; j<this->M; j++) {
#ifdef FIN_DTYPE
			mat[i][j] = (*this)[i+1][j+1];
#else
			mat[i][j] = TO_LONG((*this)[i+1][j+1]);
#endif
		}
	}

	ZZ det_zz = ABS(modular_determinant(mat, this->M));

	for (i=0; i<this->M; i++) 
		delete [] mat[i];
	delete [] mat;

	return det_zz;
}

/*
	Wird vor den Aufruf des eigentlichen Simplex-Algorithmus geschaltet, 
 	um Ungleichungen der Form A*x<=b in Gleichungen zu verwandeln 
	(durch Einfuehrung von Schlupfvariablen). 
	
	Ausserdem wird hierdurch zusaetzlich erreicht, 
	dass rang A = #Zeilen von A
*/
template <typename DATATYPE>
void Matrix<DATATYPE>::simplex(Vector<DATATYPE> const &b,
	Vector<DATATYPE> const &c, Vector<DATATYPE> &x) const
{
	register long i, j;  

	Matrix<DATATYPE> AA;
	Vector<DATATYPE> bb, cc, xx;

	AA.resize(M, M+N);

	bb.resize(M);
	cc.resize(M+N);
	xx.resize(M+N);

	for (i=1; i<=M; i++) {
		AA[i][i+N] = 1;
		for (j=1; j<=N; j++)
			AA[i][j] = (*this)[i][j];
		bb[i] = b[i];
	}

	for (j=1; j<=N; j++)
		cc[j] = c[j]; 
	for (j=N+1; j<=M+N; j++)
		cc[j] = 0;

	AA.simplex_with_equations(bb, cc, xx);

	for (j=1; j<=N; j++)
		x[j] = xx[j];
}

/*
	Eigentlicher Simplex-Algorithmus, der Probleme der folgenden Form loest: 
		Minimiere c'x unter den Nebenbedingungen A*x=b, 
			x>=0 und rang A = #Zeilen von A
*/
template <typename DATATYPE>
void Matrix<DATATYPE>::simplex_with_equations(Vector<DATATYPE> const &b,
	Vector<DATATYPE> const &c, Vector<DATATYPE> &x) const
{
	register long i, j;

	Matrix<DATATYPE> AA;
	Vector<DATATYPE> cc, xx;

	AA.resize(M, M+N);
	cc.resize(M+N);
	xx.resize(M+N);

	////////// Beginn Phase I //////////

	// Mache alle b[i] >= 0	
	
	for (i=1; i<=M; i++) {
		for(j=1; j<=N; j++) {
			if (b[i] < 0)
				AA[i][j] = -(*this)[i][j];
			else
				AA[i][j] = (*this)[i][j];
		}
	}

	// Erweiterung der Ausgangsmatrix mit m-ter Einheitsmatrix
	 
	for (i=1; i<=M; i++) {
		for (j=N+1; j<=M+N; j++) {
			if ((j-N) == i)
				AA[i][j] = 1;
			else
				AA[i][j] = 0;
		}
	}

	// Bilde den Kostenvektor cc fuer Phase I 
	// und belege xx mit gueltiger Basisloesung
	 
	for (i=1; i<=M+N; i++) {
		if (i <= N) {
			cc[i] = 0;
			xx[i] = 0;
		} else {
			cc[i] = 1;
			if (b[i-N] < 0)
				xx[i] = -b[i-N];
			else
				xx[i] = b[i-N];
		}
	}

	AA.simplex_ph2(cc, xx);

	for (j=N+1; j<=M+N; j++) 
		if(xx[j] != 0)	
			ERROR("simplex: Es existieren keine zulässigen Punkte!");

	////////// Ende Phase I //////////

	simplex_ph2(c, xx);

	for (j=1; j<=N; j++)
		x[j] = xx[j];
}

template <typename DATATYPE>
Polynom<DATATYPE> Matrix<DATATYPE>::characteristic_polynom(void) const
{
	register long i, j;

	if (M != N)
		ERROR("The matrix is not quadratic!");

	Matrix<Polynom<DATATYPE> > En(M, M), A(M, M), B(M, M);
	Vector<DATATYPE> v;
	
	v.resize(2);

	v[1] = 0;
	v[2] = 1;

	Polynom<DATATYPE> p(v);

	for (i=1; i<=M; i++)
		for (j=1; j<=N; j++)
			A[i][j] = (*this)[i][j];
	
	En.make_one(M);
	
	// [ B = µ*En - A ]
	B = (En * p) - A; 

	return B.determinant();
}

template <typename DATATYPE>
DATATYPE Matrix<DATATYPE>::determinant(void) const
{
	if (M != N)
		ERROR("Matrix: a non-quadratic matrix determinant is not defined");

	register long i, r;
	Vector<long> pmt;

	Matrix<DATATYPE> L, R;
	DATATYPE det;

	r = gauss(L, R, pmt);

	if (r < M) 
		det = 0;
	else {
		det = 1;
		for (i=1; i<=M; i++)
			det *= R.row[i][i];
	}

	return det;
}

template <typename DATATYPE>
void Matrix<DATATYPE>::resize(register long m, register long n)
{
	if (m < 0 || n < 0)
		ERROR("Matrix: invalid size");

	register long i;

	if (m > M) {

		Vector<DATATYPE> *tmp_vec;

		tmp_vec = 0;
		if (row) 
			tmp_vec = row;
		row = new Vector<DATATYPE>[m+1];
		if (tmp_vec) {
			for (i=1; i<=M; i++) 
				row[i] = tmp_vec[i];
			delete [] tmp_vec;
		}

		for (i=M+1; i<=m; i++) 
			row[i].resize(N);
	}

	M = m;

	if (M > 0) {

		//if (n > N) 
		if (n > 0) 
			for (i=0; i<=M; i++) 
				row[i].resize(n);

		N = n;
	}
}

template <typename DATATYPE>
void Matrix<DATATYPE>::swap(register long i, register long j) 
{
	if (!(0 <= i && i <= M && 0 <= j && j <= M))
		ERROR("Matrix: swap index out of range");

	if (i != j) {
		DATATYPE *tmp;
		tmp = row[i].data;
		row[i].data = row[j].data;
		row[j].data = tmp;
	}
}

template <typename DATATYPE>
void Matrix<DATATYPE>::clear(void)
{
	register long i;
	
	for (i=1; i<=M; i++)
		row[i].clear();
}

template <typename DATATYPE>
void Matrix<DATATYPE>::make_zero(register long m)
{
	register long i, j;

	if (m == 0)
		m = M;

	resize(m, m);
	for (i=1; i<=M; i++)
		for (j=1; j<=N; j++)
			row[i][j] = 0;
}

template <typename DATATYPE>
void Matrix<DATATYPE>::make_one(register long m)
{
	register long i;

	make_zero(m);
	for (i=1; i<=M; i++)
		row[i][i] = 1;
}

template <typename DATATYPE>
void Matrix<DATATYPE>::blockmatrix_AD(Matrix<DATATYPE> const &A, 
	Matrix<DATATYPE> const &D) 
{
	register long i, j;

	this->resize(A.M + D.M, A.N + D.N);
	this->clear();

	for (i=1; i<=A.M; i++)
		for (j=1; j<=A.N; j++)
			(*this)[i][j] = A[i][j];
	
	for (i=A.M+1; i<=M; i++)
		for (j=A.N+1; j<=N; j++)
			(*this)[i][j] = D[i-A.M][j-A.N];
}

template <typename DATATYPE_FRIEND>
istream& operator>> (istream &i, Matrix<DATATYPE_FRIEND> &ref)
{
	char c; 
	register long m, l;
	
	m = 1;

	if (!i)
		ERROR("Matrix: bad input1"); 

	c = i.peek(); 
	while (isspace(c)) 
	{ 
		i.get(); 
		c = i.peek(); 
	} 

	if (c != '[') 
		ERROR("Matrix: bad input2"); 

	i.get(); 

	c = i.peek(); 
	while (isspace(c)) 
	{ 
		i.get(); 
		c = i.peek(); 
	} 

	while (c != ']' && c != (-1))
	{ 
		ref.resize(m);

		if (!(i >> ref.row[m])) 
			ERROR("Matrix: bad input3");

		m++; 

		c = i.peek(); 
		while (isspace(c)) 
		{ 
			i.get(); 
			c = i.peek(); 
		} 
	} 

	if (c == (-1)) 
		ERROR("Matrix: bad input4"); 

	i.get(); 

	ref.N = 0;
	for (l=1; l<=ref.M; l++) 
		if (ref.row[l].N > ref.N)
			ref.N = ref.row[l].N;

	ref.resize(ref.M, ref.N);
	
	return i;
}

template <typename DATATYPE_FRIEND>
ostream& operator<< (ostream &o, Matrix<DATATYPE_FRIEND> const &ref) 
{
	register long i;

	o << "[" << endl;;
	for (i=1; i<=ref.M; i++) 
		o << ref.row[i] << endl;
	o << "]";

	return o;
}

long modular_gauss(ZZ const * const * const T, 
		register long m, register long n, ZZ const &modul, 
		ZZ ** const L, ZZ ** const R, bool &sign) 
{
	ZZ max, inv, t, *tmp;
	register long i, j, k, z, rang, min_dim, max_dim;

	z = 0;
	
	min_dim = LMIN(m, n);
	max_dim = LMAX(m, n);
	
	rang = min_dim;

	for (i=0; i<m; i++)
		for (j=0; j<n; j++)
			L[i][j] = T[i][j] % modul;
		
	sign = true; // ==> the determinant is positive
	
	for (j=0; j<n; j++) {
		max = 0;
		for (i=j; i<m; i++) {
			if (ABS(L[i][j]) > ABS(max)) {
				max = L[i][j];
				z = i;
			}
		}

		if (max == 0) { 
			rang--;
			continue;
		}
	
		if (z != j) { // swap the rows (z, j)
			
			tmp = L[z];
			L[z] = L[j];
			L[j] = tmp;

			sign = !sign;
		}

		// Compute the inverse of max % modul, 
		// via the extended euclidean algorithm
				
		ZZ::extended_euclid(max, modul, inv, t);
		
		for (k=j+1; k<m; k++) {		
			L[k][j] = (L[k][j] * inv) % modul;     
			for (i=j+1; i<n; i++)
				L[k][i] = (L[k][i] - ((L[k][j]*L[j][i]) % modul) % modul); 
		}
	}
		
	for (i=0; i<m; i++) {
		for (j=0; j<n; j++) {
			if (i <= j && i < n) {
				R[i][j] = L[i][j];
				L[i][j] = 0;
			} else
				R[i][j] = 0;
		}

		if (i < n)
			L[i][i] = 1;
	}

	return rang;
}

ZZ modular_determinant(ZZ const * const * const T, register long n)
{
	register long i, j, r, rang;
	bool sign = true;
	
	ZZ N, det, two, tmp, modul, B, C;

	ZZ **L, **R;
	ZZ *m, *d;

	B = 0;
	for (i=0; i<n; i++) {
		for (j=0; j<n; j++) {
			tmp = ABS(T[i][j]);

			if (tmp > B)
				B = tmp;
		}
	}

	N = n;
	two = 2;

	if (n % 2 == 0)
		tmp = N / two;
	else
		tmp = (N + 1) / two;

	C = ZZ::pow(N, tmp) * ZZ::pow(B, N);
	r = TO_LONG(CEIL(ZZ::log2(two * C + 1)));

	if (r >= PRIMES) {
		ERROR("globals3: add more primes to primes.h / defs.h");
	}

	L = new ZZ*[n];
	R = new ZZ*[n];
	
	ASSERT(L);
	ASSERT(R);

	for (i=0; i<n; i++) {
		L[i] = new ZZ[n];
		R[i] = new ZZ[n];
	
		ASSERT(L[i]);
		ASSERT(R[i]);
	}

	m = new ZZ[r];
	d = new ZZ[r];

	ASSERT(m);
	ASSERT(d);

	for (j=0; j<r; j++) {

		modul = m[j] = prime[j];
		rang = modular_gauss(T, n, n, modul, L, R, sign);
		
		if (rang < n) 
			d[j] = 0;
		else {
			d[j] = 1;
			for (i=0; i<n; i++) 
				d[j] = d[j] * R[i][i];
			d[j] = d[j] % modul;
			
			if (!sign)
				d[j] = -d[j];
		}
	}

/*
	std::cerr << "modul_vector = ";
	
	for (i=0; i<r; i++)
		std::cerr << m[i] << " ";
	std::cerr << std::endl;

	std::cerr << "det_vector = " ;
	
	for (i=0; i<r; i++)
		std::cerr << d[i] << " ";
	std::cerr << std::endl;
*/

	for (i=0; i<n; i++) {
		delete [] L[i];
		delete [] R[i];
	}
		
	delete [] L;
	delete [] R;

	det = ZZ::chinese_remainder(m, d, r);

	delete [] m;
	delete [] d;

	return det;
}

template <typename DATATYPE>
void Matrix<DATATYPE>::simplex_ph2(Vector<DATATYPE> const &c, 
		Vector<DATATYPE> &x) const 
{
	bool isElement = false;

	register long i, j, k, l;
	register long countJ, countJc, counter;

	DATATYPE sum, min;

	Matrix<DATATYPE> x1, x2;
	Matrix<DATATYPE> AA, L, R;
	Vector<DATATYPE> bb, xx, xxx;

	Vector<long> J, Jc, pmt; 

	x1.resize(N, N);
	x2.resize(N, N);

	AA.resize(M, M);

	bb.resize(M);
	pmt.resize(M);

	J.resize(M);
	Jc.resize(N);

	xx.resize(N);

	countJ = 0;
	countJc = 0;

	// Erzeugung der Indexmengen
	
	for (j=1; j<=N; j++) {
		if (ABS(x[j]) == 0) {
			countJc++;
			Jc[countJc] = j;
		} else {
			countJ++;
			J[countJ] = j;
		}
	}
		
	// Ergaenze J solange, 
	// bis countJ == M
		
	for (j=1; j<=N; j++) {

		if (countJ == M)
			break;

		for (k=1; k<=countJ; k++) {
			if (J[k] == j) {
				isElement = true;
				break;
			}
		}

		if (isElement)
			continue;
		
		for (i=1; i<=M; i++)
			for (k=1; k<=countJ; k++) 
				AA[i][k] = (*this)[i][J[k]];

		for (i=1; i<=M; i++)
			AA[i][countJ+1] = (*this)[i][j];

		if (AA.gauss(L, R, pmt) > countJ) {

			countJ++;
			J[countJ] = j; 
			
			for (k=1; k<=countJc; k++) {

				if (Jc[k] == j) {
					Jc[k] = Jc[countJc];
					countJc--;
					break;
				}
			}
		}
	}

	if (countJ != M || countJc != N-M) 
		ERROR("simplex_phase2: the amount of basis indices is != M");

	// Alles ok, die Indexmengen
	// sind nun fertig belegt

	// Berechnung der Startwerte fuer x1[i][j] 

	for (i=1; i<=M; i++)
		for (j=1; j<=M; j++)
			AA[i][j] = (*this)[i][J[j]];

	if (AA.gauss(L, R, pmt) != M) 
		ERROR("simplex_phase2: the matrix has not full rank!");

	for (j=1; j<=N-M; j++) {
		for (i=1; i<=M; i++) 
			bb[i] = (*this)[i][Jc[j]];

		if (compute_coords(L, R, pmt, bb, xxx, false, false) != 1) 
			ERROR("simplex_phase2: could not compute a valid solution!");

		for (i=1; i<=M; i++) 
			x1[J[i]][Jc[j]] = xxx[i];
	}

	counter = 0;

	while (counter < LOOP_LIMIT) {
		k = N+1; 

		// Bildung der negativen red. Kosten
		 
		for (i=1; i<=N-M; i++) {
			sum = 0;
			for (j=1; j<=M; j++)
				sum += c[J[j]] * x1[J[j]][Jc[i]];
			sum -= c[Jc[i]];

			if (sum > EPSILON && Jc[i] < k /* Bland'sche Regel */) 
				k = Jc[i]; 
		}

		if (k != N+1) {
			for (j=1; j<=M; j++)
				if (x1[J[j]][k] > 0)
					break;

			if (j == M+1) 
				ERROR("simplex_phase2: Problem ist nicht beschraenkt!");

         l = J[1];
			min = x[J[1]] / x1[J[1]][k];
			
			for (i=2; i<=M; i++) {
				if (x1[J[i]][k] > 0) {
					if ((x[J[i]] / x1[J[i]][k]) < min) {
						l = J[i]; 
						min = x[J[i]] / x1[J[i]][k];
					} else if ((x[J[i]] / x1[J[i]][k]) == min && J[i] < l)
						l = J[i]; 
				}
			}

			// Update der Indexmengen
			 
			for (i=1; i<=M; i++)
				if (J[i] == l)
					J[i] = k; 

			for (i=1; i<=N-M; i++)
				if (Jc[i] == k)
					Jc[i] = l;

			// Anwendung der Rekursionsformeln
			 
			for (i=1; i<=M; i++) {
				if (J[i] == k)
					xx[k] = x[l]/x1[l][k];
				else
					xx[J[i]] = x[J[i]] - (x[l] * x1[J[i]][k])/x1[l][k];
			}

			for (i=1; i<=M; i++) {
				for (j=1; j<=N-M; j++) {
					if (J[i] == k && Jc[j] == l)
						x2[k][l] = 1/x1[l][k];
					else if (J[i] == k)
						x2[k][Jc[j]] = x1[l][Jc[j]]/x1[l][k];
					else if (Jc[j] == l)
						x2[J[i]][l] = - (x1[J[i]][k]/x1[l][k]);
					else {
						x2[J[i]][Jc[j]] = x1[J[i]][Jc[j]] 
							- x1[l][Jc[j]]*(x1[J[i]][k]/x1[l][k]);
					}
				}
			}

			// Umkopieren fuer Neubeginn der Rekursion
			 
			for (i=1; i<=M; i++)
				x[J[i]] = xx[J[i]];
			for (i=1; i<=N; i++)
				for (j=1; j<=N; j++)
					x1[i][j] = x2[i][j];

			counter++;

		} else
			break;
	}

	for (i=1; i<=N-M; i++)
		x[Jc[i]] = 0;

	if (counter >= LOOP_LIMIT)
		ERROR("simplex_phase2: LOOP_LIMIT reached!");
}


/*************************************************************************/
/*                                                                       */
/* This function computes a solution x for:										 */
/*                                                                       */
/*										L*R*x = pmt(b)										 */
/* and returns:																			 */
/*                                                                       */
/*		1: If everything went alright (the computed coords are correct)    */
/* 	0: If the matrix was said to be regular, but it isn't              */
/*   -1: If the matrix was said to be not regular and no solution exists */
/*   -2: If the computed coords should be integer, but they aren't!      */
/*                                                                       */
/*************************************************************************/
template <typename DATATYPE>
short compute_coords(Matrix<DATATYPE> const &L, 
	Matrix<DATATYPE> const &R, Vector<long> const &pmt, 
	Vector<DATATYPE> const &b, Vector<DATATYPE> &x,
	bool regular, bool integer = true) 
{
	DATATYPE tmp;
	register long i, j, k, dim, probe;
	Vector<DATATYPE> bb, y, yy;

	if (b.N != L.M)
		ERROR("compute_coords: b.N != L.M");

	dim = LMIN(L.M, L.N);

	x.resize(L.N);
	y.resize(L.N);
	
	x.clear();
	y.clear();

	bb.resize(L.M);

	for (i=1; i<=L.M; i++)
		bb[i] = b[pmt[i]];
	
	// Löse L*y = bb //
	for (k=1; k<=dim; k++) {
		y[k] = bb[k];
		for (i=1; i<k; i++)
			y[k] -= L[k][i]*y[i];
		y[k] /= L[k][k];
	}

	probe = 0;
		
	// Löse R*x = y //
	for (k=L.N; k>=1; k--) {

		if (R[k][k] == 0) { 

			// Das System besitzt entweder keine
			// oder unendlich viele Lösung(en).
			
			if (regular)
				return 0;

			// Falls unendlich viele Lösungen existieren,
			// setze x[k] = 0 und prüfe ob die bereits gewählten x[j] 
			// die Gleichung sum_j=k+1..N { R[k][j]*x[j] } = y[k] erfüllen.
		
			x[k] = 0;
			tmp = 0;

			for (j=k+1; j<=L.N; j++) 
				tmp += R[k][j] * x[j];

			// Falls die Gleichung nicht erfüllt ist, existiert KEINE Lösung!
			
			if (ABS(y[k] - tmp) > EPSILON) 
				return -1;
			
		} else {
			
			x[k] = y[k];
			for (i=k+1; i<=L.N; i++) 
				x[k] -= R[k][i]*x[i];

			x[k] /= R[k][k];

			if (integer) {
				tmp = ROUND(x[k]);
				if (ABS(x[k] - tmp) > 0.4) // FIXME > EPSILON
					probe = k;
					
				x[k] = tmp;
			} 
		}
	}

	if (probe) {

		yy = L*R*x;
		y.resize(bb.N);

		for (j=1; j<=y.N; j++)
			y[j] = yy[pmt[j]];
/*
		cerr << "bb = " << bb << endl;
		cerr << "y = " << y << endl;
*/
		if (y != bb) 
			return -2;
	}

	return 1;
}
