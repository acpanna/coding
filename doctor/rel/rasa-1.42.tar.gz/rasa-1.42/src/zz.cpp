#include "zz.h"

#include "defs.h"
#include "error.h"

#include <iostream>
#include <algorithm>
#include <iterator>
#include <cstring>
#include <cstdio>

#include <climits>

#define KARATSUBA 750

using namespace std;

// USHORT_DECIMALS ist der Exponent der groessten Zehner-Potenz,
// die noch mit einer unsigned short dargestellt werden kann.
static const unsigned short USHORT_DECIMALS = (unsigned short) \
		((sizeof(unsigned short) * 8 * log(2.0))/log(10.0));

// BASE gibt an, bzgl. welcher Basis
// die ZZs intern dargestellt werden.
static const unsigned long BASE = (unsigned long) pow(10.0, USHORT_DECIMALS);


/******** Verschiedene Hilfsfunktionen ********/
inline unsigned long ushort_join(const unsigned short &high, 
				const unsigned short &low)
{
	return (unsigned long) high * BASE + (unsigned long) low;
}

inline void ulong_split(const unsigned long &join, unsigned short &high,
					unsigned short &low)
{
	high = (unsigned short) (join / (unsigned long) BASE);
        low = (unsigned short) (join - (unsigned long) high *
          					(unsigned long) BASE);
}

bool trim_string(char * const string)
{
	char ret = '+';
        char *ptr1 = string, *ptr2 = string;
	unsigned long i = 0;

        // Extrahiere ein evtl. Vorzeichen aus dem String
        while (string[i] != '+' && string[i] != '-' && string[i] != '\0') i++;
	if (string[i] != '\0')
        	ret = string[i];

	// Entferne alle Nicht-Ziffern != 0,...,9
        for (; *ptr2 != '\0'; ptr2++)
        	if (isdigit(*ptr2)) {
        		*ptr1 = *ptr2;
        		ptr1++;
        	}

	*ptr1 = '\0';
	ptr1 = ptr2 = string;
        
	// Entferne fuehrende Nullen
	while (*ptr2 == '0')
        	ptr2++;

	for (; *ptr2 != '\0'; ptr1++, ptr2++)
		*ptr1 = *ptr2;

	*ptr1 = '\0';
     
	// Falls der String nach Bereinigung "leer" ist, so
	// setze ret = '+' (leerer String wird als 0 interpretiert,
	// 0 hat in meiner Implementation pos. Vorzeichen)
	if (string[0] == '\0')
		ret = '+';
	
	// Gebe Vorzeichen des Strings zurueck
	if (ret == '+')
		return true;
	else
		return false;
}


/******** Implementierung der Klasse ZZ ********/

ZZ::ZZ(ZZ const &src) : STL_Vector()
{ 
	*this = src; 
}

ZZ& ZZ::operator =(int src)
{
	unsigned short rest;
	clear(); 
	
	if (src == 0) {
		sign = true;
		push_back(0);
		return *this;
	} else if (src < 0) {
		sign = false;
		src = -src;
	} else  
		sign = true;

	while (src != 0) {
		rest = src % BASE;
		src = src / BASE;
		
		push_back(rest);
	}
	
	return *this;
}

ZZ& ZZ::operator =(const ZZ &src)
{
	if (this != &src) {
		STL_Vector::operator=(src);
		sign = src.sign;
	}

	return *this;
}

ZZ& ZZ::operator =(const char * const src)
{
	char *ptr, *str = new char[strlen(src) + 1];
	assert(str);
	strcpy(str, src);

	clear();
	sign = trim_string(str); 
	
	ptr = str;
	while (*ptr != '\0')
		ptr++;
	
	while (ptr != str) {
		ptr -= USHORT_DECIMALS;

		if (ptr <= str) 
			ptr = str;

		push_back((unsigned short) atol(ptr));
		*ptr = '\0';
	}

	if (empty())
		*this = 0;

	delete [] str;
	return *this;
}

ZZ& ZZ::lshift(const size_type &steps)
{
	if (*this == 0)
		return *this;

	insert(begin(), steps, 0);
	
	return *this;
}

ZZ ZZ::operator-(void) const
{ 
	ZZ ret;
	ret = *this;
	ret.sign = !this->sign;

	return ret;
}

ZZ ZZ::abs(void) const
{
	ZZ ret;
	ret = *this;
	ret.sign = true;
	return ret;
}

int ZZ::compare(ZZ const &rts) const
{
	size_type this_size = size(), rts_size = rts.size(), i;

	// At first it is checked if both arguments are equal to zero.
	// If this is the case, then both signs are set to "plus".
	 
	if (this_size == 1 && rts_size == 1) 
		if ((*this)[0] == 0 && rts[0] == 0) 
				return 0;

	if (sign == true && rts.sign == false) 
		return 1;
	if (sign == false && rts.sign == true)
		return -1;
	
	int ret;
	
	if (this_size > rts_size)
		ret = 1;
	else if (this_size < rts_size)
		ret = -1;
	else {
		for (i=this_size-1; i>0; i--)
			if ((*this)[i] != rts[i])
				break;

		if ((*this)[i] < rts[i])
			ret = -1;
		else if ((*this)[i] > rts[i])
			ret = 1;
		else
			ret = 0;
	}
		
	if (sign == true)
		return ret;
	else
		return -ret;
}

ZZ& ZZ::add(const ZZ &a, const ZZ &b, ZZ &ret)
{
	if (a == 0)
		return (ret = b);
	if (b == 0)
		return (ret = a);
	
	if (a.sign == true && b.sign == false) 
		return sub(a, b.abs(), ret);
	if (a.sign == false && b.sign == true) 
		return sub(b, a.abs(), ret);

	unsigned short carry = 0;
	unsigned long res;

	size_type i = 0, a_size = a.size(), b_size = b.size(), minlen, maxlen;
	
	minlen = min(a_size, b_size);
	maxlen = max(a_size, b_size);

	if (ret.size() != maxlen)
		ret.resize(maxlen);

	while (i < minlen) {
		res = a[i] + b[i] + carry;
		
		if (res > BASE-1) {
			res -= BASE;
			carry = 1;
		} else
			carry = 0;
		
		ret[i] = (unsigned short) res;
		i++;
	}

	while (i < a_size) {
		res = a[i] + carry; 
	
		if (res > BASE-1) {
			res -= BASE;
			carry = 1;
		} else
			carry = 0;
		
		ret[i] = (unsigned short) res;
		i++;
	}

	while (i < b_size) {
               	res = b[i] + carry;
		
		if (res > BASE-1) {
			res -= BASE;
			carry = 1;
		} else
			carry = 0;
		
		ret[i] = (unsigned short) res;
               	i++;
        }

	if (carry != 0)
		ret.push_back(carry);
	
	ret.sign = a.sign;
	return ret;
}

ZZ& ZZ::sub(const ZZ &a, const ZZ &b, ZZ &ret)
{
	if (b == 0)
		return (ret = a);
	if (a == 0) {
		ret = b;
		ret.sign = !b.sign;
		return ret;
	}
		
	if (a.sign == true && b.sign == false) 
		return add(a, b.abs(), ret);

	if (a.sign == false && b.sign == true) {
		add(a.abs(), b, ret);
		ret.sign = false;
		return ret;
	}
	
	if (a.sign == false && b.sign == false) 
		return sub(b.abs(), a.abs(), ret);
	
	if (a < b) {
		sub(b, a, ret);
		ret.sign = false;
		return ret;
	}
	
	size_type i = 0, a_size = a.size(), b_size = b.size();
	
	if (ret.size() != a_size)
		ret.resize(a_size);

	unsigned short carry = 0;
	long res;

	while (i < b_size) {
		res = a[i] - b[i] - carry;
			
		if (res < 0) {
			res += BASE;
			carry = 1;
		} else
			carry = 0;
		
		ret[i] = (unsigned short) res;
		i++;
	}

	while (i < a_size) {
		res = a[i] - carry;

		if (res < 0) {
			res += BASE;
			carry = 1;
		} else
			carry = 0;
				
		ret[i] = (unsigned short) res;
		i++;
	}

	while (ret.back() == 0 && ret.size() > 1)
		ret.pop_back();
	
	ret.sign = true;
	return ret;
}

ZZ& ZZ::mul(const ZZ &a, const ZZ &b, ZZ &ret)
{
	if (a == 0 || b == 0) {
		ret = 0;
		return ret;
	}
	
	if (&a == &ret)
	{
		ZZ tmp(a);
		return mul(tmp, b, ret);
	}
	
	if (&b == &ret)
	{
		ZZ tmp(b);
		return mul(a, tmp, ret);
	}

	if (a.size() * b.size() <= KARATSUBA) 
		return schul_mul(a, b, ret);

	return karatsuba_mul(a, b, ret);
}

ZZ& ZZ::schul_mul(const ZZ &x, const ZZ &y, ZZ &ret)
{
	unsigned short lo, hi, carry = 0;
	unsigned long res;

	size_type i, j, k, x_size = x.size(), y_size = y.size();
	
	ret.clear();
	ret.resize(x_size + y_size, 0);
		
	for (i=0; i<x_size; i++) {
		for (j=0; j<y_size; j++) {
			res = x[i] * y[j];
			ulong_split(res, hi, lo);

			for (k=0; k<2; k++) {
				res = ret[i+j+k] + lo + carry;
				if (res > BASE-1) {
					res -= BASE;
					carry = 1;
				} else
					carry = 0;

				ret[i+j+k] = (unsigned short) res;
				lo = hi;
			}
			
			while (carry) {
				res = ret[i+j+k] + carry;
				if (res > BASE-1) {
					res -= BASE;
					carry = 1;
				} else
					carry = 0;

				ret[i+j+k] = (unsigned short) res;
				k++;
			}
		}
	}

	while (ret.back() == 0)
		ret.pop_back();
	
	ret.sign = !(x.sign ^ y.sign);
	return ret;
}

ZZ& ZZ::karatsuba_mul(const ZZ &x, const ZZ &y, 
							ZZ &ret)
{
	ZZ a, b, c, d, temp1, temp2, temp3;

	size_type x_size = x.size(), y_size = y.size();
	size_type k = max(x_size, y_size), i;
	
	if (k % 2 == 1)
		k = k + 1;

	a.clear();
	b.clear();
	c.clear();
	d.clear();

	// Besetze b mit niedrigen Stellen aus x
	for (i=0; i<x_size && i<k/2; i++)
		b.push_back(x[i]);
		
	while (b.back() == 0 && b.size() > 1)
			b.pop_back();

	// Wichtig, sonst gibts evtl. negative Nullen!
	if (b.back() != 0)
		b.sign = x.sign;
	
	// Besetze a mit hohen Stellen aus x
	if (x_size <= k/2)
		a = 0;
	else {
		for (i=k/2; i<x_size; i++)
			a.push_back(x[i]);
	
		a.sign = x.sign;
	}

	// Besetze d mit niedrigen Stellen aus y	
	for (i=0; i<y_size && i<k/2; i++) 
		d.push_back(y[i]);
		
	while (d.back() == 0 && d.size() > 1)
		d.pop_back();
		
	// Wichtig, sonst gibts evtl. negative Nullen!
	if (d.back() != 0)
		d.sign = y.sign;
		
	// Besetze c mit hohen Stellen aus y	
	if (y_size <= k/2)
		c = 0;
	else {
		for (i=k/2; i<y_size; i++)
			c.push_back(y[i]);
	
		c.sign = y.sign;
	}
	
	// temp1 = (a-b) * (d-c);
	sub(a, b, temp2);
	sub(d, c, temp3);
	mul(temp2, temp3, temp1);

	// temp2 = a * c
	mul(a, c, temp2);

	// temp3 = b * d
	mul(b, d, temp3); 

	// temp1 = temp1 + temp2 + temp3
	add(temp1, temp2, temp1);
	add(temp1, temp3, temp1); 
	
	temp1.lshift(k/2);
	temp2.lshift(k);

	// ret = temp1 + temp2 + temp3
	add(temp1, temp2, ret);
	add(ret, temp3, ret);
	
	return ret;
}

double ZZ::log2(ZZ x)
{
	double y, z, f;
	ZZ q, r;

	if(x <= 0) 
		ERROR("log2(x), x <= 0 is not implemented / defined");

	y = 0.0;
	z = 1.0;
	f = 0.0;

	while (x >= 2) {

		div(x, 2, q, r);
		x = q;

		if (r	== 1) 
			f += 1.0;

		f /= 2.0;
		y++;
	}

	f += 1.0;

	while (z > EPSILON) {

		f *= f;
		z /= 2.0;

		if (f >= 2.0) {
			y += z;
			f /= 2.0;
		}
	}

	return y;
}

double ZZ::log(ZZ x) 
{
	return (log2(x) * 0.6931471805599453094172321214581765681);
}

ZZ& ZZ::pow(ZZ a, ZZ b, ZZ &ret)
{
	if (b < 0) {
		cerr << b << endl;
		ERROR("[ ZZ::operator ^ ] ist fuer Exponenten < 0 "\
			"nicht implementiert -- Programmabbruch!");
	}

	ret = 1;
	ZZ tmp;

	while (b != 0) {
		if (b.front() % 2 != 0)
		{
			// ret = ret * a
			mul(ret, a, ret);
		}
		
		// a = a * a
		mul(a, a, a);

		// b = b / 2
		div(b, 2, b, tmp); 
	}

	return ret;
}
	
ZZ ZZ::pow(ZZ const &a, ZZ const &b) 
{
	ZZ ret;
	pow(a, b, ret);

	return ret;
}

void ZZ::div(const ZZ &x, const ZZ &y, ZZ &q, ZZ &r)
{
	if (&q == &r) {
		cerr << "[ ZZ::operator / ] &q == &r " \
			"-- Programmabbruch!" << endl;
		exit(1);
	}
	
	if (y == 0) {
		cerr << "[ ZZ::operator / ] Division durch Null " \
			"-- Programmabbruch!" << endl;
		exit(1);
	}

	ZZ a, b, tmp, tmp2;
	long d = BASE / (y.back() + 1);
	
	// Multiplikation mit d bewirkt, dass bei der 
	// folgenden Berechnung von quot, dieses hoechstens 
	// um 2 groesser ist als der wahre Wert
	
	// a = |x| * d
	// b = |y| * d
	mul(x.abs(), d, a);
	mul(y.abs(), d, b);
	
	if (a < b) {
		// Reihenfolge nicht vertauschen!
		// Es kann passieren, dass &q == &x
		r = x; 
		q = 0;
		return;
	}
		
	size_type a_size = a.size(), b_size = b.size(), i, j;

	if (a_size == 1) {
		a.push_back(0);
		a_size++;
	}

	// Falls der Quotient aus den ersten beiden Stellen des Dividenden a
	// und der ersten Stelle des Divisors b, nicht mehr mit einer Ziffer 
	// der Zahlenbasis dargestellt werden kann, erweitere Dividend mit
	// fuehrender Null
	if (ushort_join(a[a_size-1], a[a_size-2]) / b.back() > BASE-1) {
		a.push_back(0);
		a_size++;
	}

	j = a_size - b_size;
	q.resize(j);
		
	// Speichere die f�hrenden (b_size)
	// Stellen von a in tmp
	tmp.resize(b_size);
	for (i=b_size; i>0; i--) 
		tmp[i-1] = a[j-1+i];
	
	while (j > 0) {
		// tmp durch Hinzufuegen von fuehrenden 
		// Nullen auf die Groesse b_size bringen 
		while (tmp.size() != b_size) 
			tmp.push_back(0);
		
		// Hole die naechste Stelle des Dividenden 
		// und haenge sie an tmp an
		tmp.insert(tmp.begin(), 1, a[j-1]);
	
		// Berechne aktuelle Stelle des Quotienten 
		unsigned short quot = min(BASE-1, 
			ushort_join(tmp[b_size], tmp[b_size-1]) / b.back());
		
		// Fuehrende Nullen aus tmp entfernen
		while (tmp.back() == 0 && tmp.size() > 1) 
			tmp.pop_back();

		// tmp = tmp - b * quot
	 	mul(b, quot, tmp2);
		sub(tmp, tmp2, tmp);
		
		// Falls tmp negativ ist, so wurde quot
		// zu gross gewaehlt --> verkleinere quot 
		while (tmp.sign == false) {
			quot = quot - 1;
			
			// tmp = tmp + b
			add(tmp, b, tmp);
		}
		
		// Updaten des Quotienten 
		j--; q[j] = quot;
	}

	// Fuehrende Nullen im Ergebnis entfernen 
	while (q.back() == 0) 
		q.pop_back();
		
	// Fuehrende Nullen aus tmp entfernen
	while (tmp.back() == 0 && tmp.size() > 1) 
		tmp.pop_back();

	// Bestimmung von |r|
       	// |r| = tmp/d
	div(tmp, d, r, tmp2);
	
	// Setze das Vorzeichen des Quotienten und des Rests
	q.sign = !(x.sign ^ y.sign);
	r.sign = x.sign;

	return;
}
	
ZZ& ZZ::ggT(const ZZ &x, const ZZ &y, ZZ &ret)
{	
	ZZ a, b, tmp;
	
	a = x.abs();
	b = y.abs();
	
	while (b != 0) {
		// ret = a % b
		div(a, b, tmp, ret);
	
		a = b;
		b = ret;
	}

	ret = a;
	return ret;
}

ZZ& ZZ::kgV(const ZZ &a, const ZZ &b, ZZ &ret)
{
	ZZ tmp;

	// ret = a * b / ggT(a, b)
	mul(a, b, tmp);
	ggT(a, b, ret);
	div(tmp, ret, ret, tmp);
	
	return ret;
}

ZZ ZZ::extended_euclid(ZZ const &a, ZZ const &b, ZZ &s, ZZ &t)
{
	ZZ aa, d, dd, ss, tt;

	if (b == 0) {
		s = 1;
		t = 0;
		return a;
	}

	aa = a % b;
	dd = extended_euclid(b, aa, ss, tt);
	
	d = dd;
	s = tt;

	t = ss - (a / b) * tt;

	return d;
}

ZZ ZZ::chinese_remainder(ZZ const * const m, ZZ const * const v, register long r)
{
	register long i;

	ZZ mm, mm_mi, s, t, d, c, sum, least;

	mm = 1;
	for (i=0; i<r; i++)
		mm = mm * m[i];
	
	sum = 0;
	for (i=0; i<r; i++) { 
		mm_mi = mm / m[i];

		d = extended_euclid(mm_mi, m[i], s, t);

		if (d != 1) 
			ERROR("Vector: chinese_remainder deals only with co-primes!");
		
		c = (v[i]*s) % m[i];
		sum = sum + (c * mm_mi);

		least = sum;

		// Compute the value with the smallest absolute 
		// value in the residue class { sum + ZZ*mm }.
		 
		if (sum > 0) {

			while (ABS(sum) <= ABS(least)) {
				least = sum;
				sum = sum - mm;
			}

		} else {

			while (ABS(sum) <= ABS(least)) {
				least = sum;
				sum = sum + mm;
			}
		}
	}

	return least;
}

ostream& operator <<(ostream &OS, const ZZ &value)
{
	if (!value.sign)
		OS << "-";
	
	for (STL_Vector::const_reverse_iterator iter=value.rbegin();
			iter != value.rend(); iter++)
	{
		char *str = new char[USHORT_DECIMALS + 1];
		assert(str);
		
		sprintf(str, "%u", *iter);
	
		if (iter != value.rbegin()) {
			for (unsigned short i=0; 
					i<USHORT_DECIMALS-strlen(str); i++)
				OS << 0;
		}
		
		OS << *iter;
		delete [] str;
	}
	
	return OS;
}
	
istream& operator >>(istream &IS, ZZ &value)
{
	string str;
	
	IS >> str;
	value = str.c_str();

	return IS;
}

