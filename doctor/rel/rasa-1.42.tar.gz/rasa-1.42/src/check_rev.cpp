#include "matrix.h"
#include "globals.h"

#include <fstream>
#include <sstream>
#include <cstring>

using namespace std;

void usage(char *prg) 
{
	cerr << prg << " [--prec=" << prec << "] [--map=*.map_XXXX]";
	cerr << " file.heu|file.slk|file.sol" << endl;
	exit(1);
}

int main(int argc, char **argv)
{
	bool aardal, prb_exists = true;
	long idx;
	
	register long i, m = 0, ineq = 0, sdim = 0;
	char ch, *ptr, buff[4096];

	string pstr, lstr, mstr, sstr, params;

	Matrix<REAL> lat, A_u, A_g, B;
	Vector<REAL> tmp_vec, l_u, r_u, b_g, c, r_x, x_prob, x_lat;

	REAL R, two, val;
	
	if (argc > 4 || argc < 2) 
		usage(argv[0]);

	mstr = "";

	prec = PRECISION;

	for (i=1; i<argc; i++) {

		if (strncmp(argv[i], "--prec=", 7) == 0) {
#ifdef INF_DTYPE
			strcpy(buff, argv[i]+7);
			istringstream iss(buff, istringstream::in);
			iss >> prec;
#else
			if (strstr(argv[0], "check_rev-rr") == NULL)
				ERROR("Run check_rev-rr, if you want to use the prec parameter!");
#endif
		} else if (strncmp(argv[i], "--map=", 6) == 0) {
			strcpy(buff, argv[i]+6);
			istringstream iss(buff, istringstream::in);
			iss >> mstr;
		} else if (strncmp(argv[i], "-", 1) == 0) {
			usage(argv[0]);
		} else 
			strcpy(buff, argv[i]);
	}

#ifdef INF_DTYPE
	NTL::RR::SetPrecision(prec);
	prec = NTL::RR::precision();

	if (prec < PRECISION)
		ERROR("Please use a precision >= " << PRECISION);

	NTL::RR::SetOutputPrecision(EXT_OUT_PRECISION);
#endif

	sstr = string(buff);
	
	ptr = strstr(buff, ".heu");
	if (ptr == NULL) {
		ptr = strstr(buff, ".slk");
		if (ptr == NULL) {
			ptr = strstr(buff, ".sol");
			if (ptr == NULL) 
				usage(argv[0]);
		}

	} else 
		prb_exists = false;

	*ptr = 0;

	pstr = string(buff) + string(".prb");
	lstr = string(buff) + string(".lat");

	ifstream fin_prob;
	if (prb_exists) {

		fin_prob.open(pstr.c_str());
		if (!fin_prob.good()) {
			cerr << "The problem file [ " << pstr << " ] can't be opened!";
			cerr << endl;
			return 1;
		}
	}

	ifstream fin_lat(lstr.c_str());
	if (!fin_lat.good()) {
		cerr << "The lattice file [ " << lstr << " ] can't be opened!";
		cerr << endl;
		return 1;
	}
		
	fin_lat >> lat;

	if (mstr != "") {

		ifstream fin_map(mstr.c_str());
		if (!fin_map.good()) {
			cerr << "The map file [ " << mstr << " ] can't be opened!";
			cerr << endl;
			return 1;
		}

		fin_map >> lat;
		fin_map.close();
	} 

	ifstream fin_sol(sstr.c_str());
	if (!fin_sol.good()) {
		cerr << "The solution file [ " << sstr << " ] can't be opened!";
		cerr << endl;
		return 1;
	}
	
	cerr << "[ file: " << sstr << " ]" << endl;

	two = 2;

	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	fin_lat >> tmp_vec;
	fin_lat >> c;
	fin_lat >> R;
	fin_lat >> idx;
	fin_lat >> val;

	fin_lat.close();

	if (prb_exists) {

		fin_prob >> A_u;
		fin_prob >> A_g;
		fin_prob >> l_u;
		fin_prob >> r_u;
		fin_prob >> b_g;
		fin_prob >> r_x;
		fin_prob >> aardal;
		fin_prob.close();

		ineq = A_u.M;

		if (aardal)
			m = ineq;
		else
			m = ineq + A_g.M;

		sdim = r_x.N;
	}

	while (1) {
		
		ch = fin_sol.peek();
		while (ch != '[')
		{
			if (fin_sol.eof()) {
				fin_sol.close();
				return 0;
			}

			fin_sol.get();
			ch = fin_sol.peek();

			if (ch == '|') 
				getline(fin_sol, params);
			
			ch = fin_sol.peek();
		}

		if (prb_exists) {

			fin_sol >> x_prob;

			x_lat.resize(m + sdim + 1); // m + n + 1

			if (ineq)
				tmp_vec = A_u*x_prob*two - (l_u+r_u);

			for (i=1; i<=ineq; i++) 
				x_lat[i] = tmp_vec[i];

			for (i=ineq+1; i<=m; i++) 
				x_lat[i] = 0;

			for (i=1; i<=idx; i++) 
				x_lat[i+m] = x_prob[i]*(val+1) - 1;

			for (i=idx+1; i<=sdim; i++) 
				x_lat[i+m] = x_prob[i]*(2*c[i+m]) - R;

			x_lat[m + sdim + 1] = R;

		} else 
			fin_sol >> x_lat;

//		cerr << ext_prec << x_prob << endl;
//		cerr << ext_prec << x_lat << endl;

		/*******************************/
		/*                             */
		/*   Hier wird überprüft, ob   */
		/*    x_lat im Gitter liegt    */
		/*                             */
		/*******************************/
		 
		Matrix<REAL> L, R;
		Vector<REAL> coord;
		Vector<long> pmt;

		B = lat.transpose();
		B.gauss(L, R, pmt);

		if (compute_coords(L, R, pmt, x_lat, coord, true) != 1)
			ERROR("check_rev: could not compute valid coords!");

		if (B*coord == x_lat) {
			cout << ext_prec << "x_lat = " << x_lat << endl;
			cout << ext_prec << "coord = " << coord << endl;
		} 	else {
			cerr << ext_prec << "This solution is incorrect:";
			cerr << ext_prec << "\t[ B*coord - x_lat ] = ";
			cerr << ext_prec << ((B*coord) - x_lat) << endl;
			cerr << ext_prec << "\tprec = " << prec << endl;
		}
	}

	return 0;
}
