#ifndef STAGE__H
#define STAGE__H

#include "globals.h"

class Stage {

	public:
		Stage();
		void clear(void);

	public:
		REAL ytilda;
		REAL vtilda;
		REAL ctilda;

		REAL utilda_lb; 
		REAL utilda_ub;  
		REAL utilda;
		
		REAL Delta;
		REAL delta;

		bool nprune;
};

#include "stage.cpp"

#endif
