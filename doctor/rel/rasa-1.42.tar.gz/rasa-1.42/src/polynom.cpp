template <typename DATATYPE> 
Polynom<DATATYPE>::Polynom() : a(1)
{
}

template <typename DATATYPE> 
Polynom<DATATYPE>::Polynom(Polynom<DATATYPE> const &ref_pol) : a(1)
{
		*this = ref_pol;
}

template <typename DATATYPE> 
Polynom<DATATYPE>::Polynom(Vector<DATATYPE> const &ref_vec) : a(1)
{
	register long i;

	a.resize(ref_vec.N);
	for (i=1; i<=ref_vec.N; i++)
		a[i] = ref_vec[i];

	trim();
}

template <typename DATATYPE> 
Polynom<DATATYPE>::~Polynom()
{
}

template <typename DATATYPE> 
DATATYPE & 
Polynom<DATATYPE>::operator[] (register long j) const
{ 
	if (0 <= j && j <= grad()) 
		return a[j+1]; 
	else {
		a[0] = 0;
		return (a[0]);
	}
}

template <typename DATATYPE> 
DATATYPE  
Polynom<DATATYPE>::operator() (DATATYPE const &x) const
{ 
	DATATYPE ret;
	register long i, n = grad();

	ret = (*this)[0];
	for (i=1; i<=n; i++)
		ret += ((*this)[i] * pow(x, (double) i));

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator= (Polynom<DATATYPE> const &ref_pol)
{
	if (this == &ref_pol)
		return *this;

	a = ref_pol.a;

	return *this;
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator= (DATATYPE const &ref_scal)
{
	a.resize(1);
	a[1] = ref_scal;

	return *this;
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator+=(Polynom<DATATYPE> const &ref)
{
	(*this) = (*this) + ref;
	
	return (*this);
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator-=(Polynom<DATATYPE> const &ref)
{
	(*this) = (*this) - ref;

	return (*this);
}


template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator*=(DATATYPE const &ref)
{
	(*this) = (*this) * ref;

	return (*this);
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator*=(Polynom<DATATYPE> const &ref)
{
	(*this) = (*this) * ref;

	return (*this);
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator/=(DATATYPE const &ref)
{
	(*this) = (*this) / ref;

	return (*this);
}

template <typename DATATYPE> 
Polynom<DATATYPE> const & 
Polynom<DATATYPE>::operator/=(Polynom<DATATYPE> const &ref)
{
	(*this) = (*this) / ref;

	return (*this);
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator+(Polynom<DATATYPE> const &ref) const
{
	Polynom<DATATYPE> ret;
	register long i, max_grad = LMAX(grad(), ref.grad());

	ret = (*this);
	ret.a.resize(max_grad+1);

	for (i=0; i<=max_grad; i++)
		ret[i] += ref[i];

	ret.trim();

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator+(DATATYPE const &ref) const
{
	Polynom<DATATYPE> ret;
	
	ret = (*this);
	ret[0] += ref;

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator-(Polynom<DATATYPE> const &ref) const
{
	Polynom<DATATYPE> ret;
	register long i, max_grad = LMAX(grad(), ref.grad());

	ret = (*this);
	ret.a.resize(max_grad+1);

	for (i=0; i<=max_grad; i++)
		ret[i] -= ref[i];

	ret.trim();

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator-(DATATYPE const &ref) const
{
	Polynom<DATATYPE> ret;
	
	ret = (*this);
	ret[0] -= ref;

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator*(DATATYPE const &ref) const
{
	register long i, n = grad();
	Polynom<DATATYPE> ret;

	ret = (*this);
	for (i=0; i<=n; i++)
		ret[i] *= ref;

	ret.trim();
	
	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator*(Polynom<DATATYPE> const &ref) const
{
	register long i, n = grad();
	Polynom<DATATYPE> ret, p;

	ret = (ref * (*this)[0]);
	for (i=1; i<=n; i++) {
		p = (ref * (*this)[i]);
		ret += (p.xmult(i));
	}

	ret.trim();

	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator/(Polynom<DATATYPE> const &ref) const
{
	Polynom<DATATYPE> q, r;
	polynomdivision(ref, q, r);

	if (r != 0)
		ERROR("Polynomdivision geht nicht auf: (" << (*this) << ") = ("
				<< q << ") * (" << ref << ") + (" << r << ")" );
		
	return q;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator/(DATATYPE const &ref) const
{
	register long i, n = grad();
	Polynom<DATATYPE> ret;

	ret = (*this);
	for (i=0; i<=n; i++)
		ret[i] /= ref;

	ret.trim();
	
	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::operator-(void) const
{
	Polynom<DATATYPE> ret;

	ret = 0;
	ret = (ret - (*this));

	return ret;
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator==(Polynom<DATATYPE> const &ref) const
{
	return (this->a == ref.a);
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator==(DATATYPE const &ref) const
{
	if (grad() == 0 && ABS((*this)[0] - ref) < EPSILON)
		return true;

	return false;
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator!=(Polynom<DATATYPE> const &ref) const
{
	return (this->a != ref.a);
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator!=(DATATYPE const &ref) const
{
	return !((*this) == ref);
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator>(DATATYPE const &ref) const
{
	if (grad() == 0 && ABS((*this)[0] - ref) > EPSILON)
		return true;

	return false;
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator>(Polynom<DATATYPE> const &ref) const
{
	if (grad() == 0) {
		if (ref.grad() == 0) {
			if (ABS((*this)[0] - ref[0]) > EPSILON)
				return true;
		} else {
			return true;
		}
	}

	return false;
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator>=(DATATYPE const &ref) const
{
	return ((*this) > ref || (*this) == ref);
}

template <typename DATATYPE> 
bool 
Polynom<DATATYPE>::operator>=(Polynom<DATATYPE> const &ref) const
{
	return ((*this) > ref || (*this) == ref);
}
	
template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::xmult(register long exp) const
{
	register long i;

	if (exp < 0)
		ERROR("xmult with exp < 0 is not implemented!");

	Polynom<DATATYPE> ret;
	ret.a.resize(a.N + exp);

	for (i=0; i<exp; i++)
		ret[i] = 0;
	for (i=exp; i<ret.a.N; i++)
		ret[i] = (*this)[i-exp];

	return ret;
}

template <typename DATATYPE> 
void Polynom<DATATYPE>::polynomdivision(Polynom<DATATYPE> const &divisor, 
		Polynom<DATATYPE> &q, Polynom<DATATYPE> &r) const
{
	if (&q == &r)
		ERROR("polynomdivison error: &q == &r!");

	register long grad_dividend = grad();
	register long grad_divisor = divisor.grad();

	if (grad_divisor > grad_dividend) {
		q = 0;
		r = (*this);
	} else {

		DATATYPE faktor;
		Polynom<DATATYPE> dividend2;
		register long exponent;

		exponent = grad_dividend - grad_divisor;
		faktor = ((*this)[grad_dividend] / divisor[grad_divisor]);
		dividend2 = ((*this) - (divisor * faktor).xmult(exponent));

		if (dividend2 == 0) {
			r = 0;
		}
		else {
			dividend2.polynomdivision(divisor, q, r);
		}

		q.a.resize(exponent+1);
		q[exponent] = faktor;
	}
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::differentiate(void) const
{
	register long i, n = grad();
	Polynom<DATATYPE> ret;
	ret = (*this);

	for (i=0; i<n; i++)
		ret[i] = ret[i+1] * (i+1);
	ret[n] = 0;

	ret.trim();
	return ret;
}

template <typename DATATYPE> 
Polynom<DATATYPE> 
Polynom<DATATYPE>::integrate(void) const
{
	register long i, n = grad();
	Polynom<DATATYPE> ret;
	ret = (*this);

	ret.a.resize(ret.a.N + 1);

	for (i=n; i>=0; i--)
		ret[i+1] = (1.0 / (i+1)) * ret[i];
	ret[0] = 0;

	return ret;
}

template <typename DATATYPE> 
DATATYPE Polynom<DATATYPE>::newton_root(void) const
{
	long count = 1;

	Polynom<DATATYPE> f_1;
	DATATYPE x0, x1;

	f_1 = differentiate();

	x0 = -1; // rand_eq_real(-10, 10); 
	while (f_1(x0) == 0) 
		x0 = 1; // rand_eq_real(-10, 10);

	while(count < LOOP_LIMIT)
	{
		x1 = -(*this)(x0);
		if (SQRT(pow2(x1)) < EPSILON)
			break;

		x1 = (x1 / f_1(x0));
		x0 = x0 + x1;

		count++;
	}

	return x0;
}

template <typename DATATYPE> 
Polynom<DATATYPE> Polynom<DATATYPE>::real_root_factor(void) const
{
	Polynom<DATATYPE> p0, q, r, qq, rr;
	Vector <DATATYPE> v0;
	DATATYPE ns;

	if (this->grad() <= 1)
		return (*this);

	v0.resize(2);

	v0[1] = 0;
	v0[2] = 1;

	p0 = v0;
	ns = newton_root();

	if (ABS((*this)(ns)) < EPSILON) {
		p0[0] = -ns;
		polynomdivision(p0, q, r);
		if (r == 0)  {
			return (q.real_root_factor() * p0);
		}
		 
		ERROR("r = " << r << "!= 0")
	} 

	p0[0] = 1;
	p0[1] = 0;

	return p0;
}

template <typename DATATYPE> 
long
Polynom<DATATYPE>::grad(void) const
{
	return (a.N-1);
}

template <typename DATATYPE> 
void
Polynom<DATATYPE>::trim(void)
{
	register long i, n = grad();

	for (i=n; i>=0; i--)
		if (ABS((*this)[i]) > EPSILON)
			break;

	if (i >= 0)
		this->a.resize(i+1);
	else
		this->a.resize(1);
}

template <typename DATATYPE> 
std::ostream& operator <<(std::ostream &s, Polynom<DATATYPE> const &p)
{
	bool first = true;
	register long i, n = p.grad();

	for (i=n; i>0; i--) {
		if (p[i] == 0 && i > 0)
			continue;
	
		if (!first)
			s << " + ";

		first = false;

		if (i == 0) {
			if (p[0] < 0)
				s << "(" << p[0] << ")";
			else	
				s << p[0];
		} else if (p[i] < 0)
			s << "(" << p[i] << ")*x^" << i;
		else	
			s << p[i] << "*x^" << i;
	}

	if (p[0] != 0 || n == 0)  {

		if (!first)
			s << " + ";

		if (p[0] < 0)
			s << "(" << p[0] << ")";
		else	
			s << p[0];
	} 

	return s;
}
