#include "qq.h"
#include "globals.h"
#include <cstring>

void add(QQ &ret, const QQ &a, const QQ &b)
{
	QQ_TYPE z_a, z_b, n;
	com_denom(z_a, z_b, n, a, b); 
	
	ret.zaehler = z_a + z_b;
	ret.nenner = n;

	ret.kuerzen();
}

void sub(QQ &ret, const QQ &a, const QQ &b)
{
	QQ_TYPE z_a, z_b, n;
	com_denom(z_a, z_b, n, a ,b); 
	
	ret.zaehler = z_a - z_b;
	ret.nenner = n;
	
	ret.kuerzen();
}

std::istream& operator >>(std::istream &s, QQ &x)
{
	std::string str;
	char c = s.peek();

	while (c != ' ' && c != ']') {
		str = str + c;
		s.get();
		c = s.peek();
	}
	
	x = str.c_str();

	return s;
}

std::ostream& operator <<(std::ostream &s, const QQ &a)
{
	if (a.nenner == 1) 
		s << a.zaehler;
	else
		s << a.zaehler << "/" << a.nenner;
		
	return s;
}

QQ::QQ() : zaehler(0), nenner(1) 
{ }

QQ::QQ(int src) : zaehler(src), nenner(1)
{ }

QQ::QQ(long src) : zaehler(src), nenner(1)
{ }

QQ::QQ(QQ_TYPE src) : zaehler(src), nenner(1)
{ }

QQ::QQ(long z, long n) : zaehler(z), nenner(n)
{ }

QQ::QQ(QQ_TYPE z, QQ_TYPE n) : zaehler(z), nenner(n)
{ }

QQ::QQ(const QQ &src) : zaehler(0), nenner(1)
{ 
	*this = src; 
}

QQ::QQ(const char * const src) : zaehler(0), nenner(1)
{ 
	*this = src; 
}

QQ& QQ::operator =(int rts)
{
	zaehler = rts;        
	nenner = 1;

	return *this;
}

QQ& QQ::operator =(long rts)
{
	zaehler = rts;        
	nenner = 1;

	return *this;
}

QQ& QQ::operator =(double rts)
{
	zaehler = rts;
	nenner = 1;
	
	return *this;
}

QQ& QQ::operator =(const QQ &rts)
{
	zaehler = rts.zaehler;
	nenner = rts.nenner;

	return *this;
}

QQ& QQ::operator =(const char * const str)
{
	char *ptr, *str2 = new char[strlen(str) + 1];
	if (!str2) 
		ERROR("QQ: out of memory");
	               
	strcpy(str2, str);
	ptr = str2;

	while (*ptr != '/' && *ptr != '\0')
		ptr++; 
		
	if (*ptr == '/') {
		*ptr = '\0';
		ptr++; 
	}       
	
	zaehler = atof(str2);

	if (*ptr == '\0')
		nenner = 1;
	else {  
		nenner = atof(ptr);
		if (nenner == 0) 
			ERROR("QQ: division by zero1");
	}       
	
	delete [] str2;

	return this->kuerzen();
}

QQ& QQ::kuerzen(void)
{
	if (zaehler == 0) 
		nenner = 1;
	
	QQ_TYPE ggt;

	gcd(ggt, zaehler, nenner);
	
	zaehler /= ggt;
	nenner /= ggt;
	
	if (sign(nenner) == -1) {
		zaehler = -zaehler;
		nenner = -nenner;
	}
/*
   // Falls Zaehler oder Nenner zu gross werden, teile den Zaehler
	// durch den Nenner ==> Vorteil: Zahlen bleiben  klein, 
	// Kürzen geht schneller -- Nachteil: Ungenauigkeiten ...
  
	if (ABS(zaehler) > QQ_TYPE_BND || ABS(nenner) > QQ_TYPE_BND ||
			ABS(zaehler) < QQ_TYPE_EPS || ABS(nenner) < QQ_TYPE_EPS) {

		zaehler = ROUND(zaehler / nenner);
		nenner = 1;

		kuerzen(); 
	}
*/
	return *this;
}

long compare(const QQ& a, const QQ& b)
{
	QQ_TYPE z_a, z_b, n;
	com_denom(z_a, z_b, n, a, b);
        
	if (z_a == z_b)
		return 0;
	if (sign(n) == 1) {
		if (z_a < z_b)
			return -1;
		else
			return 1;
	} else {
		if (z_a < z_b)
			return 1;
		else
			return -1;
	}
}

void com_denom(QQ_TYPE &a_z, QQ_TYPE &b_z, QQ_TYPE &ab_n, 
		const QQ &a, const QQ &b)
{
	if (&a_z == &b_z || &a_z == &ab_n || &b_z == &ab_n) 
		ERROR("QQ: the QQ_TYPEs have the same adress");

	QQ_TYPE ggt;
	
	// ab_n = kgv(a.nenner, b.nenner)
   ab_n = a.nenner * b.nenner;
	gcd(ggt, a.nenner, b.nenner);
	ab_n = ab_n / ggt;

	// a_z = (ab_n / a.nenner) * a.zaehler 
	// b_z = (ab_n / b.nenner) * b.zaehler
	a_z = ab_n / a.nenner;
	b_z = ab_n / b.nenner;
	a_z = a.zaehler * a_z;
	b_z = b.zaehler * b_z;
}

void gcd(QQ_TYPE &ggt, QQ_TYPE const &a, QQ_TYPE const &b)
{
	QQ_TYPE tmp;

	tmp = ROUND(a / b);
	// tmp = a % b
	tmp = (a - tmp * b);

	if (b == 0)
		ggt = a;
   else
      gcd(ggt, b, tmp);
}

void div(QQ &ret, const QQ &a, const QQ &b)
{
   if (b.zaehler == 0)
		ERROR("QQ: divison by zero2");
	
	QQ tmp;
	
	tmp.zaehler = b.nenner;
	tmp.nenner = b.zaehler;
	
	mul(ret, a, tmp);
}

void mul(QQ &ret, const QQ &a, const QQ &b)
{
	QQ r1, r2;

	r1.zaehler = a.zaehler;
	r1.nenner = b.nenner;
	r2.zaehler = b.zaehler;
	r2.nenner = a.nenner;
	
	r1.kuerzen();
	r2.kuerzen();

	// ret = r1 * r2
	ret.zaehler = r1.zaehler * r2.zaehler;
	ret.nenner = r1.nenner * r2.nenner;
}

void power(QQ &ret, const QQ &a, const QQ &b)
{
	if (b.nenner != 1) {
		QQ_TYPE tmp_z, tmp_n;

		tmp_z = pow(a.zaehler, (1.0 / b.nenner));
		tmp_n = pow(a.nenner, (1.0 / b.nenner));

		ret = (tmp_z / tmp_n);
	} else
		ret = a;

	if (b < 0) {
		if (a.zaehler == 0) 
			ERROR("QQ: division by zero3");
	
		QQ_TYPE tmp; 

		tmp = pow(ret.nenner, ABS(b.zaehler));
		ret.nenner = pow(ret.zaehler, ABS(b.zaehler));
		ret.zaehler = tmp;

	} else {
		ret.zaehler = pow(ret.zaehler, b.zaehler);
		ret.nenner = pow(ret.nenner, b.zaehler);
	}
}

void abs(QQ &ret, QQ const &src)
{
	if (src.zaehler < 0) 
		ret.zaehler = -src.zaehler;
	else
		ret.zaehler = src.zaehler;
	
	if (src.nenner < 0)
		ret.nenner = -src.nenner;
	else
		ret.nenner = src.nenner;
}

void sqrt(QQ& z, const QQ& a)
{ 
	if (a.zaehler < 0) {
		z.zaehler = -a.zaehler;
		z.nenner = -a.nenner;
	} else
		z = a;

	if (z.nenner < 0)
		ERROR("QQ: sqrt of a negative number");
		
	z.zaehler = sqrt(a.zaehler);
	z.nenner = sqrt(a.nenner);
}

QQ ceil(const QQ& a)
{
	QQ ret;
	ret.zaehler = CEIL(a.zaehler / a.nenner);
	return ret;
}

QQ floor(const QQ& a)
{
	QQ ret;
	ret.zaehler = FLOOR(a.zaehler / a.nenner);
	return ret;
}

QQ log(const QQ& a)
{ 
	QQ ret;
	ret.zaehler = log(a.zaehler / a.nenner); 
	return ret;
}
