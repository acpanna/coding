#ifndef SET__H
#define SET__H

#include "element.h"
#include "error.h"

template <class DATATYPE>
class Set
{
	public:
		Set(void); 
		Set(long max); 
		Set(Set const &ref); 
		~Set(); 
		
		void clear(void);

		bool insert(const Element<DATATYPE> &e);
		void remove(const Element<DATATYPE> &e);

		void remove_smaller(void);
		void remove_greater(void);
		
		Element<DATATYPE> * min_element(void) const;
		Element<DATATYPE> * max_element(void) const;

		Element<DATATYPE> * contains(const Element<DATATYPE> &e) const;
		
		bool contains(const Set &other) const;

		Set& operator= (const Set &ref);  
		Set& vereinigung(const Set &other);

		bool operator==(const Set &other) const;  

		void swap(Element<DATATYPE> &e1, Element<DATATYPE> &e2);
		
		void shuffle(register long count);

		Element<DATATYPE> * prev_element(Element<DATATYPE> const * const ref) const
		{ if (ref == 0) return last_element; else return ref->prev_element; }

		Element<DATATYPE> * next_element(Element<DATATYPE> const * const ref) const
		{ if (ref == 0) return first_element; else return ref->next_element; }

		template <class DATATYPE_FRIEND>
		friend std::ostream& operator << (std::ostream &io, 
				Set<DATATYPE_FRIEND> &set);

	public:
		long elements;			
		long elements_max;			

	public:
		Element<DATATYPE> *first_element;
		Element<DATATYPE> *last_element;
		Element<DATATYPE> *curr_element;

		REAL center; // it's dirty to put this 
		REAL dst_2;	 // in here, but it had to be ...
};

#include "set.cpp"

#endif
