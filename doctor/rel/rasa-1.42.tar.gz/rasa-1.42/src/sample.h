#ifndef SAMPLE__H
#define SAMPLE__H

#include "vector.h"

template <typename REAL>
class Sample {

	public:
		Sample();
		Sample(Sample const &ref);
		~Sample();

		Sample const & operator=(Sample const &ref);
		Sample const & operator=(double const &ref);

		template <typename REAL_FRIEND>
		friend void sswap(Sample<REAL_FRIEND> &a, 
				Sample<REAL_FRIEND> &b);

	public:
		Vector<REAL> B;
		Vector<REAL> U;
		Vector<REAL> MU; 

		REAL pi;
		REAL len;
		
		long pos;
};

#include "sample.cpp"

#endif
