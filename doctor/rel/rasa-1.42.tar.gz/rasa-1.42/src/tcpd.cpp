#include "tcp.h"

void* tcp_server(void *arg) 
{ 
	arg = 0; //

	int i, ctr, maxi, maxfd, listenfd, connfd, sockfd ; 
	int nready, client[FD_SETSIZE]; 

	ssize_t n; 
	fd_set rset, allset; 

	char str_hostname[MAXLINE];

	char banner[MAXLINE];

	char str_input[] = "You asked: ";
	char str_output[] = "My answer: ";

	char input[MAXLINE];
	char output[MAXLINE];

	socklen_t clilen; 
	struct sockaddr_in cliaddr, servaddr; 

	listenfd = Socket(AF_INET, SOCK_STREAM, 0); 

	i=1;
	setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(i));

	bzero(&servaddr, sizeof(servaddr)); 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(SERV_PORT); 
	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr)); 
	Listen(listenfd, LISTENQ); 

	fprintf(stderr, "Enumeration server listens on TCP port: %d\n", SERV_PORT);
	gethostname(str_hostname, MAXLINE);
	snprintf(banner, MAXLINE, "220 %s -- Enumeration server\n\n", str_hostname);

	maxfd = listenfd; 
	maxi  = -1; 

	for (i =0; i<FD_SETSIZE; i++ ) 
		client[i] = -1; 

	FD_ZERO(&allset); 
	FD_SET(listenfd, &allset); 

	ctr = 0;

	for (;;)
	{
		rset   = allset; 
		nready = Select(maxfd+1, &rset, NULL, NULL, NULL); 

		///////////////////////
		// Connection part
		///////////////////////

		if (FD_ISSET(listenfd, &rset)) 
		{
			clilen = sizeof(cliaddr); 
			connfd = Accept(listenfd, (SA *) &cliaddr, &clilen); 

			for (i=0; i<FD_SETSIZE; i++) 
				if (client[i] < 0) 
				{
					client[i] = connfd;
					break; 
				} 

			if (i == FD_SETSIZE) 
				err_quit ( "too many clients" ); 

			FD_SET(connfd, &allset); 

			Writen(connfd, banner, strlen(banner)); 

			if (connfd > maxfd) 
				maxfd = connfd; 

			if (i > maxi) 
				maxi = i; 

			if (--nready <= 0) 
				continue; 
		} 

		///////////////////////
		// Input/Output part
		///////////////////////

		sleep(1);
		ctr++;
		sprintf(output, "%d\n\n", ctr);

		for (i=0; i<=maxi; i++)  
		{
			if ((sockfd = client[i]) < 0) 
				continue; 

			if (FD_ISSET(sockfd, &rset))  
			{
				if ((n = Readline(sockfd, input, MAXLINE)) == 0)  
				{ 
					Close(sockfd); 
					FD_CLR(sockfd, &allset); 
					client[i] = -1; 
				} else {
					Writen(sockfd, str_input, strlen(str_input)); 
					Writen(sockfd, input, strlen(input)); 
					Writen(sockfd, str_output, strlen(str_output)); 
					Writen(sockfd, output, strlen(output)); 
				}


				if (--nready <= 0) 
					break; 
			}
		} 
	} 

	return NULL;
}

/*
void str_serv(int sockfd)
{
	ssize_t n;
	
	char banner[] = "This is the server response: ";
	char line[MAXLINE];

	for (;;) {
		if ((n = Readline(sockfd, line, MAXLINE)) == 0)
			return;

		Writen(sockfd, banner, strlen(banner));
		Writen(sockfd, line, n);
	}
}
*/
