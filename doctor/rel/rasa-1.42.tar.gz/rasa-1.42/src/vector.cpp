template <typename DATATYPE> 
Vector<DATATYPE>::Vector() : N(0), data(0)
{ }

template <typename DATATYPE> 
Vector<DATATYPE>::Vector(register long n) : N(0), data(0)
{ 
	resize(n);
}

template <typename DATATYPE> 
Vector<DATATYPE>::Vector(Vector<DATATYPE> const &ref) : N(0), data(0)
{
	*this = ref;
}

template <typename DATATYPE> 
Vector<DATATYPE>::~Vector() 
{ 
	if (data)
		delete [] data;
	
	data = 0;
	N = 0;
}

template <typename DATATYPE> 
Vector<DATATYPE> const & 
Vector<DATATYPE>::operator= (Vector<DATATYPE> const &ref)
{
	if (this == &ref)
		return *this;

	register long j;

	resize(ref.N);

	for (j=1; j<=ref.N; j++)
		data[j] = ref.data[j];

	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const & 
Vector<DATATYPE>::operator+=(Vector<DATATYPE> const& ref)
{
	if (N != ref.N)
		ERROR("Vector: dimension mismatch1");
	
	register long j;

	for (j=1; j<=N; j++)
		data[j] += ref.data[j];
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const & 
Vector<DATATYPE>::operator-=(Vector<DATATYPE> const &ref)
{
	if (N != ref.N)
		ERROR("Vector: dimension mismatch2");
	
	register long j;

	for (j=1; j<=N; j++)
		data[j] -= ref.data[j];
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const &
Vector<DATATYPE>::operator*=(Vector<DATATYPE> const &ref)
{ 
	if (N != ref.N)
		ERROR("Vector: dimension mismatch3");

	register long j;

	for (j=1; j<=N; j++)
		data[j] *= ref.data[j];
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const &
Vector<DATATYPE>::operator/=(Vector<DATATYPE> const &ref)
{ 
	if (N != ref.N)
		ERROR("Vector: dimension mismatch4");

	register long j;

	for (j=1; j<=N; j++)
		data[j] /= ref.data[j];
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const & 
Vector<DATATYPE>::operator*=(DATATYPE const &ref)
{
	register long j;

	for (j=1; j<=N; j++)
		data[j] *= ref;
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const & 
Vector<DATATYPE>::operator/=(DATATYPE const &ref)
{
	register long j;

	for (j=1; j<=N; j++)
		data[j] /= ref;
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> const &
Vector<DATATYPE>::operator%=(DATATYPE const &modul)
{ 
	register long j;

	for (j=1; j<=N; j++)
		data[j] = modulo(data[j], modul);
	
	return *this;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator+(Vector<DATATYPE> const &ref) const
{
	if (N != ref.N)
		ERROR("Vector: dimension mismatch5");
	
	register long j;
	Vector ret(*this);

	for (j=1; j<=ret.N; j++)
		ret.data[j] += ref.data[j];
	
	return ret;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator-(Vector<DATATYPE> const &ref) const
{
	if (N != ref.N)
		ERROR("Vector: dimension mismatch6");
	
	register long j;
	Vector ret(*this);

	for (j=1; j<=ret.N; j++)
		ret.data[j] -= ref.data[j];
	
	return ret;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator/(Vector<DATATYPE> const &ref) const
{ 
	if (N != ref.N)
		ERROR("Vector: dimension mismatch7");

	register long j;
	Vector ret(*this);

	for (j=1; j<=ret.N; j++)
		ret.data[j] /= ref.data[j];
	
	return ret;
}

template <typename DATATYPE> 
DATATYPE 
Vector<DATATYPE>::operator*(Vector<DATATYPE> const &ref) const
{
	if (N != ref.N)
		ERROR("Vector: dimension mismatch8");
   
	register long j;
	DATATYPE ret;
	
	ret = 0;
   for (j=1; j<=N; j++) 
      ret += (data[j] * ref.data[j]);

   return ret;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator*(DATATYPE const &ref) const
{ 
	register long j;
	Vector ret(*this);

	for (j=1; j<=ret.N; j++)
		ret.data[j] *= ref;
	
	return ret;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator/(DATATYPE const &ref) const
{ 
	register long j;
	Vector ret(*this);

	for (j=1; j<=ret.N; j++)
		ret.data[j] /= ref;
	
	return ret;
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator%(DATATYPE const &ref) const
{ 
	register long j;
	Vector ret(N);

	for (j=1; j<=ret.N; j++)
		ret.data[j] = modulo(data[j], ref);
	
	return ret;
}

template <typename DATATYPE>
DATATYPE & 
Vector<DATATYPE>::operator[] (register long j) const
{ 
	if (j < 0 || j > N) 
		ERROR("Vector: index out of range");

	return data[j]; 
}

template <typename DATATYPE> 
Vector<DATATYPE> 
Vector<DATATYPE>::operator-(void) const
{
	register long j;
	Vector ret;
	
	ret.resize(N);
	for (j=1; j<=N; j++)
		ret.data[j] = -data[j];

	return ret;
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::operator==(Vector<DATATYPE> const& ref) const
{	
	register long j;

	if (N != ref.N)
		ERROR("Vector: dimension mismatch9");

	for (j=1; j<=N; j++) {
		if (ABS(data[j] - ref.data[j]) <= EPSILON)
			continue;
		else
			return false;
	}

	return true;
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::operator<=(Vector<DATATYPE> const& ref) const
{
	register long j;

	if (N != ref.N)
		ERROR("Vector: dimension mismatch10");

	for (j=1; j<=N; j++) {
		if (data[j] <= ref.data[j])
			continue;
		else
			return false;
	}

	return true;
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::operator>=(Vector<DATATYPE> const& ref) const
{
	register long j;

	if (N != ref.N)
		ERROR("Vector: dimension mismatch11");

	for (j=1; j<=N; j++) {
		if (data[j] >= ref.data[j])
			continue;
		else
			return false;
	}

	return true;
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::operator!=(Vector<DATATYPE> const& ref) const
{
	return !((*this) == ref);
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::check_finite(register long k, DATATYPE &bnd) const
{
	register long j;

	for (j=1; j<=N; j++)
		if (ABS(data[j]) > bnd)
			break;

	if (j > N)
		return true;

	std::cerr << "Vector " << k << " doesn't satisfy the bnd condition: ";
	std::cerr << std::endl;
	std::cerr << (*this);
	std::cerr << std::endl;

	return false;
}

template <typename DATATYPE> 
bool 
Vector<DATATYPE>::is_abs_equal(Vector<DATATYPE> const &ref) const
{
	if ((*this) == ref) 
		return true;

	if ((*this) == (-ref)) 
		return true;
		
	return false;
}
  
template <typename DATATYPE> 
long Vector<DATATYPE>::zeroes(void) const
{
	register long z, j;

	z = 0;
	for (j=1; j<=N; j++)
		if (ABS(data[j]) < EPSILON)
			z++;

	return z;
}

template <typename DATATYPE> 
bool Vector<DATATYPE>::is_zero(void) const
{
	register long j;

	for (j=1; j<=N; j++)
		if (ABS(data[j]) > EPSILON)
			break;

	if (j > N)
		return true;
	
	return false;
}

template <typename DATATYPE> 
bool Vector<DATATYPE>::is_sparse(void) const
{
	if (zeroes() >= N-1)
		return true;

	return false;
}

template <typename DATATYPE> 
void Vector<DATATYPE>::resize(register long n) 
{
	if (n < 0)
		ERROR("vector: dimension < 0");

	if (n > N) {

		register long j;
		DATATYPE *tmp_real;

		tmp_real = 0;
		if (data)
			tmp_real = data;
		data = new DATATYPE[n+1];
		if (tmp_real) {
			for (j=1; j<=N; j++)
				data[j] = tmp_real[j];
			delete [] tmp_real;
		/*
			for (j=N+1; j<=n; j++)
				data[j] = 0
		*/
		}
	}

	N = n;
}

template <typename DATATYPE> 
void 
Vector<DATATYPE>::swap(register long i, register long j) 
{
	if (!(0 <= i && i <= N && 0 <= j && j <= N))
		ERROR("Vector: swap index out of range");

	if (i != j) {
		DATATYPE tmp;
		tmp = data[i];
		data[i] = data[j];
		data[j] = tmp;
	}
}

template <typename DATATYPE> 
void Vector<DATATYPE>::clear(register long start, register long end)
{
	register long j;

	if (start == 0 || end == 0) {
		start = 1;
		end = N;
	}

	for (j=start; j<=end; j++)
		data[j] = 0;
}

template <typename DATATYPE> 
void Vector<DATATYPE>::push_back(DATATYPE &dat)
{
	resize(N+1);
	data[N] = dat;
}

template <typename DATATYPE> 
const DATATYPE Vector<DATATYPE>::quad_euklid_norm(void) const
{
	return ((*this) * (*this));
}

template <typename DATATYPE> 
DATATYPE Vector<DATATYPE>::eins_norm(register long n) const
{
	register long j;
	DATATYPE ret;

	if (n == 0 || n > N)
		n = N;

	ret = 0;
	for (j=1; j<=n; j++)
		ret += ABS(data[j]);
	return ret;
}

template <typename DATATYPE> 
DATATYPE Vector<DATATYPE>::sup_norm(void) const
{
	register long j;
	DATATYPE t, ret;

	ret = 0;
	for (j=1; j<=N; j++) {
		t = data[j];

		if (t < 0)
			t = -t;
		if (t > ret)
			ret = t;
	}

	return ret;
}

template <typename DATATYPE_FRIEND> 
std::istream& operator>> (std::istream &i, Vector<DATATYPE_FRIEND> &ref)
{
	char c; 
	register long n = 1;

	if (!i)
		ERROR("Vector: bad input1"); 

	c = i.peek(); 
	while (isspace(c)) 
	{ 
		i.get(); 
		c = i.peek(); 
	} 

	if (c != '[') 
		ERROR("Vector: bad input2"); 

	i.get(); 

	c = i.peek(); 
	while (isspace(c)) 
	{ 
		i.get(); 
		c = i.peek(); 
	} 

	while (c != ']' && c != (-1))
	{ 
		ref.resize(n);

		if (!(i >> ref.data[n])) 
			ERROR("Vector: bad input3");

		n++; 

		c = i.peek(); 
		while (isspace(c)) 
		{ 
			i.get(); 
			c = i.peek(); 
		} 
	} 

	if (c == (-1)) 
		ERROR("Vector: bad input4"); 

	i.get(); 

	return i;
}

template <typename DATATYPE> 
void Vector<DATATYPE>::print_subvector(register long i, register long j) const 
{
	register long k;

	if (i < 1 || j < i || j > N || i > N)
		ERROR("Vector: dimension mismatch12");

	std::cerr << "( ";
	for (k=i; k<=j; k++)
		std::cerr << data[k] << " ";
	std::cerr << ")" << std::endl;
}

template <typename DATATYPE> 
DATATYPE Vector<DATATYPE>::gcd(register long i, register long j) const 
{
	DATATYPE ggt;
	register long k;

	if (i < 1 || j < i || j > N || i > N)
		ERROR("Vector: dimension mismatch13");

	ggt = ABS(data[i]);
	for (k=i+1; k<=j; k++) 
		ggt = ggT(ggt, data[k]); 

	return ggt;
}

template <typename DATATYPE> 
std::ostream& operator<< (std::ostream &o, Vector<DATATYPE> const &ref) 
{
	register long j;

	o << "[ ";
	for (j=1; j<=ref.N; j++) 
		o << ref.data[j] << " ";
	o << "]";

	return o;
}

template <typename DATATYPE> 
bool read_vector(std::ifstream &fin, Vector<DATATYPE> &x_lat)
{
	char ch = fin.peek();

	while (ch != '[') {

		if (fin.eof())
			return false;

		fin.get();
		ch = fin.peek();
	}

	fin >> x_lat;
	return true;
}
