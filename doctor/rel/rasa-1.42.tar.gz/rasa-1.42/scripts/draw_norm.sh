#!/bin/sh 

rm Rplots.ps Rplots.pdf /tmp/draw.r &> /dev/null

cat << _EOF_ > /tmp/draw.r 
#!/usr/bin/env Rscript

arg = commandArgs();

print(arg[6]);
source(arg[6]);

######################### Initialization #############################

x <- c(1:length(yB));

M <- matrix(c(yB, yC), length(yB));
colnames(M) <- c("Länge des Basisvektors", "Länge des orth. Vektors")

#yB;
#yC;
#M;

############################ Plotting ################################

yD <- rev(1 / yC);  
plot(x, type="b", pch=8, yC, main="Längen der orth. Basisvektoren", col="red", xlab="", ylab="");
plot(x, type="b", pch=8, yD, main="Länge der dualen orth. Basisvektoren", col="red", xlab="", ylab="");

#plot(x, type="b", pch=8, yC, main="", col="red", xlab="", ylab="");

######################################################################

plot(x, type="b", pch=8, log(yC[1]/yC), main="GSA behaviour (primal)", col="red", xlab="", ylab="");
#legend=legend("topleft", pch=8, col=c("red"), legend=c("log ( ||c[1]|| / ||c[i]|| )"));
plot(x, type="b", pch=8, log(yD[1]/yD), main="GSA behaviour (dual)", col="red", xlab="", ylab="");

######################################################################

#barplot(yC, col="red", main="Euklid. Längen der orth. Basisvektoren");
#barplot(yB, col="blue", main="Euklid. Längen der Basisvektoren\nund der zugehörigen orth. Basisvektoren");
#barplot(yC, col="red", add=TRUE);

#legend=legend("topright", pch=15, col=c("blue", "red"), legend=c("Basisvektoren", "orth. Basisvektoren"));

######################################################################

#barplot(M, col=rainbow(length(yB)), border="white", main="Euklid. Längen der Basisvektoren\nund der zugehörigen orth. Basisvektoren", beside=TRUE); 

# col=heat.colors(length(yB))
# col=gray.colors(length(yB))

######################################################################

#plot(x, type="b", log(yB/yC), main="GSA behaviour", col="red", xlab="", ylab="");
#legend=legend("topleft", pch=1, col=c("red"), legend=c("log ( ||b[i]|| / ||c[i]|| )"));

######################################################################

#plot(x, type="b", yC/yB[1], main="GSA behaviour", col="blue", ylim=c(1,5), xlab="", ylab="");
#points(x, type="b", log(yC[1]/yC), col="red");
#legend=legend("topleft", pch=1, col=c("blue", "red"), legend=c("||c[i]||/||b[1]||", "log(||c[1]||/||c[i]||)"));

######################################################################

#plot(x,5*yB,ylim=c(0.0,2000), xlab="x", ylab="||x||");
#plot(x, yC, type="b", col="blue", xlab="c", ylab="||c||");

# Add the norms of the orthogonal vectors to the plot
#points(x,yC,col="red", ylab="||x^||");

# Add the blue points to the first plot
#points(xC,5*40*log(yC[1]/yC),col="blue");

# Add the red points to the second plot
#points(xC,yB,col="red");

# Create the second plot
#plot(x,C);

# Add the blue points to the second plot
#points(x,5*40*log(C[1]/C),col="blue")

# Add the red points to the second plot
#points(x,B,col="red")

# Create the third and fourth plot 
barplot(B, beside = TRUE);

#	Sys.sleep(10);
#	dev.copy2eps("R.ps")
_EOF_

chmod 755 /tmp/draw.r

/tmp/draw.r "$1"

if [ -f Rplots.ps ] ; then
	gv Rplots.ps
fi

if [ -f Rplots.pdf ] ; then
	xpdf Rplots.pdf || evince Rplots.pdf 
fi
