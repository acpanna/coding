#!/bin/sh

LC_NUMERIC="POSIX" sort -n $1 | uniq > $1.tmp
mv $1.tmp $1
