
// Preload der Pfeilchen
on = new Image();
on.src = "ressources/pfeilchen_rechts_light.gif";
off = new Image();
off.src = "ressources/pfeilchen_rechts.gif";
backon = new Image();
backon.src = "ressources/pfeil_back_light.gif";
backoff = new Image();
backoff.src = "ressources/pfeil_back.gif";
linkon = new Image();
linkon.src = "ressources/pfeilchen_rechts_light.gif";
linkoff = new Image();
linkoff.src = "ressources/pfeilchen_rechts_link.gif";

// Highlighten bzw. Zur�cksetzen der Pfeilchen
function hi(n) {
	document.images[n].src = on.src;
}
function lo(n) {
	document.images[n].src = off.src;
}
function backhi(n) {
	document.images[n].src = backon.src;
}
function backlo(n) {
	document.images[n].src = backoff.src;
}
function linkhi(n) {
	document.images[n].src = linkon.src;
}
function linklo(n) {
	document.images[n].src = linkoff.src;
}

// Popup-Fenster
var rand = 18;  // Abstand der Bilder bzw. Flashchen zum Fensterrand
function popup(DatName,Breite,Hoehe) {
	Breite += rand;
	Hoehe += rand;
	window.open('popups/'+DatName,'Popup','toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=1,width=' + Breite + ',height=' + Hoehe);
}
